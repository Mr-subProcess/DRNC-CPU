# RAQM-03C Parça Seçim Gerekçeleri

## Ana komponent adayları

| İşlev | Aday | Kaynakla doğrulanan parametre | Hala yapılacak |
|---|---|---|---|
| eFuse | TI TPS25947 ailesi | 2.7–23V giriş, ayarlanabilir akım limiti, ters polarite ve reverse-current koruması, 5.5A sürekli switch akımı ailesi | Exact variant, ILIM, OVLO/UVLO, transient/inrush |
| 12V→5V buck | TI TPS54302DDCR | 4.5–28V giriş, 3A çıkış, 400kHz, SOT-23-6 DDC ailesi | Inductor, caps, feedback, thermal, EMI |
| Düşük voltaj buck | TI TPS62130A | 3–17V giriş, 0.9–6V çıkış, 3A, RGT 3x3mm QFN-16 | Her rail için current/inductor/capacitor ve stability |
| Konfigürasyon flash | Winbond W25Q128JVSSM | 128Mb, 2.7–3.6V, SPI/Dual/Quad, SOP-8, STR 133MHz, -40..125°C, mass-production status P | Vivado master-SPI x4 compatibility, straps, startup timing |
| Çıkış comparator | TI TLV3502 family | Dual, 2.7–5.5V, 4.5ns family speed, rail-to-rail input, push-pull output | CML common-mode/swing; comparator supply/output level adaptation |

## Kritik seçim uyarıları

- TPS54302 / TPS62130A için katalog maksimum akımı gerçek kartta kullanılabilir akım olarak kabul edilmez. Termal, copper area, inductor saturation, transient, efficiency ve derating analizleri gerekir.
- W25Q128JVSSM bir flash adayıdır; AMD configuration pin wiring ve Vivado boot flow test edilmeden bitstream flash seçimi kapanmış sayılmaz. 03B baseline içindeki W25Q128JVSIQ için üretici N / Not Recommended for New Design durumu nedeniyle yeni BOM’da yer verilmemiştir.
- TLV3502 family comparator çıkışı 5V beslenirse FPGA girişine doğrudan gidemez. 3.3V VCCO uyumlu arayüz gerekir. Giriş common-mode compatibility, actual RAQM output measurement olmadan kabul edilmez.
- RAQM driver olarak sıradan LVDS driver seçilmedi. CML hücresinin 4V civarı bias/common-mode ortamına LVDS seviyeleri doğrudan uymaz. Önce transistor-level interface network ölçümle tamamlanmalı.
