# XC7A35T-FGG484 Pinout Import Talimatı

AMD'nin resmi Artix-7 Package Device Pinout Files portalı, ZIP içerisinde CSV ve TXT ASCII package files sağladığını bildirir. Bu yürütme ortamında AMD ZIP indirme işlemi başarısız olduğundan 484 grid koordinatının signal/ball eşlemesi yapılmamıştır.

1. Resmi portal: https://www.amd.com/en/developer/resources/adaptive-socs-and-fpgas/package-pinout-files/artix-7-package-device-pinout-files.html
   Direct AMD ZIP (CSV + TXT): https://download.amd.com/adaptive-socs-and-fpgas/developer/adaptive-socs-and-fpgas/package-pinout-files/a7packages/a7all.zip
2. `XC7A35T` / `FGG484` dosyasını seç ve CSV ile TXT'yi çıkar.
3. CSV'yi `XC7A35T_FGG484_GRID_TEMPLATE_484.csv` ile karşılaştır; coordinate count, duplicate coordinate, empty signal, power/ground/NC categories kontrol et.
4. Her pin fonksiyonunu UG475 v1.20 package diagram ve bank/memory group diagram ile çapraz kontrol et.
5. PCIe lane0 için PG054 tablosu ve Vivado generated XDC/Pin Planner doğrulamasıyla GTP Quad216 / X0Y3, RX/TX/refclk eşleşmesini teyit et.
6. UG482 GTP reference resistor/filter topology'sini uygula.
7. I/O bank seçmeden önce tüm planned user nets için VCCO, IOSTANDARD, drive strength, slew, differential support and bank VREF constraints kontrol et.
8. Bağımsız ikinci kişi 484 konumu ve tüm power/GND/NC pins çapraz kontrol etsin.
9. Ancak o zaman gerçek KiCad FPGA symbol pin numbering ve FGG484 footprint pad mapping üret.

**Önemli:** Grid şablonundaki `A1`…`AB22` değerleri koordinat adaylarıdır; gerçek ball-to-signal data değildir. Sadece grid boyutu 22×22'dir. Dosya resmi pinout CSV'nin yerini tutmaz.
