# RAQM-03C PCB Stackup, Yerleşim ve SI Planı

## Hedef kart

- PCIe x1 electrical / x16 slot mechanical compatibility.
- First bring-up PCIe Gen1 2.5 GT/s only.
- Full-height/half-length mechanical outline is not frozen; select CEM revision/edge connector standard drawing before board outline.
- 6-layer PCB candidate; final thickness, copper, dielectric and controlled-impedance line geometry agreed with fabricator.

## 6-layer candidate stackup

| Layer | Intended use | Notes |
|---|---|---|
| L1 TOP | GTP PCIe TX/RX, REFCLK, critical local parts | continuous L2 reference; no plane splits under pairs |
| L2 GND | uninterrupted ground plane | primary return for L1 high-speed routes |
| L3 SIGNAL | local FPGA/flash and low-speed digital | keep switching nodes short; controlled return paths |
| L4 POWER | power islands: 12V, 5V, 3.3V, 1.8V, 1.2V, 1.0V | plane splits never under high-speed routes |
| L5 GND | solid ground plane | analog/digital return with deliberate tie strategy; no moat cuts |
| L6 BOTTOM | slow control/debug and auxiliary routes | avoid high-speed lane unless stackup field solver says acceptable |

## GTP / PCIe routing

- 100Ω differential target as board-level design target, exact geometry from fabricator stackup field solver; no generic width/spacing copied from unrelated stackup.
- Route each lane as continuous pair, length/skew limits from PCIe CEM and AMD GTP board design guidelines.
- Avoid stubs, test pads on high-speed pair, unnecessary vias, plane splits and sharp discontinuities.
- Place endpoint TX AC-coupling capacitors per CEM and AMD GT guidelines; exact values/placement must be frozen from current implementation guide.
- REFCLK pair routed as dedicated differential pair into MGTREFCLK; no general-purpose clock fanout into RAQM.
- No vias if possible; if needed, pair symmetry, return vias and via stub plan.

## Functional zoning

1. PCIe edge connector and GTP route at card edge.
2. FPGA + configuration flash in digital center zone.
3. Switching regulators near power entry, with SW nodes and inductors kept away from CML analog cells and GTP pairs.
4. CML/RAQM analog tile in its own quiet region, with local 5V filter and controlled return path.
5. JTAG/debug/test pads accessible at outer edge, not placed on GTP nets.

## Not yet frozen

- Exact card outline and card-edge geometry.
- BGA escape/via-in-pad/backdrill requirement and FGG484 fanout method.
- Trace width/gap, differential length, via transition and reference plane decisions.
- Copper weight, dielectric thickness/Dk/Df, solder mask, surface finish and edge bevel.
- Thermal spreading/copper/power plane analysis.
