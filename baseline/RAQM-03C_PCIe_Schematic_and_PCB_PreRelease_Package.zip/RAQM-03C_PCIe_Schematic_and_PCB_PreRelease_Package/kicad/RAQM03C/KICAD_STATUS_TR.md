# KiCad Durumu — RAQM-03C

Proje klasöründe bir root `.kicad_sch`, dört alt sistem `.kicad_sch` sayfası ve `.kicad_pro` yer alır. Bunlar KiCad S-expression biçiminde **sistem-seviyesi çizim sayfalarıdır**: hiyerarşik alt sistemleri, sınırları ve tasarım kararlarını görselleştirir. Gerçek komponent pinleri, pin numaraları, elektriksel wire/net ilişkileri veya footprint mapping içermez.

Bu ortamda `kicad-cli` / Eeschema bulunmadığı için dosyalar KiCad içinde açılarak görsel kontrol, annotation ve ERC/DRC testinden geçirilemedi. S-expression parantez dengesi ve sayfa UUID/instance referansları dosya üretiminde kontrol edildi; bu kontroller KiCad parser doğrulaması değildir.

**Açmak için:** `RAQM03C.kicad_pro` veya `RAQM03C.kicad_sch` dosyasını KiCad Eeschema ile aç. Sayfalar arasında hierarchical navigator kullan. Elektriksel şema sanma; üretim çıktısına dönüştürme.
