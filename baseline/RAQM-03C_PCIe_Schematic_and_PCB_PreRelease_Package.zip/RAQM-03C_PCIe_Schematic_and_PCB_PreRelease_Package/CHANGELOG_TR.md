# Değişiklik Kaydı — RAQM-03C

- RAQM-03B ZIP'i eksiksiz baseline olarak eklendi.
- Güç girişi koruması için TPS25947 ailesi aday gösterildi.
- 12V→5V ana dönüştürücü için TPS54302; 5V→FPGA rayları için TPS62130A ailesi aday gösterildi.
- 128Mb, 2.7–3.6V QSPI NOR flash W25Q128JVSSM (SOP-8, -40..125°C, mass production P) konfigürasyon adayı olarak eklendi.
- Önceki W25Q128JVSIQ adayı Winbond tarafından N / Not Recommended for New Design olarak işaretlendiği için yeni BOM’dan çıkarıldı.
- TLV3502 çift hızlı karşılaştırıcı, RAQM diferansiyel çıkış alma katmanı için koşullu aday olarak eklendi.
- FPGA/CML arasında doğrudan bağlantı engellendi; seviye/akım sürücü katmanı zorunlu kılındı.
- 484 konumluk FGG484 grid şablonu eklendi; ball numaraları ve işlevleri boş bırakıldı.
- KiCad sistem-seviyesi sayfa taslakları ve PCB stackup önerisi eklendi.
- Üretim öncesi doğrulama kapıları, açık riskler ve kabul testleri genişletildi.
