# RAQM-03C Sources & Provenance

1. **AMD Artix 7 FPGA Package Device Pinout Files portal** — official portal provides CSV/TXT package pinout ZIP; actual ZIP download was not available to this execution environment.  
   https://www.amd.com/en/developer/resources/adaptive-socs-and-fpgas/package-pinout-files/artix-7-package-device-pinout-files.html
2. **AMD UG475 v1.20 (2024-03-13)** — 7 Series FPGAs Packaging and Pinout, including FGG484 pinout/bank/power diagrams.  
   https://docs.amd.com/v/u/en-US/ug475_7Series_Pkg_Pinout
3. **AMD PG054 v3.3 (2024-12-06)** — Artix-7 PCIe integrated block; recommended XC7A35T FGG484 x1 lane-0 site X0Y3.  
   https://docs.amd.com/r/en-US/pg054-7series-pcie/Artix-7-Devices
4. **AMD DS181** — Artix-7 DC/AC characteristics; VCCINT/VCCBRAM 1.00V, VCCAUX 1.80V, GTP MGTAVCC 1.00V and MGTAVTT 1.20V nominal targets for supported speed grade.  
   https://docs.amd.com/r/en-US/ds181-artix-7-fpgas-data-sheet
5. **AMD Design Advisory 51017 (2026-11-03)** — GTP power sequencing guidance; MGTAVTT must not lead VCCINT/MGTAVCC.  
   https://docs.amd.com/r/en-US/51017/Solution
6. **TI TPS25947 product page and Rev. C datasheet (May 2026)** — 2.7–23V, 5.5A family, reverse polarity/reverse current blocking, adjustable current and inrush control.  
   https://www.ti.com/product/TPS25947  
   https://www.ti.com/lit/ds/symlink/tps25947.pdf
7. **TI TPS54302 product page and Rev. C datasheet (Mar 2026)** — 4.5–28V input, 3A synchronous buck, 400kHz, SOT-23-6.  
   https://www.ti.com/product/TPS54302  
   https://www.ti.com/lit/ds/symlink/tps54302.pdf
8. **TI TPS62130A product page** — 3–17V input, 0.9–6V output, up to 3A synchronous buck.  
   https://www.ti.com/product/TPS62130A
9. **Winbond 2025 Code Storage Flash Product Selection Guide** — W25Q128JVSSM: 128Mb, 2.7–3.6V, -40..125°C, SOP-8 208 mil, SPI/Dual/Quad, mass production status P.  
   https://www.winbond.com/export/sites/winbond/product-selection-guide/file/2025-Product-Selection-Guide-Winbond-Code-Storage-Flash-Memory.pdf
10. **Winbond W25Q128JVSIQ product page** — the prior baseline candidate is marked Industrial Status N; Winbond defines N as Not Recommended for New Design.  
   https://www.winbond.com/hq/product/code-storage-flash/qspi-nor/w25q-jv/?__locale=en&partNo=W25Q128JVSIQ
10. **TI TLV3502 product page** — dual high-speed comparator family, 2.7–5.5V supply, rail-to-rail input and push-pull output; typical family propagation delay 4.5ns.  
    https://www.ti.com/product/TLV3502
11. **KiCad Schematic File Format documentation** — native `.kicad_sch` S-expression format.  
    https://dev-docs.kicad.org/en/file-formats/sexpr-schematic/
12. **PCI-SIG CEM 6.0.1** — add-in-card mechanical/electrical requirements (full standard access may be restricted).  
    https://pcisig.com/PCIExpress/Spec/CEM/CardElectromechanical_6.0.1

## Third-party / user-reported inputs

- RAQM-02D/02E/02F/02G and 03A/03B project packages are carried forward as internal baseline snapshots, not external proof.
- User reports successful two-cell physical operation; this package contains no raw measurement evidence. Record as user-reported until scope captures and test logs are included.
- No unofficial pinout / board XDC was substituted for AMD's package file.
