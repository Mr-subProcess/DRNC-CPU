# Paket İçeriği

Bu paket toplam 46 dosya içerir.

| Dosya | Boyut (byte) |
|---|---:|
| `CHANGELOG_TR.md` | 1021 |
| `CHECKSUMS.sha256` | 4433 |
| `PACKAGE_FILE_INDEX_TR.md` | 1232 |
| `PACKAGE_MANIFEST.json` | 549 |
| `README_STATUS_TR.md` | 798 |
| `README_TR.md` | 3201 |
| `architecture/RAQM03C_DESIGN_FREEZE_TR.md` | 2752 |
| `baseline/RAQM-03B_PCIe_Component_Freeze_Design_Package.zip` | 2057327 |
| `components/RAQM03C_BOM_CANDIDATE.csv` | 2896 |
| `components/RAQM03C_COMPONENT_SELECTION_TR.md` | 1993 |
| `diagrams/01_PCIE_FPGA_SHEET.png` | 85659 |
| `diagrams/01_PCIE_FPGA_SHEET.svg` | 2521 |
| `diagrams/02_POWER_SHEET.png` | 79981 |
| `diagrams/02_POWER_SHEET.svg` | 2539 |
| `diagrams/03_RAQM_IF_SHEET.png` | 79376 |
| `diagrams/03_RAQM_IF_SHEET.svg` | 2611 |
| `diagrams/04_DEBUG_VALIDATE_SHEET.png` | 72487 |
| `diagrams/04_DEBUG_VALIDATE_SHEET.svg` | 2481 |
| `diagrams/RAQM03C_BOARD_ZONING.png` | 79193 |
| `diagrams/RAQM03C_BOARD_ZONING.svg` | 3015 |
| `diagrams/RAQM03C_CML_BOUNDARY.png` | 70494 |
| `diagrams/RAQM03C_CML_BOUNDARY.svg` | 3384 |
| `diagrams/RAQM03C_POWER_TREE.png` | 95463 |
| `diagrams/RAQM03C_POWER_TREE.svg` | 4107 |
| `diagrams/RAQM03C_SYSTEM_BLOCK.png` | 88629 |
| `diagrams/RAQM03C_SYSTEM_BLOCK.svg` | 4283 |
| `interfaces/RAQM03C_ASYNC_ACCEPTANCE.csv` | 1021 |
| `interfaces/RAQM03C_ELECTRICAL_BOUNDARY_TR.md` | 1642 |
| `interfaces/RAQM03C_PCIE_GT_CONTRACT.csv` | 761 |
| `kicad/RAQM03C/01_PCIE_FPGA.kicad_sch` | 3608 |
| `kicad/RAQM03C/02_POWER.kicad_sch` | 3627 |
| `kicad/RAQM03C/03_RAQM_IF.kicad_sch` | 3709 |
| `kicad/RAQM03C/04_DEBUG_VALIDATE.kicad_sch` | 3577 |
| `kicad/RAQM03C/KICAD_STATUS_TR.md` | 932 |
| `kicad/RAQM03C/RAQM03C.kicad_pro` | 98 |
| `kicad/RAQM03C/RAQM03C.kicad_sch` | 3525 |
| `pcb/RAQM03C_PLACEMENT_RULES.csv` | 614 |
| `pcb/RAQM03C_STACKUP_AND_ROUTING_TR.md` | 2651 |
| `pinout/FGG484_PINOUT_IMPORT_AND_REVIEW_TR.md` | 1694 |
| `pinout/RAQM03C_FPGA_NET_ASSIGNMENT_OPEN.csv` | 2075 |
| `pinout/XC7A35T_FGG484_GRID_TEMPLATE_484.csv` | 56905 |
| `power/RAQM03C_POWER_RAIL_MATRIX.csv` | 1475 |
| `power/RAQM03C_POWER_TREE_AND_SEQUENCE_TR.md` | 3616 |
| `references/SOURCES_03C.md` | 3310 |
| `validation/RAQM03C_RELEASE_GATES.csv` | 1648 |
| `validation/RAQM03C_RISK_REGISTER_TR.md` | 1470 |
