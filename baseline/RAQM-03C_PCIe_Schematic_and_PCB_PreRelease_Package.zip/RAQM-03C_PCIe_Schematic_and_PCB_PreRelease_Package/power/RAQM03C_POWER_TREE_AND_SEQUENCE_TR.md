# RAQM-03C Güç Ağacı ve Açılış Sırası

## Giriş

Ana giriş `+12V_SLOT`. J1 edge padları üzerinden kısa/akım sınırlama koruması sonrası `+12V_PROTECTED` oluşturulur. +3V3 slot hattı yalnızca resmi CEM pin planı ve power budget kararı sonrasında kullanılacaktır; bu revizyonda ana dönüşüm 12V üzerinden kurgulanmıştır.

## Önerilen ray ağacı

```text
PCIe +12V
   |
  F1  TPS25947 eFuse / hot-swap / reverse protection
   |
+12V_PROTECTED
   |
  U3 TPS54302 (12V -> 5V_MAIN)
   +---- filtered +5V_RAQM -> CML tile analog supply
   +---- U4 TPS62130A -> +1V0_VCCINT_VCCBRAM
   +---- U5 TPS62130A -> +1V0_MGTAVCC (separate clean branch)
   +---- U6 TPS62130A -> +1V2_MGTAVTT
   +---- U7 TPS62130A -> +1V8_VCCAUX
   |                   +-- MGTVCCAUX connection only if UG482/group rules approve
   +---- U9 TPS62130A -> +3V3_CONFIG / selected HR VCCO bank
```

Bu topoloji component candidate ağacıdır; elektriksel freeze değildir. Her buck kanalı için load current AMD Power Design Manager/Vivado raporundan alınmalıdır. Feedback, inductor, output capacitor, compensation (if applicable), soft-start and input cap values datasheet design procedure/calculator ile tamamlanır.

## Ray hedefleri

| Ray | Nominal | Kullanım | Durum |
|---|---:|---|---|
| +12V_PROTECTED | slot 12V | tüm kart ana güç | CEM budget + eFuse ayarı açık |
| +5V_MAIN | 5.0V | ara güç | TPS54302 adayı |
| +5V_RAQM | 5.0V | analog CML hücreler | filtre/ayrı regülatör ölçüme bağlı |
| VCCINT | 1.00V | FPGA core | DS181 target; akım açık |
| VCCBRAM | 1.00V | block RAM | aynı voltaj seviyesi; connection per DS181 |
| MGTAVCC | 1.00V | GTP analog | ayrı düşük gürültülü branch |
| MGTAVTT | 1.20V | GTP termination | AMD advisory sequence gate |
| VCCAUX | 1.80V | FPGA auxiliary | akım ve sequencing açık |
| MGTVCCAUX | 1.80V nominal class expected for 7-series GT AUX; confirm exact UG482 guidance | GTP auxiliary analog | package group/UG482 doğrulaması açık |
| VCCO_CONFIG/USER | bank-dependent, 3.3V only on selected HR bank | config and selected I/O | bank/ball map open |

## Power sequence state machine

1. PCIe slot 12V detected; F1 disabled/current-limited until UVLO and host insertion conditions valid.
2. F1 enable; current monitor and `PWR_IN_OK` qualify.
3. U4 VCCINT+VCCBRAM and U5 MGTAVCC start; ramp and PG monitored.
4. U6 MGTAVTT only after both VCCINT and MGTAVCC power-good. This follows AMD Design Advisory 51017; do not let MGTAVTT lead.
5. VCCAUX / VCCO / MGTVCCAUX sequencing finalized against DS181/UG482 and exact pin map; FPGA remains in reset until all required rails are valid.
6. PROGRAM_B released; configuration flash loads; INIT_B/DONE and configuration CRC/status verified.
7. PERST# deassertion and PCIe Gen1 link training; endpoint ready only after link-up.
8. RAQM +5V branch enabled; bias/reference settles; both cells receive clear/known-state procedure.
9. Driver outputs remain inhibit until `CELL0_READY && CELL1_READY`; REQ held inactive; then `RAQM_READY=1`.

## 03C power budget policy

- Board input target inherited from 03B: <=8W engineering target, not a PCIe compliance declaration.
- 8W at 12V is 0.667A ideal; at 90% conversion efficiency it is about 0.741A input. This is a planning estimate only; actual FPGA and analog current must be measured/estimated.
- eFuse limit must not be set to an arbitrary maximum: calculate from worst-case start-up + steady load + fault response + allowed slot power class.
- Regulator power dissipation and temperature must be checked at maximum ambient and airflow.
