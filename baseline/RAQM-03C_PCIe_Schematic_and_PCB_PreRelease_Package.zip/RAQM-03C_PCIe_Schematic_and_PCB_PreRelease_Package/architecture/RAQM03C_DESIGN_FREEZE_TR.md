# RAQM-03C Tasarım Dondurma Notu

## 1. Sistem tanımı

RAQM-03C, PCIe x1 slotundan komut alan, FPGA tabanlı PCIe endpoint/host bridge ve ayrı asenkron CML/RAQM tile alanı taşıyan masaüstü hızlandırıcı kartının ön tasarımıdır. RAQM'nin iki bit hücreli çekirdeği kullanıcı tarafından fiziksel olarak başarılı bildirildi; bu pakette bu başarıya ilişkin osiloskop ekranı, test log'u veya ölçüm dosyası bulunmadığından proje kaydı **user-reported bench success** olarak işaretlenmiştir.

## 2. FPGA/PCIe kararları

- Hedef parça: `XC7A35T-2FGG484C`.
- İlk bring-up: PCIe Gen1, x1, 2.5 GT/s.
- Lane 0 GTP site: `X0Y3` (PG054 tablosuna göre).
- Slot 100MHz REFCLK: GTP REFCLK girişine; genel RAQM clock'u değildir.
- Host veri yolu: ilk prototip BAR0 PIO/register + küçük command/result FIFO. DMA ikinci iterasyona bırakılır.
- PERST# ve FPGA configuration/reset birbirinden ayrılır; RAQM_READY yalnızca host link, FPGA config, power-good, analog bias ve cell-safe-state koşulları sağlanınca yükselir.

## 3. PCIe ile RAQM ayrımı

PCIe GTP çok yüksek hızlı dijital bağlantıdır. RAQM hücreleri analog/diferansiyel CML çalışma noktaları ve asenkron handshake alanıdır. İki alan fiziksel yerleşimde ve besleme dönüş yollarında ayrılmalıdır. FPGA I/O, CML giriş transistorlerinin bias common-mode seviyesine doğrudan bağlanamaz. Her B0/B1 write hattı için özel driver; her hücre çıkışı için diferansiyel receiver/comparator ve FPGA VCCO uyumlu mantık seviyesi gerekir.

## 4. Güç mimarisi

12V slot girişi TPS25947 ailesi eFuse ile korunur. TPS54302 ailesi 12V→5V ana ray için adaydır. 5V üzerinden ayrı buck kanalları ile VCCINT/VCCBRAM, MGTAVCC, MGTAVTT, VCCAUX/MGTVCCAUX ve seçilecek HR I/O/config bank VCCO beslemeleri oluşturulur. 5V_RAQM, 5V ana rayından ayrı filtrelenmiş branch olarak ayrılır. Regülatör çıkış current-limit, feedback dirençleri, inductor/capacitor değerleri AMD Power Design Manager ve TI hesaplayıcıları sonrası belirlenir.

## 5. Bilinçli olarak dondurulmayan öğeler

- FGG484 ball→signal listesi ve gerçek footprint pad mapping.
- Kullanıcı I/O bankı/ball ataması ve VCCO seçimi.
- GTP pin ball numaraları, AC-coupling capacitor final placement/value ve UG482 analog network.
- QSPI flash configuration mode/straps ve exact boot pin wiring.
- CML input driver transistor değerleri ve output comparator/level-shifter zinciri.
- Buck inductor, input/output capacitors, feedback network, soft-start/current limit values.
- PCIe edge pad dimensions, board thickness/bevel/plating, stackup dielectric/trace width.

Bu öğeler olmadan PCB netlist/footprint mapping üretmek güvenilir değildir.
