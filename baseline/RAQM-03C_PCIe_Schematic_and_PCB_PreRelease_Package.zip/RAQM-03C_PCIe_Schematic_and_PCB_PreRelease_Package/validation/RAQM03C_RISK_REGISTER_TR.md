# RAQM-03C Risk Register

| Risk | Impact | Mitigation / evidence |
|---|---|---|
| AMD official package pinout not imported | Wrong BGA pad assignment can destroy FPGA or board | Do not route until full 484-ball file imported and second-person audited |
| FPGA power estimate unknown | Undersized rails, brownout, thermal issues | AMD Power Design Manager with intended PCIe bitstream, then load-step test |
| CML input/output interface not characterized on card | Wrong common-mode/threshold causes bit errors | Measure successful two-cell bench unit; derive driver and receiver from real data |
| TLV3502 output at 5V | FPGA 3.3V bank overvoltage | Add validated 5V-to-3.3V adaptation; direct connect forbidden |
| Switching regulator noise coupling to CML | State errors/metastability | Isolated analog zone, filtering, controlled return, measure output spectrum/ripple |
| PCIe Gen1/Gen2 SI not closed | Link training failures | Start Gen1, fabricate controlled impedance coupons, eye/BER test before Gen2 |
| GTP sequencing error | Excess current / device stress | Enforce AMD advisory 51017 power-good gating and capture ramp traces |
| Power budget exceeds card/slot limit | Host slot overload | Use <=8W as internal design target only; calculate actual max and CEM class before release |
| Unqualified user-reported two-cell success | Architecture premise may not match measurable limits | Attach raw oscilloscope/logic analyzer records to validation archive |
