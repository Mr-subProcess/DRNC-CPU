# RAQM-03C — PCIe x1 Hızlandırıcı Kartı / Şematik ve PCB Ön Tasarım Paketi

**Sürüm:** 03C  
**Tarih:** 17 Kasım 2026  
**Durum:** Mühendislik ön tasarımı — FABRICATION HOLD  
**Önceki sürüm:** RAQM-03B (tam ZIP baseline olarak korunmuştur)

## Bu sürümün amacı

03B'deki PCIe x1 + Artix-7 mimarisini somut bileşen adaylarına, güç ağacına, arayüz elektrik sözleşmesine, BGA pin eşleme şablonuna, KiCad'de açılabilir sistem-seviyesi sayfalara ve PCB stackup/yerleşim kurallarına indirmek.

Bu paket, **tam pin-seviyeli elektrik şematiği veya üretime hazır PCB değildir**. AMD'nin resmi XC7A35T-FGG484 pinout ZIP'i bu üretim ortamında ikili olarak indirilemedi. Bu nedenle 484 BGA ball kimlikleri, güç pin adetleri ve kullanıcı I/O ball'ları uydurulmadı. KiCad dosyaları, elektriksel bağlantı üretmeyen sistem-seviyesi taslak sayfalardır; ERC/DRC temiz raporu iddia edilmez.

## En önemli kararlar

1. FPGA tasarım hedefi: `XC7A35T-2FGG484C`; PCIe x1 Gen1 bring-up.
2. AMD PG054'te XC7A35T FGG484 için lane 0 / GTP X0Y3 önerilir.
3. Slot REFCLK yalnızca GTP/PCIe alanında kalır; RAQM hücreleri clockless REQ/ACK ile çalışır.
4. PCIe ile RAQM arasında ayrı seviye/akım sürücüsü ve diferansiyel alıcı katmanı bulunur. FPGA LVCMOS pinleri CML transistor tabanlarına doğrudan bağlanmaz.
5. Winbond W25Q128JVSSM, üretim listesinde (P) görünen 128Mb QSPI NOR adaydır; Vivado boot-mode uyumluluğu doğrulanmadan dondurulmaz. 03B baseline içindeki W25Q128JVSIQ üretici sayfasında N / Not Recommended for New Design olarak işaretlidir; 03C ileriye dönük BOM’da kullanılmaz.
6. TPS25947 eFuse, TPS54302 12V→5V buck ve TPS62130A düşük gerilim buck ailesi güç adaylarıdır. Pasif değerler AMD güç tahmini ve regülatör tasarım hesaplayıcısı sonrası belirlenecektir.
7. TLV3502 çift karşılaştırıcı çıkış-alıcı adayıdır; CML OUT common-mode/swing ölçümleri ve 3.3V FPGA giriş uyarlaması doğrulanmadan seçilmiş parça sayılmaz.

## Paket yapısı

- `baseline/`: 03B'nin tam arşivi.
- `kicad/RAQM03C/`: KiCad'de açılabilir sistem-seviyesi sayfa taslakları; elektriksel netlist değil.
- `pinout/`: 484 konumluk BGA grid çalışma şablonu ve açık pin eşleme tablosu.
- `components/`: aday BOM, kaynak/uygunluk notları.
- `power/`: regülatör ağacı, raylar ve güç sıralama kabul matrisi.
- `interfaces/`: PCIe GTP, FPGA–RAQM arayüzü ve el sıkışma sözleşmesi.
- `pcb/`: altı katmanlı stackup önerisi, yerleşim ve SI gereksinimleri.
- `diagrams/`: sistem, güç, RAQM arayüzü ve board zoning çizimleri.
- `validation/`: açık doğrulama kapıları.

## Bu sürüm nasıl kullanılmalı?

Önce pinout grid'ini AMD'nin resmi Artix-7 package-pinout CSV/TXT dosyasıyla doldur; ardından Vivado Pin Planner ve UG475/UG482 üzerinden ikinci kişi incelemesi yap. Sonrasında gerçek KiCad sembol/footprint, pin-seviyeli şematik, ERC, PCB, DRC ve üretim çıktıları hazırlanabilir.

**Üretim uyarısı:** Bu paketten Gerber üretmeyin, FPGA'yı satın alma siparişine bağlamayın ve kartı anakart PCIe yuvasına takmayın. Release status: HOLD.
