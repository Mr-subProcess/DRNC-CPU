# FPGA ↔ RAQM Electrical Boundary

## Zorunlu topoloji

```text
FPGA 3.3V I/O
   |  B0/B1 logic commands + REQ/RESET
   v
CML INPUT DRIVER (separate transistor/current-steering stage)
   |  DATA_P / DATA_N at measured common-mode and differential swing
   v
RAQM bit cells B0 and B1
   |  OUT_P / OUT_N per cell
   v
Differential comparator / receiver (TLV3502 family only a candidate)
   |  if comparator uses 5V, add explicit 5V->3.3V logic adaptation
   v
FPGA 3.3V I/O

ACK / PAIR_VALID / FAULT -> FPGA async control bridge
```

## Electrical rules

- FPGA I/O pins must remain within bank VCCO/absolute input limits in powered and unpowered states.
- The 02D cell notes contain candidate common-mode and swing values, not qualified limits. Measure both B0 and B1 on the successful two-cell setup and attach scope/logic-analyzer records.
- No generic LVDS driver is assumed to match the RAQM CML input bias. LVDS common-mode/swing and the transistor input common-mode are different interfaces.
- Driver must present known safe inactive state when FPGA is unconfigured or any rail is down.
- Output receiver threshold/reference must be adjustable or calculated from measured OUT_P/N common-mode and differential amplitude.
- Comparator output voltage must be adapted to the actual FPGA bank VCCO. Never feed a 5V CMOS output to a 3.3V bank.
- Comparator propagation delay and driver delay become part of the asynchronous handshake timing budget. ACK must not be asserted until both data bits and validity qualifier are settled.
- Pair-valid generation requires same transaction generation for B0 and B1; no half-valid symbol may escape.
