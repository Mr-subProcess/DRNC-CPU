# 41 — Parça Seçimi, Güvenilirlik ve Derating

## 1. Aktif elemanlar

- BCM847BS: eşlenmiş NPN/NPN çifti; U_DATA, U_FB ve U_SEL için aday. Matched-pair özelliği yalnız tek paket içindeki TR1/TR2 çifti için kullanılabilir.
- BC847B: Q_TAIL için tek NPN aday.

Nexperia BCM847BS v8 datasheet'i 15.07.2026 tarihli olup VBE matching max 2 mV koşulunu VCE=5 V, IC=2 mA, Tamb=25 °C test koşulunda verir. Bu, 0.75 mA veya tüm sıcaklık aralığında 2 mV garantisi gibi yorumlanamaz. B0/B1 paketleri arası eşleşme garantisi de değildir.

## 2. Hız sınırı

BCM847BS datasheet grafiğinde fT tipik değerleri akıma bağlıdır; yaklaşık 1 mA'da 100 MHz, 3 mA'da 180 MHz ve 20 mA civarında tepe 270 MHz gösterilir. Bu değerler tipik karakteristiktir, hücrenin propagation delay'i veya maksimum çalışma frekansı değildir. Dolayısıyla pikosaniye gecikme, GHz throughput veya milisaniyenin altında çözüm iddiası bu parça seçimiyle desteklenmez.

## 3. Derating

- Mutlak maksimum VCEO/IC/Ptot değerleri tasarım hedefi olarak kullanılmaz.
- Her transistorun hesaplanan P_D, VCE ve IC değeri datasheet limitlerinin altında yeterli termal marjla kalmalıdır.
- SOT363-3 küçük package olduğundan PCB thermal copper/spacing ve reflow tasarımı önemlidir.
- Sıcaklık sweep: ilk karakterizasyon -10…+60 °C lab aralığı (oda sıcaklığı dışı ekipman varsa); ürün çalışma aralığı daha sonra tanımlanır.
- Her bit için bias ayrıdır; B0/B1 ortak threshold kabul edilmez.

## 4. Lot/alternate control

BCM847BS yerine generic BC847BS veya başka üreticinin SOT363 parçası pin-compatible ve matching-compatible varsayılmaz. Her substitute için pinout, package drawing, matching specs, frequency curves, SPICE model, availability ve thermal limits yeniden değerlendirilmelidir.
