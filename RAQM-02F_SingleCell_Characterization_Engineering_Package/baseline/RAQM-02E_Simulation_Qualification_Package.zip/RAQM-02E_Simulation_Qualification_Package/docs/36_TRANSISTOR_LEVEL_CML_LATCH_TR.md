# 36 — Tek Bit CML Latch: Transistor-Level Bağlantı Sözleşmesi

## 1. Bir hücrenin işlevi

Her bit hücresi bir statik iki-durumlu CML latch adayıdır. Akım, WE diferansiyel çifti üzerinden ya veri koluna ya da geri besleme koluna yönlendirilir. Böylece global clock olmadan WRITE/HOLD davranışı hedeflenir.

## 2. Alt bloklar

- `U_DATA`: BCM847BS eşlenmiş NPN çifti; bazlar D_P/D_N, emitörler E_D ortak, kolektörler OUT_P/OUT_N. D_P/D_N girişleri SMA merkezinden BJT bazına DC-coupled gelir; her base düğümü ayrıca 10 kΩ üzerinden VCM_DATA referansına bağlanır. Seri AC-coupling kondansatörü kullanılmaz.
- `U_FB`: BCM847BS eşlenmiş NPN çifti; bazlar FB_N/FB_P (çapraz), emitörler E_F ortak, kolektörler OUT_P/OUT_N.
- `U_SEL`: BCM847BS eşlenmiş NPN çifti; WE_P/WE_N ile E_D ve E_F kollarından hangisinin tail akımını alacağını seçer. WE girişleri de DC-coupled ve 10 kΩ VCM_WE referanslıdır. DATA/WE seviyeleri handshake süresince sabit kalabileceğinden araya seri kondansatör konulmaz.
- `Q_TAIL`: BC847B; U_SEL ortak emitöründen akım çeker.
- `R_LOAD_P/N`: VDD_CML ile OUT_P/OUT_N arasında kolektör yükleri.
- `R_FB`: OUT_P/OUT_N sinyallerini VREF_FB ile direnç bölerek FB_P/FB_N seviyelerine indirir.

## 3. İşlevsel yönler

`D_P > D_N` iken ve `WE_P > WE_N` koşulu sağlandığında DATA kolu seçilir. Bu örnek polaritede OUT_P aşağı çekilir, OUT_N yukarı kalır; mantıksal `STATE=1` tanımı `OUT_N - OUT_P` pozitif olduğunda kullanılır.

`WE_N > WE_P` olduğunda feedback kolu seçilir. Feedback bazları çapraz bağlanmıştır: OUT_P'den türetilen seviye FB_P üzerinden U_FB'nin TR2 bazına; OUT_N'den türetilen seviye FB_N üzerinden U_FB'nin TR1 bazına gider. Bu pozitif geri besleme durumun tutulmasını amaçlar.

## 4. Geri besleme seviye kaydırma

OUT düğümleri doğrudan U_FB bazlarına bağlanmaz. Her OUT için iki eşit değerli dirençten oluşan bölücü kurulur:

`FB = (OUT + VREF_FB) / 2`

Eşit R_FB_TOP ve R_FB_BOTTOM varsayımıyla geçerlidir. Bu, feedback baz ortak-modunu düşürür ve aktif transistorun kolektör-baz geriliminde pozitif marj bırakmayı hedefler. Gerçek marj, transistor-level DC/transient simülasyon ve ölçümle doğrulanmalıdır.

## 5. BCM847BS pin-net sözleşmesi

Üretici top-view pin eşlemesi: pin1=E1, pin2=B1, pin3=C2, pin4=E2, pin5=B2, pin6=C1. Bu pin dizilimi her Ux paketi için aşağıdaki netlistte uygulanmıştır.

## 6. Önemli sınırlamalar

- Bu topoloji bir analog/dijital BJT latch adayıdır; analog qudit veya quantum state değildir.
- Hücrenin çıkışlarından `ACK_CAPTURE` kendiliğinden üretilmez; capture qualification harici test fikstüründe yapılır.
- `PAIR_VALID` bu kartta üretilmez.
- Doğrudan 50 Ω çıkış yükü bağlanmaz; yüksek empedanslı diferansiyel prob kullanılır.
- Eşlenmiş BCM847BS transistörleri yalnız aynı paket içindeki çifte ilişkin eşleşme sağlar; B0 ile B1 arasında paketler arası matching garantisi değildir.

## 7. Netlist dosyası

`hardware/NETLIST_RAQM02D.csv`, U1–U6, Q1–Q2 ve pasiflerin tam pin/net eşlemesini verir. Bu tablo şematik CAD'e aktarılmadan önce bağımsız mühendislik kontrolünden geçmelidir.
