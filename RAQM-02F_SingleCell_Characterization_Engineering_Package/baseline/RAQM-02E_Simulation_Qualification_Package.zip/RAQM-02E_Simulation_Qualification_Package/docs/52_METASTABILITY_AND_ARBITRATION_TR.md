# 52 — Metastabilite, Kararsız Giriş ve Arbitration

## Risk
Diferansiyel çiftte giriş farkı sıfıra yaklaştığında iki kolun akım paylaşımı hassaslaşır. Pozitif geri beslemeli latch, karar süresini uzatabilir ve metastabilite benzeri uzun yerleşme davranışı gösterebilir.

## Karakterizasyon
- DATA farkını +150 mV'dan -150 mV'a küçük adımlarla tara.
- WE farkını aynı şekilde tara.
- Her noktada en az 1000 tekrar; kritik eşik çevresinde daha yüksek tekrar sayısı.
- Gürültü, giriş slew-rate ve iki giriş arasındaki skew değerlerini değiştir.
- Q'nun geçerli diferansiyel eşiğe ulaşma süresini dağılım olarak kaydet.
- Hiçbir tek ölçüm metastabilite olasılığının sıfır olduğunu kanıtlamaz.

## Mimari kural
- WE_P ≈ WE_N iken WRITE/HOLD kararı tanımsızdır.
- Harici handshake denetleyicisi WE farkını garanti etmeli ve Q valid penceresi tamamlanmadan ACK vermemelidir.
- Bu kartta ACK_CAPTURE ve PAIR_VALID üretilmez; test fikstürü tarafından ölçülür.
- İki bit için bağımsız Q valid sinyalleri geldikten sonra çift sembol geçerli sayılır.
