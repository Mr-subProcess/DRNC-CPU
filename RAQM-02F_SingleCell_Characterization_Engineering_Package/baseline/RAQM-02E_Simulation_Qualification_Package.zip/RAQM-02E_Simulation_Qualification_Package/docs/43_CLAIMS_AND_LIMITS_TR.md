# 43 — İddia ve Sınır Kaydı

## Desteklenen

- RAQM'nin clockless handshake kontrollü ön-hızlandırıcı çekirdeği hedeflediği.
- CML/BJT current steering'in araştırma dataplane adayı olduğu.
- Bu revizyonda iki tek-bit BJT latch için pin-net bağlantı sözleşmesi tanımlandığı.
- İki bitin birlikte dört klasik sembol (00, 01, 10, 11) gösterebileceği.
- History/recurrent bağlantıların state boundary üzerinden kurulması gerektiği.

## Desteklenmeyen / henüz doğrulanmayan

- Saniyede işlem, ps propagation, GHz throughput, düşük güç, analog solver yakınsaması.
- Fiziksel qudit veya kuantum süperpozisyon.
- RAM gerektirmeyen tam ölçekli genel amaçlı hesaplama.
- Üretim-ready PCB veya çalışır prototip iddiası.
- Pair-valid/C-element'in kart üzerinde uygulanmış olduğu.

## Kesin kapsam dışı

Bu sürümde programlama dili, compiler, firmware, host driver veya kod üretici bulunmaz.
