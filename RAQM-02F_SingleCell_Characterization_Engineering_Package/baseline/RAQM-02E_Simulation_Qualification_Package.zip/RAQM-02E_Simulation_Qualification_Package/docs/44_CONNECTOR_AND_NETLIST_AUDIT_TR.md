# 44 — RAQM-02D Konnektör ve Pin-Net Denetimi

## 1. Konnektör referansları

| RefDes | Sinyal | Görev |
|---|---|---|
| J1/J2 | B0_D_P / B0_D_N | Bit-0 veri diferansiyel girişi |
| J3/J4 | B0_WE_P / B0_WE_N | Bit-0 WRITE/HOLD seçimi |
| J5/J6 | B0_OUT_P / B0_OUT_N | Bit-0 yüksek empedanslı diferansiyel çıkış |
| J7/J8 | B1_D_P / B1_D_N | Bit-1 veri diferansiyel girişi |
| J9/J10 | B1_WE_P / B1_WE_N | Bit-1 WRITE/HOLD seçimi |
| J11/J12 | B1_OUT_P / B1_OUT_N | Bit-1 yüksek empedanslı diferansiyel çıkış |
| J13 | 2x5 header | İki bitin VBIAS, VCM_DATA, VCM_WE ve VREF_FB referansları |
| J14 | 2-pin power | +5 V nominal VDD_CML ve GND |

SMA `Center` sinyal temasıdır; `Shell` tüm montaj/şase temaslarının GND'ye bağlandığı mantıksal gösterimdir. Gerçek Samtec footprint pad numaraları seçilen CAD footprint'iyle doğrulanmadan üretim netlisti sayılmaz.

## 2. Netlist tanımının sınırı

`hardware/NETLIST_RAQM02D.csv`, transistor ve pasif elemanların pin-terminal/net eşlemesini incelemek için hazırlanmış bir **tasarım sözleşmesi CSV'sidir**. KiCad tarafından üretilmiş netlist değildir; ERC/DRC veya Gerber üretimi için doğrudan doğrulanmış kaynak olarak kullanılamaz.

## 3. RAQM-02C'den 02D'ye düzeltmeler

- `J1A/J1B` biçimindeki karışık çoklu referanslar, gerçek tekil SMA referansları `J1..J12` olarak düzeltildi.
- 2x5 bias header `J13`, güç girişi `J14` olarak ayrıldı.
- SMA giriş nets artık doğrudan `D_P/D_N/WE_P/WE_N` base nets'lerine bağlanır; `_SRC` ve AC-kuplaj ara düğümleri kaldırıldı.
- Seri giriş kondansatörleri kaldırıldı; DC seviyesi statik handshake boyunca korunur.
- Netlist satırlarında altı kolon ve benzersiz RefDes/pin çifti denetimi uygulandı.
- C_BULK güç kondansatörünün netlist bağlantısı eklendi.

## 4. Açık maddeler

SMA shell pad eşlemesi, J13/J14 üretici parça numarası, pin-1 yönü, footprint courtyard, creepage/clearance, PCB edge setback ve gerçek stackup üretici CAD/DFM incelemesi gerektirir. Bunlar çözülmeden connector pinout imalata serbest bırakılmaz.
