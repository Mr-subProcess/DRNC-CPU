# 38 — DC-Coupled Analog Arayüzler ve 4-Fazlı Handshake Sözleşmesi

## 1. Elektriksel arayüz

D_P/D_N, WE_P/WE_N ve Q_P/Q_N düğümleri CMOS 3.3 V GPIO değildir. DATA ve WRITE/HOLD girişleri **DC-coupled diferansiyel BJT arayüzleridir**. Seri AC-coupling kondansatörü yasaktır: dört-faz transferinde DATA ve WE seviyeleri ACK tamamlanana kadar sabit kalır; AC-coupling uzun süreli lojik seviyeleri droop ile söndürür.

Harici diferansiyel sürücü, `VCM_DATA≈4.16 V` ve `VCM_WE≈3.45 V` başlangıç ortak-mod seviyelerini doğrudan üretmeli ve diferansiyel amplitüdü BJT base pinlerinde ölçülerek ayarlanmalıdır. Bu VCM değerleri nominal başlangıç noktalarıdır; SPICE/bench olmadan kesin çalışma aralığı değildir. Her base düğümünden uygun VCM hattına 10 kΩ referans direnci bağlanır. 100 Ω diferansiyel sonlandırma doğrudan P/N giriş düğümleri arasındadır. Kaynak empedansı ve sürücü çıkış yapısına göre gerçek giriş amplitüdü ölçülmelidir.

## 2. Giriş seviyeleri ve korumalar

- DATA: `D_P/D_N`, DC common-mode `VCM_DATA` çevresinde.
- WRITE/HOLD: `WE_P/WE_N`, DC common-mode `VCM_WE` çevresinde.
- Q: `OUT_P/OUT_N`, yalnız yüksek empedanslı diferansiyel prob ile izlenir; başlangıç kuponunda 50 Ω output termination yoktur.
- Diferansiyel kaynak kapatılmadan veya kablo sökülmeden önce sürücü çıkışının DC seviyeleri güvenli idle seviyesine alınır.
- 3.3 V MCU GPIO doğrudan bağlanmaz. Host ancak seviye çevirici/diferansiyel sürücü üzerinden bağlanabilir.

## 3. Dört fazlı transfer

1. Sender D_P/D_N veri kodunu sabitler.
2. Sender WE_P>WE_N yaparak WRITE seçer ve PAIR_REQ yükseltir. DATA, ACK gelene kadar değişmez.
3. Receiver/fikstür Q_P/Q_N karar marjını ve common-mode penceresini `T_QUAL` boyunca doğrular; sonra ACK_CAPTURE yükselir.
4. Sender WE_N>WE_P ile HOLD'a geçer ve REQ'yu düşürür. DATA, ACK düşene kadar tutulur.
5. Receiver ACK'i düşürür; kanal idle olur.

Bu board'da REQ/ACK üretici/tüketici devresi entegre değildir; harici test fikstürü oluşturur. WE diferansiyel çifti latch'in WRITE/HOLD akım yönlendirmesini yapar.

## 4. Tek outstanding transaction

Her bit hücresinde yalnız bir aktif yazma isteği bulunur. Bir sonraki WRITE, önceki REQ/ACK dört-faz döngüsü tamamen sıfırlanmadan başlayamaz. Bu sürümde multi-token arbitration veya pipeline throughput iddiası yoktur.

## 5. WE geçiş aralığı

WE_P−WE_N sıfıra yaklaştığında steering çiftinin akımı iki kola bölünebilir. Bu aralıkta Q geçersizdir. Fikstür, yalnız ölçülen `|V_WE_DIFF|` guard-band dışındayken capture başlatır. Guard-band ve minimum pulse width SPICE ve bench sweep sonrasında dondurulur.

## 6. Output capture

ACK_CAPTURE, tek bir Q kenar geçişiyle verilmez. `|V_OUT_P−V_OUT_N| ≥ V_Q_MIN` ve `VCM_Q_MIN..VCM_Q_MAX` penceresi tanımlı `T_QUAL` boyunca korunmalıdır. Bu limitler henüz TBD'dir.

## 7. PAIR_VALID

02D kuponunda PAIR_VALID ve ACK arbiter bulunmaz. Harici fikstür aynı sembol transaction'ına ait iki ACK_CAPTURE sonucunu birleştirir. İki bitin de geçerli yakalanması ve fault-free durum olmadan PAIR_VALID yükselmez.
