# 46 — Power-Up, İlk State ve Fault Recovery

## 1. Power-up state belirsizliği

Çapraz bağlı iki kararlı state'e sahip latch'in ilk power-up state'i garanti edilmez. RAQM-02D kuponunda reset/preset devresi yoktur. Bu nedenle power-up sonrasında Q'nun 0 veya 1 olacağı varsayılmaz; `PAIR_VALID` harici fikstürde 0 tutulur.

## 2. İlk durum yükleme

1. GND ve +5 V rayını akım sınırlı laboratuvar kaynağıyla kur.
2. VREF_FB, VCM_DATA, VCM_WE ve VBIAS_TAIL kaynaklarını sırayla uygula.
3. DATA diferansiyel çiftine bilinen bir değer sür.
4. WE diferansiyel çiftini WRITE konumuna getir; Q diferansiyel output'un kararlı hale geldiğini ölç.
5. WE'yi HOLD'a getir. Q state'ini ve tail current'i kaydet.
6. Yalnız iki bit de ayrı ayrı capture-qualified olduktan sonra dış fikstürde PAIR_VALID yükseltilir.

## 3. Önerilen laboratuvar rail sırası

- Açılış: GND referansları → current-limited VDD_CML → VREF_FB → VCM_DATA/VCM_WE → VBIAS_TAIL → DATA/WE diferansiyel sinyalleri.
- Kapanış: DATA/WE idle → bias kaynakları → VDD_CML.
- İlk güç verme için +5 V hattında 10 mA başlangıç akım limiti önerilir; bu yalnızca kupon bring-up prosedürüdür, bileşen mutlak maksimum akımı değildir. Akım limitine oturursa hemen kes ve kısa devre/yanlış pin eşlemesini araştır.

## 4. Fault davranışı

Aşağıdaki olaylardan herhangi birinde PAIR_VALID=0 tutulur: rail out-of-range, tail current limit dışı, VCM/VREF fault, Q differential margin düşmesi, WE guard-band içinde kalma, timeout, iki bit ACK uyuşmazlığı veya güç reseti. Fault sonrası otomatik yeniden deneme yoktur; fikstür önce WE'yi HOLD/idle yapar, rail ve input durumunu doğrular, ardından bilinen DATA ile yeniden initialize eder.
