# 39 — Pair Valid ve Harici Test Fikstürü

## 1. Neden harici bırakıldı?

CML state-cell karakterizasyonu ve asynchronous control karakterizasyonu ayrı doğrulama problemleridir. Henüz transistor-level C-element/arbiter kararlı ve metastability-safe olarak doğrulanmadığından 02C'ye gömülmemiştir.

## 2. Test fikstürü işlevleri

- İki bit için bağımsız DATA ve WE diferansiyel sürücüleri.
- B0/B1 Q differential high-Z ölçümü.
- Her bit için ayrı ACK_CAPTURE comparator/qualification.
- Pair transaction kimliği ve timeout gözlemi.
- PAIR_VALID harici çıkışı.
- FAULT latch ve RESET_INHIBIT.

## 3. Pair-valid mantığı

`PAIR_VALID = ACK_B0_VALID AND ACK_B1_VALID AND SAME_TRANSACTION AND NOT_FAULT`

Bu ifade fonksiyonel şarttır; bu revizyonda gate-level veya transistor-level devre olarak sunulmaz.

## 4. Fault-safe koşullar

Aşağıdakilerden birinde PAIR_VALID=0 tutulur: ACK_B0/ACK_B1 eksik; transaction identity farklı; timeout; invalid input; bias rail dışında; Q margin kaybı; reset; iki hücreden birinde contention.

## 5. İleriki aşama

02D'de discrete transistor Muller C-element ve arbiter kuponu ayrı tasarlanacak. C-element test matrisi geçmeden pair-controller'ı dataplane kartına entegre etmeyin.
