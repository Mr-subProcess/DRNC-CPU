# 40 — PCB/Fabrication Kısıtları ve Üretici Arayüzü

## 1. Kart hedefi

İki tek-bit latch kuponu; dört katmanlı FR-4 prototip kartı. SMA edge-launch giriş/çıkışlar, harici bias header'ı ve yüksek empedanslı Q ölçümü.

## 2. Katman yığını (aday)

| Katman | İşlev |
|---|---|
| L1 | BJT-CML kısa analog bağlantıları, SMA merkez pinleri, DC-coupled diferansiyel girişler |
| L2 | Kesintisiz GND referans düzlemi |
| L3 | +5 V ve bias dağıtımı; dönüş akımlarını kesmeyecek şekilde |
| L4 | Düşük hızlı bias/monitor hatları ve test erişimi |

Kesin dielektrik kalınlıkları, bakır kalınlığı ve hat genişliği seçilen fabrikadan alınan gerçek stackup ile hesaplanır. 100 Ω diferansiyel giriş hattı için sabit milimetre genişliği bu dosyada verilmez; üretici field-solver sonucuyla belirlenir.

## 3. Route kuralları

1. Giriş diferansiyel çiftlerini L1 üzerinde ve kesintisiz L2 referans düzlemi üstünde tut.
2. Pair hatlarında L2 yarığı, via stub veya gereksiz layer transition oluşturma.
3. P/N yollarını aynı layer, benzer geometri ve yakın uzunlukta yönlendir; nihai skew bütçesi kenar hızı ölçüldükten sonra tanımlanır.
4. 100 Ω diferansiyel giriş sonlandırmalarını doğrudan DC-coupled P/N base girişleri arasında ve transistorlara yakın yerleştir. DATA/WE hatlarına seri AC-coupling kondansatörü koyma. Her base node için 10 kΩ VCM referans direnci bulunur.
5. Q çıkışlarına 50 Ω tek uçlu terminasyon koyma; yalnız yüksek empedanslı diferansiyel prob kullan. DATA/WE SMA merkezleri doğrudan BJT base girişlerine gider; harici sürücü doğru DC common-mode seviyelerini sağlamalıdır.
6. VDD decoupling'i hücreye yakın yerleştir; tail-current dönüşlerini analog input reference'tan ayır.
7. Her SOT363-3 footprint için pin-1 yönü ve reflow land pattern üretici çizimine göre kontrol edilir.
8. SMA edge-launch board-edge copper, ground tabs, board thickness ve connector launch geometry üretici CAD ile doğrulanır.
9. Tüm rail girişlerinde test point ve akım sınırlı besleme kullan.
10. PCB üretici stackup'ı sabitlenmeden trace width/spacing kesinleştirme.

## 4. Üretim dosyası statüsü

Bu revizyonda native KiCad schematic/PCB, Gerber, drill, IPC-356, BOM placement centroid veya assembly drawing üretilmemiştir. SVG kat planı ve şematik görseli üretim verisi değildir. Üreticiye gönderim kesinlikle HOLD'dur.

## 5. Minimum üretim çıktıları

Release aşamasında aynı CAD revision ve netlist hash'inden şu dosyalar dışa aktarılmalıdır: Gerber X2, NC Drill, IPC-356 netlist, BOM (MPN/Manufacturer/Qty/Refs), Pick-and-Place, assembly drawing, fabrication drawing, stackup/impedance note, solder stencil layer, panelization notu ve SHA-256 manifest.
