# 54 — Model Provenance ve SPICE Kapısı

## Üretici kaynakları
Nexperia BCM847BS ürün sayfası ve resmi datasheet, cihazın NPN/NPN eşlenmiş çift olduğunu ve SOT363-3 pin eşlemesini doğrular. Ancak bu paketin hazırlanması sırasında resmi, doğrulanmış BCM847BS SPICE model dosyası temin edilmedi.

BC847B tek transistor modelini BCM847BS eşlenmiş çiftin yerine kullanmak, matching davranışını temsil etmez. Başka üreticinin aynı isimli modelini de Nexperia modeli gibi sunmak doğru değildir.

## SPICE kapısının açılması için gerekenler
1. Exact ordering code ve üretici lotu kesinleştirilmeli.
2. Nexperia'dan model dosyası veya üretici onayı alınmalı.
3. Model lisansı ve revizyonu kaydedilmeli.
4. SOT363 pin mapping, model subcircuit pin order ile karşılaştırılmalı.
5. Model tek-transistor DC eğrileri datasheet ile kıyaslanmalı.
6. Eşlenmiş çift davranışı (ΔVBE / gain matching) modelde var mı doğrulanmalı.
7. Simülatör sürümü ve tolerans ayarları raporlanmalı.

## Simülasyon sonucu durumu
**NOT RUN — MODEL NOT AVAILABLE / SIMULATOR NOT INSTALLED IN BUILD ENVIRONMENT.**

Bu ifade başarısız simülasyon değil, henüz çalıştırılmamış simülasyon anlamına gelir.
