# 47 — Üretim Release Gate ve DFM Kapanış Listesi

Bu liste tamamlanmadan `RELEASED FOR FAB` statüsü verilemez. Mevcut RAQM-02D paketi **ENGINEERING CANDIDATE / FAB HOLD** durumundadır.

| Gate | Gerekli kanıt | Mevcut durum |
|---|---|---|
| G0 Architecture freeze | Netlist, pinout, protocol ve limits onaylı | Kısmi; elektriksel model aday |
| G1 Device model | Üretici SPICE modelleri, model uyum kontrolü | Açık |
| G2 DC operating point | Bütün transistorlar için VBE/VBC/VCE/IC/IB, güç ve PVT sweep | Açık |
| G3 Transient | WRITE/HOLD, startup, metastability, timeout, edge/slew sweeps | Açık |
| G4 Monte Carlo | Beta, VBE, resistor mismatch, temperature and supply corners | Açık |
| G5 Native schematic | KiCad schematic + ERC=0 unwaived errors | Üretilmedi |
| G6 Native PCB | KiCad PCB, placement, all routes, no unrouted nets | Üretilmedi |
| G7 DRC/DFM | DRC=0 unwaived errors; fab-specific min width/space/drill/copper | Çalıştırılmadı |
| G8 Signal integrity | SMA launch model, TDR/VNA, differential impedance and skew | Açık |
| G9 BOM procurement | Exact MPN, lifecycle, stock, alternates, package/footprint crosscheck | Kısmi; J13/J14 MPN TBD |
| G10 Assembly | Assembly drawing, centroid, stencil, polarity/pin-1, AOI plan | Üretilmedi |
| G11 Fabrication outputs | Gerber X2, NC drill, IPC-356, stackup, impedance note | Üretilmedi |
| G12 Bench validation | Functional, power, temperature, retention, error-rate tests | Açık |
| G13 Release audit | File hashes, independent review, revision lock and signed release | Açık |

**Release rule:** tüm gates kapalı, kritik riskler 0 açık, iki kişi tarafından bağımsız tasarım incelemesi tamamlanmış olmalıdır. Bu paket üreticiye gönderilmemelidir.
