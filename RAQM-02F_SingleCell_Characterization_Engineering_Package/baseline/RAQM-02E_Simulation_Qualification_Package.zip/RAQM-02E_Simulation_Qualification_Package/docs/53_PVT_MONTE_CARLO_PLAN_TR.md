# 53 — PVT ve Tolerans Doğrulama Planı

## Köşeler
- VDD: 4.5 V, 5.0 V, 5.25 V (ön tarama; kesin limit üretici datasheet kontrolüne tabidir)
- Ambient: -20 °C, 25 °C, 70 °C; ardından ürün hedef aralığına göre genişlet
- R_LOAD: nominal ve üretici tolerans uçları
- R_TAIL: nominal ve tolerans uçları
- R_FB oran hatası: eşleşmiş ve worst-case oran kombinasyonları
- BJT beta/VBE: üretici modelinin sağladığı köşe ve mismatch parametreleri
- Giriş diferansiyel genliği ve common-mode: ayrı ayrı taranmalı

## Monte-Carlo
Monte-Carlo yalnızca modelin mismatch parametreleri gerçekçi ve kaynağı belgeli ise anlamlıdır. BCM847BS eşleşme verisini iki ayrı paket arasındaki matching garantisi olarak kullanma. B0/B1 paketleri arası fark ayrıca ölçülmelidir.

## Çıktılar
- DC state separation
- Tail current variation
- VCE/VBC margin
- Q differential swing
- Write delay
- Hold retention drift
- Dissipation / estimated junction temperature
- Fail count / total trials

## Stop koşulları
- Herhangi bir transistor absolute maximum yaklaşımı
- B-C ileri kutuplanması
- Beklenmeyen yüksek akım
- Termal runaway eğilimi
- State kaybı veya çift state
- Simülatör convergence failure (bu da raporlanmalı, sessizce atlanmamalı)
