# 48 — Dört Sembollü Kodun Anlamı ve İddia Sınırı

RAQM-02D'nin iki fiziksel latch biti, `00`, `01`, `10`, `11` olmak üzere dört klasik dijital sembolü kodlar. Bu prototipte “qudit” sözcüğü çok-sembollü durum uzayına yönelik mimari isimdir; kuantum koherensi, süperpozisyon, dolaşıklık veya kuantum hesaplama performansı gösterilmiş değildir. İki bitin aynı anda geçerli sembol sayılması için harici PAIR_VALID fikstürü gerekir.

Her tek-bit latch bir diferansiyel çıkış çifti üzerinden tek state tutar. Bu devre analog seviyelerle çalışan BJT-CML fiziksel devresidir; fakat kullanıcıya sunulan state iki kararlı diferansiyel karar durumundan biridir. Dörtlü sembolün atomik kabulü, iki ayrı latch ve harici qualification protokolüyle yapılır.

Bu revizyonda kullanılan BCM847BS ve BC847B elemanları standart NPN BJT'lerdir. Tek bir üç-gate özel transistor üretilmiş değildir; DATA, feedback ve WRITE/HOLD select işlevleri üç ayrı diferansiyel çift (U_DATA, U_FB, U_SEL) arasında paylaştırılır. Kullanıcının üç-gate özel transistör fikri gelecekteki ayrı bir yarıiletken cihaz/üretim araştırmasıdır.

B0 ve B1 bit-cell'leri bu kartta birbirine recurrent çapraz bağlanmaz. Her bitin kendi lokal cross-coupled feedback latch'i vardır; iki hücre yalnızca harici fikstür tarafından aynı transaction için PAIR_VALID altında birleştirilir. Bu revizyon fiziksel mesh, cross-cell branch, fork/join network veya geçmiş epoch taşımasını henüz uygulamaz.

Bu revizyon ayrıca recurrent mesh, fiziksel rezonansla optimizasyon, self-organized solution, ultra-low latency veya işlemci yeteneğini kanıtlamaz. Önce tek hücre elektriksel olarak karakterize edilmeli, sonra iki hücre ve pair control entegre edilmeli, en son mesh ölçekleme yapılmalıdır.
