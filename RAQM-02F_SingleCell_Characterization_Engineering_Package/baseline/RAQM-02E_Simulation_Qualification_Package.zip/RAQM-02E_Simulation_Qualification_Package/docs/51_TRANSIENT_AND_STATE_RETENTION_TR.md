# 51 — WRITE/HOLD Transient ve State Retention

## Test dizisi
A. Güç ver; girişleri güvenli ortak-modda tut; Q çıkışlarının rastgele olabileceğini kabul et.
B. DATA=0 uygula, WRITE isteği gönder, çıkış yerleşene kadar bekle.
C. WRITE'ı kaldır; HOLD durumuna geç; DATA'yı değiştirmeden veya kontrollü biçimde değiştirerek Q'nun tutulduğunu doğrula.
D. DATA'yı tersine çevirirken HOLD'u koru; Q değişmemeli.
E. Yeniden WRITE uygula; Q yeni DATA durumuna geçmeli.
F. WRITE/HOLD arasında kontrollü overlap ve dead-zone testleri yap; yasak aralıkları ölç.
G. Beslemeyi kesip yeniden ver; power-on state davranışını kaydet.

## Kaydedilecek metrikler
- t_write_to_valid
- t_hold_settle
- Q diferansiyel genliği ve common-mode
- HOLD sırasında maksimum drift
- DATA/WE giriş ortak-modu ve diferansiyel genliği
- WRITE/HOLD overlap akımı
- Girişten çıkışa skew
- Gürültü altında yanlış state geçiş sayısı

## Kabul ilkeleri
- WRITE sırasında Q, DATA polaritesiyle tutarlı olmalı.
- HOLD sırasında DATA değişimi Q state'ini değiştirmemeli.
- Q, belirtilen test süresince tanımlanan minimum diferansiyel marjı korumalı.
- Belirsiz WE bölgesinde güvenilir yazma/hold garantisi verilmemeli; bu bölge harici kontrol protokolüyle dışlanmalı.
- Power-on reset davranışı tanımlanmadan `PAIR_VALID` yükseltilmemeli.
