# 37 — Bias, Akım ve Headroom: İlk Elektriksel Çalışma Noktası

## 1. Başlangıç rail'i

`VDD_CML=+5.0 V`, +3.3 V adayına göre üç transistor katmanına (data/feedback çifti, seçici çift, tail sink) daha geniş gerilim alanı bırakmak amacıyla seçilmiş başlangıç değeridir. 5 V üretim değeri olarak dondurulmamıştır.

## 2. Tail akımı

İlk yaklaşım:

`I_TAIL ≈ (VBIAS_TAIL - VBE_TAIL) / R_TAIL`

Nominal örnek: VBIAS_TAIL=1.00 V, VBE_TAIL varsayımı=0.65 V, R_TAIL=470 Ω ise I_TAIL≈0.745 mA.

Bu hesap bir çalışma noktası çözümü değildir. VBE; akım, sıcaklık ve cihazdan cihaza değişir. Üretimden önce her hücrenin tail akımı ölçülerek bias penceresi çıkarılmalıdır. İlk sweep: VBIAS_TAIL 0.80–1.20 V aralığında küçük adımlarla; sweep sırasında kolektör/emitör gerilimleri ve cihaz gücü kaydedilir. Güvenli sınır aşımı veya termal yükseliş görülürse sweep durdurulur.

## 3. Kolektör yükü

İlk yaklaşımda tek aktif kolun çıkış düşümü:

`ΔV_OUT ≈ I_TAIL × R_LOAD`

0.745 mA ve 470 Ω için ΔV_OUT≈0.350 V. Bu, tek-ended high/low farkı için başlangıç tahminidir. Gerçek diferansiyel swing, bölücü yükleri, transistor beta, akım paylaşımı, parazit ve prob yüküyle değişecektir.

## 4. Feedback divider

Her OUT_P/OUT_N hattından ayrı FB düğümüne 22 kΩ; FB düğümünden VREF_FB'ye 22 kΩ bağlanır. İdeal eşit dirençlerle:

`V_FB ≈ 0.5 × V_OUT + 0.5 × VREF_FB`

VREF_FB=3.50 V ve OUT düğümleri 5.00 V ile 4.65 V civarında olursa feedback bazları yaklaşık 4.25 V ve 4.075 V olur. Bu seviye kaydırma, cross-coupled on transistorun kollektörünün bazından yukarıda kalmasına yardımcı olacak şekilde seçilmiştir. Gerçek C-B margin simülasyon/ölçüm şartıdır.

## 5. Common-mode başlangıç değerleri

- VCM_DATA ≈ 4.16 V
- VCM_WE ≈ 3.45 V
- VREF_FB = 3.50 V
- VBIAS_TAIL ≈ 1.00 V

Diferansiyel DATA/WE girişleri DC-coupled olmalıdır. Dört-faz handshake sırasında DATA ve WE seviyeleri ACK alınana kadar statik tutulur; seri AC-coupling kondansatörü bu seviyeleri zamanla düşürür ve bu nedenle yasaktır. Harici diferansiyel sürücü VCM_DATA≈4.16 V ve VCM_WE≈3.45 V ortak-mod seviyelerini doğrudan sağlamalıdır. Her base düğümünden aynı VCM hattına 10 kΩ referans direnci bulunur; bu direnç sürücünün yerine geçmez. 100 Ω diferansiyel sonlandırma base düğümleri arasında, DC-coupled girişte bulunur. Gerçek diferansiyel amplitüd ve common-mode BJT base pinlerinde ölçülmelidir. İlk çalışma aralığı için `|V_D|` ve `|V_WE|` yaklaşık 80–150 mV diferansiyel aralıkta sweep edilebilir; bunlar sınanacak deney penceresidir, garantili logic threshold değildir.

## 6. Doyum ve headroom denetimi

Her transistor için DC op tablosunda şu büyüklükler kaydedilir: V_BE, V_BC, V_CE, I_C, I_B, güç. Özellikle U_FB'nin aktif transistöründe `V_C - V_B` marjı pozitif kalmalıdır; base-collector ileri kutuplanması ya da V_CE(sat) bölgesi hızlı CML kullanımı için risk olarak işaretlenir.

## 7. Başlangıç değerleri üretim reçetesi değildir

RL=470 Ω, RTAIL=470 Ω, RFB=22 kΩ ve 5 V yalnızca ilk SPICE/bench iterasyonunu başlatmak içindir. Model ve ölçüm olmadan kesin direnç/gerilim toleransı belirlenemez. Değerler sonradan değiştirilebilir olmalıdır; R_LOAD, R_TAIL, R_FB ve bias hatları için ölçüm/alternatif footprint korunur.
