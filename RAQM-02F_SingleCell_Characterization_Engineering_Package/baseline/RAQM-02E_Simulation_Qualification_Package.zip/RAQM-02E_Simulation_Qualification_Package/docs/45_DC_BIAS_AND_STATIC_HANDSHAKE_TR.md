# 45 — DC Bias, Statik Sinyal ve Asenkron Handshake Gereksinimleri

## 1. Neden DC-coupled?

RAQM latch'in WRITE/HOLD ve DATA girişleri yalnız kenar tetiklemeli değildir. WE, latch'in kuyruk akımını data çiftine veya feedback çiftine yönlendirir; HOLD süresince feedback kolu state'i tutar. Dört-faz handshake'te REQ ve ACK seviyeleri bir olay tamamlanana kadar sabit kalabilir. Seri kuplaj kondansatörü bu statik seviyeyi zaman sabiti üzerinden sıfıra doğru söndürür. Bu nedenle DATA ve WE portlarında AC coupling kullanılmaz.

## 2. Harici sürücü koşulları

- Her P/N hattı DC-coupled diferansiyel sürülür.
- DATA common-mode başlangıcı yaklaşık 4.16 V; WE common-mode başlangıcı yaklaşık 3.45 V'tur.
- Her VCM değeri gerçek transistor base pininde ölçülür; harici kaynak toleransı, kablo kaybı ve 50 Ω çıkış etkisi hesaba katılır.
- 100 Ω diferansiyel direnç P/N girişleri arasında yer alır. Sürücünün çıkış empedansı nedeniyle gerilim bölünmesi olabileceğinden kaynak ayarı değil, base-pin amplitüdü kabul ölçüsüdür.
- VCM reference dirençleri 10 kΩ ile base düğümlerine bağlanır; bunlar sürücünün yerini tutmaz.
- 3.3 V logic GPIO doğrudan bağlanmaz. Host arayüzü için uygun DC-coupled yüksek-ortak-mod diferansiyel line driver gerekir.

## 3. Giriş state kontrolü

DATA, WRITE ve HOLD seviyeleri test fikstürü tarafından açıkça belirlenir. WE_P≈WE_N bölgesinde state geçerli sayılmaz; bu aralık için `V_WE_GUARD` testle belirlenir. DATA, WRITE seçili olduğu andan ACK_CAPTURE'a kadar değişmez. HOLD'a geçmeden önce output qualification tamamlanmış olmalıdır.

## 4. Zamanlama bütçesi

Bu kartta global clock yoktur; fakat fiziksel gecikmeler vardır. Data setup, WE steering, output settle, qualification, ACK ve return-to-zero gecikmeleri ölçülür. Bunların toplamı latency'yi belirler. `picosecond` veya sub-nanosecond iddiası yapılmaz; test cihazı bandwidth'i ve cihaz veri sayfası ile sınırlı ölçüm bütçesi raporlanır.
