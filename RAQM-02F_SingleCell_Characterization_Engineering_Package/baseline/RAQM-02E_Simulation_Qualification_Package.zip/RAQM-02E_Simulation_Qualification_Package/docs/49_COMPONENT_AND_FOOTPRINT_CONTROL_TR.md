# 49 — Parça, Paket ve Footprint Kontrolü

## 1. BCM847BS

U1–U6, üçer diferansiyel çift (DATA, feedback, steering) için altı adet matched dual NPN paketidir. Nexperia ordering table/product data içinde BCM847BS,115 ve BCM847BS,135 packing suffix adayları listelenir; procurement release öncesi exact packing form distributor/producer ordering data ile teyit edilir. Nexperia BCM847BS v8 pin eşlemesi: 1=E1, 2=B1, 3=C2, 4=E2, 5=B2, 6=C1. Üretici footprint'i SOT363-3 olarak tanımlanır. 2 mV VBE matching yalnız datasheet'teki belirli akım/gerilim/sıcaklık test koşuluna aittir; iki ayrı BCM847BS paketinin birbirine 2mV matched olduğu anlamına gelmez.

## 2. BC847B

Q1/Q2 tail sink için aday NPN'dir. Nexperia product/series data içinde BC847B,215 ve BC847B,235 ordering suffix seçenekleri yer alır; exact reel/packing suffix sipariş öncesi doğrulanır. SOT23 pin eşlemesi üretici veri sayfasındaki pinout ile kontrol edilmelidir: 1=B, 2=E, 3=C.

## 3. Footprint/assembly

- SOT363-3 pad geometrisi, pin-1 yönü ve solder mask/paste üretici footprint çizimine göre birebir kontrol edilir.
- SOT23 footprint yönü ve pin-1 doğrulaması ikinci kişi tarafından gözden geçirilir.
- Samtec SMA-J-P-H-ST-EM1, 50 Ω board-edge/end-launch adayıdır; üretici CAD/series print exact orientation ve launch geometrisi için zorunludur. SMA edge launch footprint'i yalnız 1.6 mm kart kalınlığı varsayılarak seçilemez; Samtec exact CAD, board thickness ve pad/ground-tab geometrisi seçilen fab stackup ile eşleşmelidir.
- J13/J14 için kesin manufacturer MPN henüz seçilmediği için assembly BOM release edilemez.
- Rezistörlerin P/N eşleşmesi kritik: load çiftleri tercihen 0.1% tolerance ve aynı seri/lot; feedback divider çifti ratio-matched network veya eşlenmiş aynı seri kullanılmalıdır.
