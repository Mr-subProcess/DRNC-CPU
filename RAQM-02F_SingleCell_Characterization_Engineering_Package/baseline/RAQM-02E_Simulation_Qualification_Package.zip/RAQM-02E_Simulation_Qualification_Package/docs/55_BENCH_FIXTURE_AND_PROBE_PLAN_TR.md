# 55 — Laboratuvar Fikstürü ve Prob Planı

## Gerekli ekipman
- Akım sınırlamalı, ayarlanabilir 0–5.5 V DC kaynak
- En az iki kanallı diferansiyel osiloskop probu veya uygun diferansiyel ölçüm sistemi
- İki bağımsız diferansiyel DATA/WE sürücüsü (DC common-mode ayarlı)
- Düşük gürültülü VBIAS, VCM ve VREF kaynakları
- DMM; mümkünse akım ölçümü için düşük burden voltmetre/seri shunt
- Termal kamera veya temaslı sıcaklık sensörü
- Giriş/çıkış için kısa, kontrollü empedanslı kablo

## Ölçüm güvenliği
- İlk güç verme akım limiti 10 mA yalnızca laboratuvar başlangıç prosedürüdür; ürün akım spesifikasyonu değildir.
- VDD yokken giriş pinlerine yüksek seviye uygulama.
- 50 Ω osiloskop girişi doğrudan Q çıkışına bağlanmaz; yüksek empedanslı diferansiyel prob kullan.
- Bias kablolarında ortak toprak ve ground loop etkilerini kontrol et.
- Güç kesildikten sonra rail'lerin boşaldığını doğrula.

## Fikstür kanalları
- DATA0_P/N, WE0_P/N
- DATA1_P/N, WE1_P/N
- Q0_P/N, Q1_P/N
- VDD, VBIAS0/1, VCM_DATA, VCM_WE, VREF_FB
- Tail current monitor ve board temperature
