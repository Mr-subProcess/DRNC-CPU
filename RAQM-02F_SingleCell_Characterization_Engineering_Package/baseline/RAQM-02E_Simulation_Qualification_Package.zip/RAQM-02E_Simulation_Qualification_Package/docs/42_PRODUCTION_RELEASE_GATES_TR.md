# 42 — Üretim Release Gates

| Gate | Gereken kanıt | 02C durumu |
|---|---|---|
| G0 Architecture | Interface/polarity/functional rules frozen | Kısmen tanımlandı |
| G1 Pin-net | Independent pin/net audit, netlist match | Tasarım adayı var; bağımsız audit yok |
| G2 SPICE | Vendor models; DC/transient/PVT/mismatch | Açık |
| G3 Schematic | Native KiCad schematic, ERC clean | Açık |
| G4 PCB | Native KiCad PCB, routed, DRC clean | Açık |
| G5 SI/PI | Fab stackup, impedance, return path, parasitics | Açık |
| G6 BOM | Exact orderable MPN, supplier/lead time/alternates | Kısmen açık |
| G7 Fab pack | Gerber, drill, IPC-356, fab/assembly drawings | Açık |
| G8 Bench | Bring-up and all acceptance tests | Açık |
| G9 Release | Version/hash consistent, reviewer sign-off | HOLD |

Üretim onayı yalnız G0–G9 kapanınca verilir. 02C, G0/G1 tasarım çalışmasını ilerletir; diğer kapıların geçildiğini iddia etmez.
