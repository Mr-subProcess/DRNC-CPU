# 50 — Tek Hücre DC Çalışma Noktası Doğrulaması

## Amaç
U_DATA, U_FB, U_SEL ve Q_TAIL katlarının beklenen akım yönlendirmesini sağlayıp sağlamadığını, her transistorun güvenli aktif bölgede kalıp kalmadığını belirlemek.

## Ölçülecek her transistor değişkeni
- VBE = VB - VE
- VBC = VB - VC
- VCE = VC - VE
- IC, IB
- P = VCE × IC (işaret ve güç yönü simülatör konvansiyonuna göre raporlanır)
- Sıcaklık ve cihaz modeli/provenansı

## DC durumları
1. WRITE=0 / HOLD=1, DATA=0
2. WRITE=0 / HOLD=1, DATA=1
3. WRITE=1 / HOLD=0, DATA=0
4. WRITE=1 / HOLD=0, DATA=1
5. WE belirsiz bölgesi: WE_P ≈ WE_N
6. DATA belirsiz bölgesi: D_P ≈ D_N
7. Feedback başlangıç düğümleri eşit/ortak-mod

## Geçiş koşulları
- U_DATA ve U_FB çiftleri aynı anda anlamlı akım taşımamalı; overlap ve dead-zone ölçülmeli.
- U_SEL iki kol arasında akım yönlendirmeli; iki kol akımının toplamı tail akımına yakın olmalı.
- Aktif latch transistorunda B-C jonksiyonu ileri kutuplanmamalı.
- VCE(sat) bölgesine giriş, hızlı CML hedefi için başarısızlık/inceleme sebebidir.
- Her elemanın güç kaybı, üretici limitlerine ve sıcaklık azaltma eğrisine göre kontrol edilmelidir.

## Önemli
Bu belge kabul kriterlerini tanımlar; henüz DC sonucu içermez. Herhangi bir başlangıç bias değeri ölçümle doğrulanmış çalışma noktası olarak yorumlanamaz.
