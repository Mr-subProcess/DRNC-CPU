# RAQM-02E Teknik Kaynaklar

1. Nexperia, BCM847BS resmi ürün sayfası: https://www.nexperia.com/product/BCM847BS
2. Nexperia, BCM847BS resmi datasheet: https://assets.nexperia.com/documents/data-sheet/BCM847BS.pdf
3. Nexperia, BC847 ürün sayfası: https://www.nexperia.com/product/BC847

Kaynakların kullanım sınırı:
- Ürün sayfası ve datasheet pin dizilimi, paket ve mutlak maksimum bilgileri için kullanılır.
- Üretici model dosyası bulunmadığı için SPICE sonuçları türetilmemiştir.
- Tasarım değerleri 02D'deki başlangıç adaylarıdır; garanti edilmiş eşik veya üretim parametresi değildir.
