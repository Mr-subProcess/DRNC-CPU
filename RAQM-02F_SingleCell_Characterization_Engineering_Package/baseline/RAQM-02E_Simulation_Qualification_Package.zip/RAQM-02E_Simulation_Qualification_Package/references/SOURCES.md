# Kaynaklar ve Kullanım Haritası

1. **Nexperia — BCM847BS v8 Product Data Sheet, 15 July 2026**  
   https://assets.nexperia.com/documents/data-sheet/BCM847BS.pdf  
   Kullanım: matched dual NPN tanımı; per-device hFE; aynı paket içi hFE/VBE matching test koşulları; pin 1–6; SOT363-3 package outline; Fig.12 reflow solder footprint; tipik fT-current grafiği. Tipik fT eğrisi devrenin propagation delay veya maksimum toggle frekansını doğrudan vermez.  
   Bu dokümanın 2 mV VBE matching ifadesi yalnız datasheet'te belirtilen test koşullarında geçerlidir; başka akım/sıcaklığa genellenmemelidir.

2. **Nexperia — BC847x Series Product Data Sheet**  
   https://assets.nexperia.com/documents/data-sheet/BC847X_SER.pdf  
   Kullanım: BC847B tek NPN pinning; SOT23; pin 1=B, 2=E, 3=C.

3. **Nexperia — BCM847BS Product Page**  
   https://www.nexperia.com/product/BCM847BS  
   Kullanım: ürün durumu, matched NPN pair, uygulama ve paket sayfası.

4. **Samtec — SMA 50 Ω Board Connector Family**  
   https://www.samtec.com/products/sma  
   Kullanım: SMA 50 Ω konektör ailesi ve edge-mount seçenekleri; exact `SMA-J-P-H-ST-EM1` footprint/3D/CAD seçilen üretici modeliyle kontrol edilmelidir.

5. **Jens Sparsø — Introduction to Asynchronous Circuit Design, DTU Compute, 2020**  
   https://backend.orbit.dtu.dk/ws/portalfiles/portal/215895041/JSPA_async_book_2020_PDF.pdf  
   Kullanım: four-phase bundled-data, C-element, fork/join/merge ve asynchronous design ilkeleri. RAQM'nin özel kontrol devresi bu kaynağa göre doğrulanmış sayılmaz.

## Kaynak kullanımı sınırı

Üretici veri sayfası parçanın sınırlarını ve pinout'unu tanımlar; RAQM hücresinin fonksiyonel performansını garanti etmez. Tüm aday bağlantılar için simülasyon ve fiziksel test gerekir.

6. **Nexperia — BCM847BS official product page and ordering/product data** (checked 17 November 2026)
   https://www.nexperia.com/product/BCM847BS
   https://www.nexperia.com/chemical-content/BCM847BS.html
   Kullanım: product status, matched dual NPN package and available ordering suffixes BCM847BS,115 / BCM847BS,135. Packing code and distributor availability must be confirmed at purchase.

7. **Samtec — SMA-J-P-H-ST-EM1 official product page** (checked 17 November 2026)
   https://www.samtec.com/products/sma-j-p-h-st-em1
   Kullanım: 50 Ω SMA connector family and end-launch configuration; exact CAD/series print and PCB thickness must be checked before footprint freeze.

8. **Nexperia — BC847B official product page / BC847x series** (checked 17 November 2026)
   https://www.nexperia.com/product/BC847B
   https://www.nexperia.com/products/bipolar-transistors/general-purpose-and-low-vcesat-bipolar-transistors/single-bipolar-transistors/single-bipolar-transistors-100-v/series/BC847X-SERIES.html
   Kullanım: SOT23 product family and candidate orderable packing suffixes; datasheet pinout remains the authority for footprint connection.
