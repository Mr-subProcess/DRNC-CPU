# RAQM-02D Bring-up Checklist

## Before power
- [ ] U1–U6 exact MPN and SOT363-3 orientation checked.
- [ ] Q1/Q2 SOT23 pinout checked (B=1, E=2, C=3 for Nexperia BC847B).
- [ ] R_LOAD/R_FB/R_TAIL values and continuity verified.
- [ ] No +5V-to-GND short; resistance recorded.
- [ ] Bench supply current limit initially set very low and increased only under review.
- [ ] All DATA/WE sources disabled before applying rail.
- [ ] Q outputs connected only to high-impedance differential probes.

## Bias
- [ ] +5V rail ramp monitored.
- [ ] Tail VBIAS starts at low end of sweep.
- [ ] VCE/VBE and tail current recorded per bit.
- [ ] DATA/WE common-mode applied only after tail operating point is safe.
- [ ] Feedback divider nodes FB_P/FB_N measured.

## Functional
- [ ] Data polarity check.
- [ ] WRITE/HOLD selection check.
- [ ] Hold with changing data.
- [ ] All four pair symbols.
- [ ] External pair-valid and missing-ACK fault tests.

## Stop conditions
- Unexpected supply current; visible/thermal heating; VCE/VBE outside datasheet limits; output oscillation; bias instability; any unexplained state transition. Disable supply and investigate. Do not continue sweeping.


## RAQM-02D ilaveleri
- [ ] DATA/WE kablolarının DC common-mode ayarı doğrulandı; seri kuplaj kapasitörü bulunmadığı görsel olarak kontrol edildi.
- [ ] Base pinlerinde VCM_DATA/VCM_WE ve diferansiyel amplitüd ölçüldü.
- [ ] Bilinen state ilk WRITE ile kuruldu; power-up random state hiçbir zaman valid sayılmadı.
- [ ] DATA/WE uzun HOLD boyunca statik tutuldu; output ve bias drift kaydedildi.
- [ ] J1..J14 pinout netlist/PCB/assembly arasında eşleşiyor.
