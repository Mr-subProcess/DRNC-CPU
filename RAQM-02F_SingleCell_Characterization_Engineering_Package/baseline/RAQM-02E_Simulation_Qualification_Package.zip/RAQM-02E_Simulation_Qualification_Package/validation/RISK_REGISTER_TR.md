# Risk Register — RAQM-02D

| ID | Risk | Severity | Mitigation / evidence needed | State |
|---|---|---|---|---|
| R1 | BJT CML latch has no validated transistor-level model | Critical | Vendor model, DC/transient, bench correlation | Open |
| R2 | Feedback divider common-mode/margin wrong | Critical | Verify VCB, VCE and startup across PVT | Open |
| R3 | Base common-mode sources cannot drive expected levels | High | Define actual differential driver/bias fixture | Open |
| R4 | Tail current variation due VBE/temp/beta | High | Sweep + per-cell calibration | Open |
| R5 | B0/B1 offset mismatch | High | Individual bias/threshold calibration | Open |
| R6 | Pair-valid not onboard | Medium | Explicit external fixture; future separate C-element coupon | Controlled |
| R7 | SMA launch footprint/board thickness mismatch | High | Samtec CAD, fab stackup, launch review | Open |
| R8 | 100Ω termination mismatched with source | High | Confirm driver impedance and measure amplitude at PCB pins | Open |
| R9 | Q output loading/read-disturb | High | High-Z differential probes only; loading sweep | Controlled |
| R10 | Generic footprint differs from SOT363-3 v8 pattern | Critical | Manufacturer land-pattern overlay | Open |
| R11 | No routed KiCad PCB / no DRC | Critical | Native CAD and independent review | Open |
| R12 | Component fT does not support claimed ultrafast operation | High | Remove speed claims; measure; select RF transistor if needed | Controlled |

| R13 | Power-up latch state is undefined | High | PAIR_VALID held low; initialize both bits with known WRITE before use | Open |
| R14 | External driver DC common-mode mismatch | Critical | Define driver electrical spec; measure VCM at BJT bases under load | Open |
| R15 | DC-coupled WE transition through indeterminate region | High | Characterize V_WE guard-band and require capture inhibit there | Open |
| R16 | No reverse-polarity or overvoltage protection at J14 | High | Add protection after supply range and dropout budget are known | Open |
| R17 | Bias header pin orientation/MPN unspecified | High | Freeze exact J13 MPN, pin-1 and mating connector before CAD release | Open |
| R18 | SMA launch geometry not tied to fabricator stackup | High | Import exact Samtec CAD; verify board thickness, solder tabs and return path | Open |
