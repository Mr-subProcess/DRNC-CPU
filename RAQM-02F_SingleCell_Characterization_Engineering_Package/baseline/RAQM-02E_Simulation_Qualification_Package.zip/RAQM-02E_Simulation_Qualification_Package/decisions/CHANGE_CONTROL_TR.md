# Change Control

- Önceki RAQM-02B paketi `baseline/` içinde değişmeden korunur.
- Bu paketteki pin-net değişiklikleri için design reviewer onayı gerekir.
- BCM847BS/BC847B veya package alternate değişirse pinout ve footprint tekrar kontrol edilir.
- Her bias/direnç değişikliğinde SPICE sweep ve acceptance matrix güncellenir.
- Gerber yalnız final KiCad schematic ve PCB aynı revizyon/hashi taşıdığında dışa aktarılır.
- 02C status: ENGINEERING CANDIDATE / FABRICATION HOLD.
