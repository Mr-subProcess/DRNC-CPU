# RAQM-02D Design Decision Register

| ID | Karar | Gerekçe | Durum |
|---|---|---|---|
| D-020C-01 | İki bit-cell fiziksel olarak bağımsız tutulur | Offset/bias ayrı karakterize edilecek | Adopted |
| D-020C-02 | Her bit U_DATA + U_FB + U_SEL + Q_TAIL topolojisini kullanır | Explicit transistor-level current steering | Candidate |
| D-020C-03 | Feedback base doğrudan OUT'a bağlanmaz | B-C forward bias/saturation riskini azaltmak | Candidate; SPICE required |
| D-020C-04 | +5 V rail ilk sweep adayıdır | Headroom ihtiyacı | Candidate; bench required |
| D-020C-05 | Pair-valid harici test fikstüründe kalır | C-element henüz doğrulanmadı | Adopted |
| D-020C-06 | Differential inputs 100 Ω termination candidate | Controlled source interface | Candidate |
| D-020C-07 | Q outputs high-Z only | Read-disturb ve swing kaybını azaltma | Adopted |
| D-020C-08 | No compiler or firmware | Software comes only after hardware semantics freeze | Adopted |
| D-020C-09 | Manufacturing release remains HOLD | No SPICE/ERC/DRC/Gerber/bench results | Mandatory |
