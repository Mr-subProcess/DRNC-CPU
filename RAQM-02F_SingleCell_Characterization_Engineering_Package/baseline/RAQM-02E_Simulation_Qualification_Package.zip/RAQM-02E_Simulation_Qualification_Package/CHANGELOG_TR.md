# RAQM-02E Değişiklik Kaydı

- RAQM-02D baseline değişmeden `baseline/` altında korundu.
- Üretici SPICE modeli bulunmadan simülasyon sonucu iddia edilmesi yasaklandı.
- Tek-bit hücre için DC operating-point, transient, startup, metastability ve PVT doğrulama kapıları tanımlandı.
- Her transistor için VBE, VBC, VCE, IC, IB ve güç kayıt tablosu eklendi.
- State-retention testinde güç, sıcaklık, veri ve WE seviyeleri ayrı ayrı taranacak.
- PCB üretiminden önce ölçülebilir test noktaları ve yüksek empedanslı prob gereksinimleri netleştirildi.
- Yazılım/derleyici/kod üretici eklenmedi.
- Bu sürümde gerçek SPICE simülasyonu, ERC/DRC veya Gerber üretimi yapılmadı.
