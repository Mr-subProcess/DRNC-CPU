# Footprint ve Assembly Kontrol Listesi

## BCM847BS / SOT363-3

- Manufacturer: Nexperia, datasheet v8 dated 15 July 2026.
- Top-view pin order: upper row 6-5-4; lower row 1-2-3.
- Pin functions: 1=E1, 2=B1, 3=C2, 4=E2, 5=B2, 6=C1.
- Package outline nominal body approximately 2.1 × 1.25 × 0.95 mm; 0.65 mm lead pitch.
- Use the datasheet's Fig. 12 reflow footprint `sot363-3_fr`; drawing includes a 2.65 × 2.35 mm occupied/pad pattern envelope. Do not reuse generic SOT363 library footprint without checking the current SOT363-3 mechanical/land-pattern drawing.
- Reflow is the manufacturer's recommended soldering method.
- Assembly drawing must show pin-1 mark at lower-left in the stated top-view orientation.

## BC847B / SOT23

- Nexperia pin mapping: 1=B, 2=E, 3=C.
- Check courtyard, pad size, pin-1 marker and orientation against the selected manufacturer's package drawing.

## General assembly

- MSL/reflow profile must be taken from current manufacturer packaging data.
- Use lead-free paste and reflow profile approved by board assembler.
- AOI should inspect each SOT363-3 for bridges/rotation; inspect thermal/reflow quality on first article.
- First article: photograph top side, continuity test, resistance-to-ground, power-off net checks before power-up.
- This document is not a native KiCad footprint library; CAD footprint sign-off remains open.
