# PCB Layout / Fab Status — RAQM-02D

| Deliverable | Status | Notes |
|---|---|---|
| Two-cell system block diagram | Available (SVG/PNG) | Architecture only |
| One-bit transistor schematic drawing | Available (SVG/PNG) | Pin-net candidate; not CAD-native |
| PCB floorplan drawing | Available (SVG/PNG) | Concept placement; no routed copper |
| Pin-to-net CSV | Available | Must be reviewed against schematic |
| BOM candidate | Available | MPN and sourcing still to freeze |
| Native KiCad schematic | Not generated | EDA tool not available in this build environment |
| Native KiCad PCB | Not generated | No routed board |
| ERC/DRC | Not run | Must be done in KiCad |
| Gerber X2 / drill | Not generated | Do not manufacture |
| IPC-356 | Not generated | Do not manufacture |
| Pick-and-Place / assembly | Not released | Coordinates in floorplan are conceptual only |
| Fab stackup | Not frozen | Request stackup from actual fabricator |

**Release status: HOLD.**
