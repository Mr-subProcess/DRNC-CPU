# Paket Manifestosu — RAQM-02B

| Alan | Değer |
|---|---|
| Sürüm | RAQM-02B |
| Paket | RAQM-02B_SymbolPair_Architecture_Package.zip |
| Tarih | 17.11.2026 |
| Önceki sürüm | RAQM-02A |
| Hedef | İki-bit sembol çifti + recurrent mesh arayüz sözleşmesi |
| Kod içeriği | Yok |
| PCB üretim verisi | Yok; konsept kat planı var |
| Simülasyon/ölçüm sonucu | Bu revizyonda yeni fiziksel sonuç yok |

## Dosya listesi

- `README_TR.md`, `CHANGELOG_TR.md`, `PACKAGE_MANIFEST_TR.md`
- `docs/21`–`docs/35`: mimari ve elektriksel şartname
- `hardware/`: 3 adet SVG/PNG blok/PCB konsept çizimi, BOM, pinout ve arayüz tabloları
- `validation/`: test matrisi, bring-up, release gate
- `decisions/`: normatif karar günlüğü
- `references/`: bağlantılar ve kaynak-kullanım açıklaması
- `baseline/`: RAQM-02A tam paket kopyası (içinde RAQM-01C önceki baseline'ı da bulunur)
- `CHECKSUMS.sha256`: paketteki her dosyanın SHA-256 özeti (bu dosya hariç)

## Sürüm kapsamı ve eksiklerin beyanı

Bu paket belge, mimari ve PCB konsepti bakımından eksiksizdir. Üretime hazır şematik/PCB değildir. Transistor-level SPICE, gerçek netlist, ERC/DRC, yerleşim sonrası parazit analizi ve bench ölçümü yapılmadan PCB üretimi için onay verilmez.
