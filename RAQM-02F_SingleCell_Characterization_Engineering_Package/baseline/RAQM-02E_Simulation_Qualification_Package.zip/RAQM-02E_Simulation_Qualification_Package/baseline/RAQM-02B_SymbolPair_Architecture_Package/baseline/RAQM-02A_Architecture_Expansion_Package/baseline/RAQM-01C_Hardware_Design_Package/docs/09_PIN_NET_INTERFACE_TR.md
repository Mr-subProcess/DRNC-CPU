# 09 — Pin ve Net Arayüzü

## 1. Host J1 — 2×12, 2,54 mm

| Pin | Net | Yön | Not |
|---:|---|---|---|
| 1 | DATA0_A | Host→kart | N0 aday A |
| 2 | DATA0_B | Host→kart | N0 aday B |
| 3 | DATA1_A | Host→kart | N1 aday A |
| 4 | DATA1_B | Host→kart | N1 aday B |
| 5 | DATA2_A | Host→kart | N2 aday A |
| 6 | DATA2_B | Host→kart | N2 aday B |
| 7 | DATA3_A | Host→kart | N3 aday A |
| 8 | DATA3_B | Host→kart | N3 aday B |
| 9 | SEL0 | Host→kart | N0 seçim |
| 10 | SEL1 | Host→kart | N1 seçim |
| 11 | SEL2 | Host→kart | N2 seçim |
| 12 | SEL3 | Host→kart | N3 seçim |
| 13 | REQ | Host→kart | Dört-fazlı request |
| 14 | HOST_VALID_TEST | Host→kart | Sadece test modu; completion kanıtı değildir |
| 15 | ACK | Kart→host | C-element/receiver onayı |
| 16 | OUT0 | Kart→host | Qudit-A alt biti |
| 17 | OUT1 | Kart→host | Qudit-A üst biti |
| 18 | OUT2 | Kart→host | Qudit-B alt biti |
| 19 | OUT3 | Kart→host | Qudit-B üst biti |
| 20 | NC | — | Host +3V3 ile kart beslemesini paralelleme |
| 21 | GND | Ortak | GND |
| 22 | GND | Ortak | GND |
| 23 | NC / Future RESET_N | — | Bu revizyonda bağlanmaz |
| 24 | NC / Future FAULT_N | — | Bu revizyonda bağlanmaz |

## 2. J2 — kart beslemesi

| Pin | Net | Açıklama |
|---:|---|---|
| 1 | +3V3 | Harici regüle 3,3 V; kaynak kapasitesi en az 1 A önerilir |
| 2 | GND | Ortak referans |

**5 V doğrudan bağlanmaz.** Akım limiti ilk güç açılışında düşükten başlatılır.

## 3. J4 — VTT beslemesi

| Pin | Net | Açıklama |
|---:|---|---|
| 1 | VTT | 1,30 V nominal; sink kapasitesi ≥0,4 A doğrulanmış kaynak |
| 2 | GND | Ortak referans |

Standart güç kaynağının akım sink özelliği doğrulanmadan J4'e bağlanması yasaktır.

## 4. J3 — diferansiyel ölçüm çıkışları

| Pin | Net |
|---:|---|
| 1 | N0_P |
| 2 | N0_N |
| 3 | N1_P |
| 4 | N1_N |
| 5 | N2_P |
| 6 | N2_N |
| 7 | N3_P |
| 8 | N3_N |

J3 yüksek hızlı ölçüm içindir. Kısa bağlantılı, yüksek empedanslı diferansiyel prob kullanılmalıdır; uzun jumper kablo ve standart 10× tek-uçlu probla yüksek hızlı hat üzerinde ölçüm yapılmaz.

## 5. MC100EP56 pin bağlantı özeti

20 pin TSSOP üst görünüşüne göre:

| Pin | Sinyal | RAQM-01C bağlantı |
|---:|---|---|
| 1 | D0a | N0_A_P / U5; N2_A_P / U6 |
| 2 | D̅0a | N0_A_N / U5; N2_A_N / U6 |
| 4 | D0b | N0_B_P / U5; N2_B_P / U6 |
| 5 | D̅0b | N0_B_N / U5; N2_B_N / U6 |
| 6 | D1a | N1_A_P / U5; N3_A_P / U6 |
| 7 | D̅1a | N1_A_N / U5; N3_A_N / U6 |
| 9 | D1b | N1_B_P / U5; N3_B_P / U6 |
| 10 | D̅1b | N1_B_N / U5; N3_B_N / U6 |
| 11 | VEE | GND |
| 12/13 | Q̅1/Q1 | N1_N/N1_P; N3_N/N3_P |
| 14/20 | VCC | +3V3 |
| 15 | SEL1 | SEL1 / SEL3 |
| 16 | COM_SEL | GND |
| 17 | SEL0 | SEL0 / SEL2 |
| 18/19 | Q̅0/Q0 | N0_N/N0_P; N2_N/N2_P |
| 3/8 | VBB0/VBB1 | Kullanılmıyorsa açık; üretici talimatına uygun |

**Dikkat:** EP56 tüm VCC ve VEE pinlerinin harici bağlanmasını ister. VBB pinleri çıkış referanslarıdır; kullanılmıyorlarsa açık bırakılır ve başka devreye yüklenmez.

## 6. MC100EPT22 pin bağlantı özeti

| Pin | Sinyal | İşlev |
|---:|---|---|
| 1 | Q0 | İlk kanal P |
| 2 | Q̅0 | İlk kanal N |
| 3 | Q1 | İkinci kanal P |
| 4 | Q̅1 | İkinci kanal N |
| 5 | GND | GND |
| 6 | D1 | Tek uçlu DATAx_B |
| 7 | D0 | Tek uçlu DATAx_A |
| 8 | VCC | +3V3 |

## 7. MC100EPT23 pin bağlantı özeti

| Pin | Sinyal | İşlev |
|---:|---|---|
| 1 | D0 | İlk çift P |
| 2 | D̅0 | İlk çift N |
| 3 | D̅1 | İkinci çift N |
| 4 | D1 | İkinci çift P |
| 5 | GND | GND |
| 6 | Q1 | İkinci host çıkışı |
| 7 | Q0 | İlk host çıkışı |
| 8 | VCC | +3V3 |

Bu özet üretici pinout'una göre hazırlanmıştır; üretim öncesi pin-1 yönü ve footprint pad numarası CAD içinde tekrar kontrol edilmelidir.

## 8. Kontrol C-element pin bağlantısı (U9/U10)

U9=SN74LVC08A AND, U10=SN74LVC32A OR kullanılarak aşağıdaki geri beslemeli denklem kurulur:

`ACK_next = (REQ AND HOST_VALID_TEST) OR (ACK_prev AND (REQ OR HOST_VALID_TEST))`

| İşlev | U9 pin/net | U10 pin/net |
|---|---|---|
| REQ girişi | 1 / REQ | 1 / REQ |
| HOST_VALID_TEST girişi | 2 / HOST_VALID_TEST | 2 / HOST_VALID_TEST |
| REQ AND VALID | 3 / C_BOTH | 4 / C_BOTH |
| REQ OR VALID | 5 / C_ANY | 3 / C_ANY |
| ACK AND (REQ OR VALID) | 4=ACK, 5=C_ANY → 6=C_HOLD | 5=C_HOLD |
| ACK çıkışı | — | 6 / ACK |

U9 pin 7 ve U10 pin 7 GND; pin 14'ler +3V3'tür. Kullanılmayan kapı girişleri GND'ye bağlanır, kullanılmayan çıkışlar NC bırakılır. Bu tablo board-level net export ile birlikte çapraz kontrol edilmelidir. C-element başlangıç ve hazard testleri `04_ASYNCHRONOUS_HANDSHAKE_TR.md` içindedir.
