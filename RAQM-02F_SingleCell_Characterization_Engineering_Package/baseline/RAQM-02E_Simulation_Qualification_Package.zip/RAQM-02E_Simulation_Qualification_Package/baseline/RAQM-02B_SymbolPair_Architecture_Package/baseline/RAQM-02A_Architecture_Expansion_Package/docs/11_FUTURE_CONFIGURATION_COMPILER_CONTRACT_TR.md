# 11 — Gelecekteki Özel Kod Oluşturucu İçin Donanım Sözleşmesi

**Bu belge compiler yazmaz ve programlama dili sözdizimi belirlemez.** Yalnızca mimari dondurulduktan sonra kod oluşturucunun hangi donanım semantiğini korumak zorunda olduğunu tanımlar.

## 1. Derlenecek şey satır dizisi değil, uzamsal graph/configuration olacaktır

Girdi modeli: node listesi, edge listesi, node tipi, branch lineage, lag, route, weight, polarity, handshake class, state-cell allocation ve bias profile.

Çıktı adayları:

- Node-to-hardware placement map.
- Edge-to-physical-net routing map.
- State-cell ve branch slot tahsisi.
- MUX/ARB/SUM/FORK seçim konfigürasyonu.
- Bias/current/termination profile.
- REQ/ACK bağlantı eşlemesi.
- Build-time topology checks ve bench test vector listesi.

## 2. Kod oluşturucunun zorunlu statik denetimleri

1. Aynı-generation DAG kontrolü.
2. Her recurrent edge için state-cell ve lag kontrolü.
3. Fan-in/fan-out ve tek-sürücü kontrolü.
4. Branch parent/child kimliği ve join generation uyumu.
5. Tek-yazıcı / multi-writer arbiter kontrolü.
6. FORK ile analog passive split ayrımı.
7. MUX / rendezvous / arbiter / weighted sum tip ayrımı.
8. Tail-current, load, headroom ve fan-out bütçesi.
9. Differential polarity ve input common-mode uyumu.
10. Handshake backpressure, timeout, reset/flush ve fault yolları.
11. Yerleşim/route kapasitesi ve test erişilebilirliği.
12. SETTLED istenen uygulamada residual/qualification criterion zorunluluğu.

## 3. Dil tasarımı için sonraya bırakılanlar

Fonksiyon sözdizimi, tip sistemi, makro, optimizer, graph lowering, compiler backend, debug ve runtime API henüz tasarlanmayacaktır. Bunlar hücre transfer eğrileri ve elektriksel limitler bilindikten sonra belirlenecektir.
