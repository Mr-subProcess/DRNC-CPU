# 05 — DRNC ve Dallanan Zerya'nın Fiziksel Eşlemesi

## 1. Rol ayrımı

DRNC burada düğüm/durum/ilişki düzenini tarif eder. Dallanan Zerya yapısı ise bir durumun birden fazla kola ayrılması, bu kolların yeniden birleşmesi ve geçmiş durum üzerinden yeni dallara geri dönmesi için topolojik/operasyonel kuralları verir. Bu isimler tek başına bir devre elemanı veya doğrulanmış fiziksel sonuç değildir; her matematiksel işlem bir akım hücresi, selector, state-cell veya summing cell ile eşleştirilmelidir.

## 2. Düğüm durumu

Bir node'un anlık diferansiyel durumu `x_i` ile, tuttuğu tarihsel durum `s_i[n]` ile gösterilsin. `x_i` bir işaret/normalize diferansiyel akım değişkeni olabilir. Fiziksel karşılığı ölçülmüş akım veya diferansiyel voltaj olmalıdır.

## 3. Aynı epoch ve tarihsel kenarlar

- Aynı epoch bağlantısı `w_ij^(0)` ile gösterilir.
- Geçmiş durum bağlantısı `w_ij^(ℓ)` ve `ℓ≥1` ile gösterilir.

Temsili durum denklemi:

`x_i[n+1] = Φ_i(b_i + Σ_j Σ_{ℓ≥0} w_ij^(ℓ) x_j[n−ℓ])`

Burada `Φ_i` fiziksel node'un transfer eğrisi/saturasyonudur. `w_ij` ağırlığı, ileride current-mirror oranı, tail current veya seçilebilir resistor/transconductance ağıyla kalibre edilebilir. Şimdiki MUX kartı programlanabilir analog ağırlık üretmez; yalnızca diferansiyel yol seçer.

## 4. Dallanan Zerya operatörü

Bir kaynağın iki kola ayrılması:

`Z_i(x_i) = (w_iA x_i, w_iB x_i)`

Pasif current-split için akım bütçesi:

`I_A + I_B + I_loss = I_source`

Eğer her kola tam genlikli kopya gerekiyorsa aktif buffer/current-copy hücresi şarttır. Her aktif kopya için güç ve bias bütçesi ayrı yazılmalıdır.

İki kolun birleşmesi seçim veya toplama olabilir:

- **Seçim:** `MUX(A,B,SEL)` — aynı anda yalnızca tanımlı bir yol seçilir.
- **Toplama:** `I_SUM = g_A I_A + g_B I_B` — özel current-summing hücresi, işaret/polarite ve lineer aralık gerektirir.

Bu iki işlemin aynı sembolle veya aynı kablo bağlantısıyla temsil edilmesi yasaktır.

## 5. DRNC recurrent durumu

Tarihsel state-cell güncellemesi kavramsal olarak:

`s_i[n+1] ← H_i(x_i[n], WRITE_i)`

ve sonraki epoch'ta:

`x_j[n+1] ← R_i(s_i[n+1])`

şeklindedir. `H_i` yakalama/hold, `R_i` okuma/buffer fonksiyonudur. Fiziksel transistor şeması, hold droop, write window, read disturbance ve metastabilite karakterizasyonu RAQM-02 işidir.

## 6. Üç fiziksel çalışma modu

- **Route mode:** MUX/crossbar ile diferansiyel verinin yolu seçilir. RAQM-01C'nin gerçek kapsamı budur.
- **Recurrent-state mode:** state-cell'ler geçmiş durumları saklar ve gecikmeli geri besleme sağlar. RAQM-02/03 hedefidir.
- **Relaxation/optimization mode:** ağırlıklı analog coupling ve enerji/kararlılık fonksiyonu tanımlanmış bir ağın denge noktasına yakınsaması. RAQM-04 hedefidir.

Route mode çalışıyor olması, relaxation mode'un da çalıştığını göstermez.
