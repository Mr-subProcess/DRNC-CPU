# 01 — Sistem Mimarisi

## 1. Ürün konumu

RAQM (Recurrent Asynchronous Qudit Mesh), genel amaçlı CPU değildir. İlk ürün hedefi, belirli matematiksel/optimizasyon alt problemlerinin fiziksel diferansiyel akım örgüsünde yürütülmesini araştıran **ön-hızlandırıcıdır**. Host, veri hazırlama, I/O, kullanıcı arayüzü, güvenli başlatma ve ölçüm kayıtlarını yönetir. RAQM veri çekirdeği ise uzamsal olarak bağlanmış diferansiyel yönlendirme ve ileride yerel durum saklama hücrelerinden oluşur.

## 2. Katmanlar

1. **Host arayüzü:** 3,3 V tek-uçlu veri, seçim, REQ/ACK, reset ve hata arayüzü. Host clock'u RAQM'nin iç clock'u değildir.
2. **Seviye çevirme:** Host'un LVTTL/LVCMOS bitlerini diferansiyel LVPECL hatlarına çevirir; çıkışları diferansiyel alıcıya göre sonlandırılır.
3. **CML/PECL yönlendirme dokusu:** N0…N3 gibi düğümlerde diferansiyel A/B adaylarından seçim yapılır. İlk kartta MC100EP56, özel CML transistör yapısının yerine kullanılan ölçülebilir ECL/PECL MUX demonstratörüdür.
4. **Yerel durum katmanı:** RAQM-02 hedefinde her state-cell bir diferansiyel değeri ACK olayıyla yakalar ve bir sonraki olay/epoch'a kadar tutar. Bu katman RAQM-01C kartında henüz fiziksel olarak yoktur.
5. **Çıkış ve completion:** Diferansiyel sonuçlar ölçülür ve host seviyesine dönüştürülür. Dijital handshake onayı ile analog yakınsama onayı ayrı sinyallerdir.

## 3. Bugünkü dört düğümlü demonstratör

- U1–U4: 4× MC100EPT22; toplam 8 diferansiyel LVPECL aday giriş çifti.
- U5–U6: 2× MC100EP56; toplam 4 diferansiyel 2:1 MUX kanalı (N0…N3).
- U7–U8: 2× MC100EPT23; toplam 4 diferansiyel girişten 4 host seviyeli çıkış.
- U9–U10: LVC08A + LVC32A ile kurulan tek 2-girişli Muller C-element kontrol denemesi.
- J1: host sinyal arayüzü. J2: +3,3 V. J3: diferansiyel test çıkışları. J4: harici VTT.

**Önemli ayrım:** Veri yolu ECL/PECL current-steering mantığı kullanır. Kontrol düzlemindeki C-element örneği CMOS LVC kapılarından kuruludur. Dolayısıyla “kartın hiçbir yerinde CMOS AND/OR yok” iddiası doğru değildir. Sistem genelinde CMOS kontrol mantığını da kaldırmak, daha sonraki bir CML kontrol hücresi revizyonunun hedefidir.

## 4. Veri akışı

`Host GPIO → MC100EPT22 → VTT sonlandırmalı diferansiyel giriş → MC100EP56 seçimi → VTT sonlandırmalı diferansiyel çıkış → MC100EPT23 → Host GPIO`

Dört çıkış iki sembole gruplanır:

- Qudit-A = (OUT1, OUT0)
- Qudit-B = (OUT3, OUT2)

Bit anlamı `b=1` ise pozitif hat negatif hattan yüksek; `b=0` ise pozitif hat negatif hattan düşüktür. Bu tanım tüm kart ve ölçüm belgelerinde korunmalıdır.

## 5. Recurrent örgü hedefi

İstenen yapı yalnızca ileri yönlü ağaç değildir. Dallar ayrılır, başka dallarla birleşir, daha sonra yeni dallar açar ve önceki durumlara geri beslenir. Ancak geri besleme doğrudan kabloyla sıfır-gecikmeli kombinasyonel halka oluşturmaz. Her tarihsel dönüş bir state-cell/hold sınırından geçer. Böylece dalın geçmişi korunur, fakat aynı epoch içinde tanımsız bir cebirsel çevrim yaratılmaz.

## 6. Host sınırı

Host bir işlem başlatır, giriş verisini sabitler ve REQ olayını üretir. Sonucun fiziksel kabulü/kararlılığı RAQM tarafında tespit edilmeden ACK yükselmemelidir. İlk kartta `HOST_VALID_TEST` host tarafından üretilen test sinyalidir; ACK gerçek analog yakınsama veya yerel durum saklama kanıtı değildir.

## 7. Ürünleşme basamakları

- **RAQM-01C:** doğru terminasyon ve besleme; dört MUX kanalının ölçümü; temel handshake; qudit sembol testi.
- **RAQM-02:** tek hücreli diferansiyel CML state-cell; set/reset, retention, write-enable, read-disturb ve metastabilite karakterizasyonu.
- **RAQM-03:** state-cell içeren 2×2 çapraz bağlı mesh; gecikmeli çapraz geri besleme ve completion.
- **RAQM-04:** ağırlıklı akım toplama/dağıtma ve sınırlı analog relaksasyon modu.
- **RAQM-05:** genişletilmiş mesh, uygulama sınıfları, ölçülmüş performans ve ancak bundan sonra özel derleyici/kod üretici.
