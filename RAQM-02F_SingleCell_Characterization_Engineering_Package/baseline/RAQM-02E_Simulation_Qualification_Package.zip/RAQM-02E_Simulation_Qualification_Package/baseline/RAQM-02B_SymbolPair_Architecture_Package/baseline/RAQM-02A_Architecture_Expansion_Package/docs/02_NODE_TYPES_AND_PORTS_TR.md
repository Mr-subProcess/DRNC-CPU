# 02 — Düğüm Tipleri ve Port Sözleşmeleri

| Tip | Giriş | Çıkış | İşlev | Yasak yorum |
|---|---|---|---|---|
| `SRC` | host diferansiyel/tek-uçlu giriş | bir token portu | işlem verisini içeri alır | compute node değildir |
| `ROUTE_MUX` | A/B diferansiyel portu + SEL | bir Q çifti | tek adayı seçer | akım toplamaz |
| `FORK` | bir diferansiyel port | iki izole çıkış | iki branch token'ı üretir | pasif kabloyla bedelsiz tam genlikli kopya değildir |
| `BUFFER` | bir diff port | bir veya daha fazla izole diff port | fan-out ve yük izolasyonu | mantıksal branch kararı değildir |
| `STATE_CELL` | D±, WE±, RESET/FAULT | Q±, capture status | diferansiyel durumu uçucu saklar | RAM/flash veya kuantum bellek değildir |
| `SYNC_JOIN` | iki ayrı branch portu | birlikte kabul edilen operand demeti | tüm gerekli branch'lerin aynı token neslini bekler | tek başına analog toplama yapmaz |
| `ARBITER_JOIN` | iki veya daha fazla istek | tek kazanan port | aynı anda gelen alternatifleri karşılıklı dışlar | wired-OR değildir |
| `WEIGHTED_SUM` | iki veya daha fazla akım girişi | tek diferansiyel/analog çıkış | tanımlı ağırlıklarla gerçek akım toplar | MUX değildir |
| `SETTLE_MONITOR` | ölçülen state/residual | SETTLED/FAULT | yakınsama kriteri denetler | host VALID kopyası değildir |
| `FAULT_GUARD` | timeout, invalid, saturation | FAULT + inhibit | hatalı durumlarda ilerlemeyi durdurur | hesaplama sonucu değildir |

## Port sözleşmesi

Her diferansiyel veri portu `P/N` çiftidir. `V(P)>V(N)` pozitif, `V(P)<V(N)` negatif durumdur. Ortak-mod ve diferansiyel salınım ilgili alıcı bileşenin veri sayfası aralığında olmalıdır.

Her veri portunun tek elektriksel sürücüsü vardır. Bir kaynak iki alıcıya gidecekse `FORK/BUFFER` hücresinin iki ayrı çıkışı kullanılır. Bir düğümün iki giriş alması, bu girişlerin aynı net üzerinde birleştirilmesine izin vermez.

## Düğüm arayüzünün zorunlu sinyalleri

- `D_P`, `D_N`: diferansiyel data.
- `REQ`: veri sunuldu / işlem başlatıldı.
- `ACK`: alıcı yakaladı / kabul etti.
- `RESET`: bilinen başlangıca dönüş isteği.
- `FAULT`: geçersiz giriş, çakışan yazma veya bias/settle sorunu.
- `READY_CAPTURE`: tek hücre yakalamasının tamamlanması.
- `READY_SETTLED`: yalnız analog çözüm ağı için ayrı yakınsama onayı.
