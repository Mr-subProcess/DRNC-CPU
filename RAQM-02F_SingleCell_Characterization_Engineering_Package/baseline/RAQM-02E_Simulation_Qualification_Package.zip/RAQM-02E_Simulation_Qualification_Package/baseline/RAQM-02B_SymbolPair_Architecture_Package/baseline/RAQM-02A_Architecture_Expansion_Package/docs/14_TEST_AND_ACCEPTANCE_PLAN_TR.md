# 14 — RAQM-02A Doğrulama ve Kabul Planı

## A. Model / SPICE

- DC operating point: U1A/U1B–U3A/U3B ve Q1 çalışma bölgeleri ve headroom.
- Differential transfer: D_P/D_N polarity sweep.
- WRITE/HOLD: iki yönlü write, hold retention.
- `I_TAIL` ve `R_L` sweep; output swing/common-mode.
- WE_P/WE_N transition overlap ve current steering.
- D setup/hold sweep; metastability window.
- Temperature, VDD, transistor mismatch Monte Carlo.
- Read load/probe capacitance sweep.
- Noise transient and low-frequency offset.

## B. Bench

- Current-limited +3V3 bring-up.
- VBIAS_TAIL ve VCM_DATA/WE sweep.
- Q_P/Q_N differential probe measurement.
- 00→01→10→11 gibi iki hücreli sembol testleri sonraki revizyona bırakılır; bu tek hücre kuponu bir diferansiyel bit saklar.
- WRITE ile Q state set; HOLD sırasında D toggling; Q korunumu.
- Reset-by-write ve power-cycle sonrası unknown state davranışı.
- Uzun süreli retention, sıcaklık ve supply variation.

## C. Kabul kriterleri

1. WRITE modunda iki polaritenin ikisi de deterministik olarak yakalanır.
2. HOLD modunda D girişinin değişmesi Q'yu değiştirmez; izin verilen noise margin altında.
3. Q_P/Q_N differential amplitude alıcı/probe threshold'unu worst-case margin ile aşar.
4. Capture delay, setup/hold ve minimum WE süresi ölçülür ve raporlanır.
5. Güç/termal değerler transistör veri sayfası sınırları içinde kalır.
6. Beklenmeyen iki kararlı durum, metastabilite, latch-up veya rail violation varsa test geçersiz sayılır.
7. Tekrar testleri farklı power cycle ve sıcaklık noktalarında aynı davranışı üretir.

## D. Kabul edilmeyen kanıtlar

- Sadece sembolik denklem veya SVG diyagramı.
- Transistor datasheet f_T değerinden sistem frekansı çıkarmak.
- Host'un READY/VALID pinini ACK olarak geri beslemek.
- Bir hücre retention testinden çok hücreli mesh stabilitesi çıkarmak.
- MUX route testinden analog weighted-sum/optimization sonucu çıkarmak.

## E. Ölçüm raporu alanları

Board revision, PCB stack-up, transistor lot, resistor values, VDD, VBIAS, ambient/case temperature, D/WE common-mode, differential amplitude, I_TAIL, R_L, probe model/load, setup/hold, capture latency, retention duration, output margin, power and fault count.
