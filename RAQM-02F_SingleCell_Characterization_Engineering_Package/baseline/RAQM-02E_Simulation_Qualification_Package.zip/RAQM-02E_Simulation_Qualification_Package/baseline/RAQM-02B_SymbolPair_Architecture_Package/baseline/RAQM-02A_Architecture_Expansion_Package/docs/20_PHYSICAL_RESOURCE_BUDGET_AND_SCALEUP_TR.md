# 20 — Fiziksel Kaynak Bütçesi ve Ölçekleme

## 1. Akım bütçesi

İlk mertebe bütçe:

`I_total ≈ Σ I_tail,cell + I_control + I_buffer + I_monitor`

`P_total ≈ VDD × I_total`

Bu yaklaşık bütçe, güç pinlerindeki gerçek akım ve ısı ölçümü ile güncellenir. Her statik state-cell HOLD durumunda bias akımı tüketebilir; yerel durum saklama ücretsiz veya sıfır-güç değildir.

## 2. Branch kopyalama

Pasif akım bölmede:

`I_in = I_A + I_B + I_loss`

İki tam genlikli bağımsız child yolu gerekiyorsa aktif current-copy/buffer hücresi ve buna ait bias bütçesi gerekir. Fan-out limitini aşmak için ağaç topolojisi kullanılabilir; her yeni kademe ek gecikme, akım ve parazit getirir.

## 3. Join tipleri fiziksel olarak ayrıdır

- MUX: bir giriş seçilir.
- SYNC_JOIN: payload slotları korunur; yalnız hazır olayları rendezvous yapar.
- ARBITER_JOIN: aynı kaynağa erişme yarışını karşılıklı dışlar.
- WEIGHTED_SUM: iki veya daha fazla akım, tanımlı summing node'da lineer/headroom sınırları altında toplanır.

Bunların hiçbiri sadece kabloyu birleştirerek aynı işleve dönüşmez.

## 4. Headroom bütçesi

Her BJT katı için collector-emitter ve base-emitter çalışma aralığı, RL düşümü, tail sink headroom'u ve output common-mode birlikte hesaplanır. U1/U2/U3 ve Q1 için tüm DC çalışma noktaları, giriş ortak-mod aralıkları ve rail limitleri transistor datasheet sınırlarında kalmalıdır.

## 5. Mesh genişleme kapısı

Bir tek-hücre kabul raporu olmadan iki hücre paralel bağlanmaz. 2-cell aşamasında önce:

1. Her hücre bağımsız capture/hold testini geçer.
2. Ortak supply/bias altında iki hücrenin loading etkisi ölçülür.
3. Cross-feedback yalnız state-cell çıkışından başlar ve state boundary ile lag≥1 olur.
4. Her edge için bağımsız REQ/ACK ölçülür.
5. Pair-valid gating ve fault/timeout davranışı doğrulanır.
6. Güç ve ısıl artış bütçeye uyar.

## 6. Analog relaksasyon için ek şart

Weighted-sum ve recurrent analog çözüm aşamasında yalnız latch doğrulaması yeterli değildir. Ağın fiziksel transfer fonksiyonu, gürültüsü, saturation davranışı, equilibrium, basin of attraction, stability margin ve workload-specific residual ölçülmelidir. Bir ağın sabit bir noktaya oturması, o noktanın istenen matematik problemin çözümü olduğunu tek başına ispatlamaz.
