# 04 — Clockless Handshake ve Completion

## 1. Clockless ne demektir?

RAQM veri çekirdeğinde global periyodik clock ve clock dağıtım ağacı yoktur. Bu, devrede zaman/gecikme bulunmadığı anlamına gelmez. Transistor yayılma gecikmesi, kablo gecikmesi, state-cell yakalama süresi, completion dedektörü ve handshake gecikmesi vardır. Host MCU clock'lu olabilir; bu clock RAQM mesh'in global clock'u değildir.

## 2. Dört-fazlı handshake

Bir işlem aşağıdaki dört fazdan geçer:

1. **Idle:** `REQ=0`, `ACK=0`; veri yolları bir sonraki payload'a hazırlanır.
2. **Request:** Gönderici payload'ı sabitler ve `REQ=1` yapar. Veri, alıcı yakalayana kadar değişmez.
3. **Acknowledge:** Alıcı verinin elektriksel olarak geçerli ve kabul edilmiş olduğunu doğrular, `ACK=1` yapar.
4. **Return-to-zero:** Gönderici `REQ=0` yapar. Alıcı `ACK=0` yapar. Sonraki payload ancak Idle yeniden görülünce başlatılır.

REQ veya ACK'nin kısa bir pulse olması yeterli değildir; her iki tarafın da fazı görmesi gerekir.

## 3. Bundled-data kuralı

Kontrol hattı, veri yolundan önce ilerleyemez. Payload, REQ yükselmeden önce kararlı olmalı ve receiver capture onayı gelene kadar korunmalıdır. Veri yolunun en kötü durum gecikmesi, kontrol yoluna eklenen tasarım gecikmesinden kısa olmalıdır. Bu eşleşme PCB, sıcaklık, gerilim ve yük koşullarında ölçülmelidir.

## 4. Muller C-element

İki girişli C-element'in durum denklemi:

`ACK_next = (REQ ∧ VALID) ∨ (ACK_prev ∧ (REQ ∨ VALID))`

- REQ=1 ve VALID=1 olduğunda ACK=1.
- REQ=0 ve VALID=0 olduğunda ACK=0.
- Girişler farklıyken ACK önceki değerini korur.

Mevcut prototipte C-element, SN74LVC08A ve SN74LVC32A ile kapı seviyesinde kurulmuştur. Bu bir kontrol düzlemi devresidir; veri CML yolunun parçası değildir. Gerçek asenkron çalışmanın hazard, yarış, reset ve metastabilite ölçümleri yapılmadan bu devre üretim kalitesinde completion cell kabul edilmez.

## 5. HOST_VALID_TEST'in anlamı

RAQM-01C kartında `HOST_VALID_TEST`, host tarafından verilen test girdisidir. Böyle bir kurulumda ACK, yalnızca host'un VALID'i yükselttiği koşulda C-element çevrimini tamamlar. Bu, fiziksel yakınsama veya yerel state-cell kabulünün ölçüldüğünü kanıtlamaz.

RAQM-01C doğrulamasında iki ayrı sinyal kategorisi kullanılmalıdır:

- `HOST_VALID_TEST`: test sırasında host tarafından zorlanabilen sinyal. Karttaki mevcut C-element, REQ ve HOST_VALID_TEST girişlerini kullanır; ACK bu iki girişin birlikte yükselmesiyle set edilir ve ikisi birlikte düşük olduğunda sıfırlanır.
- `CORE_READY`: alıcı/ölçüm devresinden gelen, fiziksel doğrulamaya bağlı sinyal.

Ürün handshake'inde ACK, `CORE_READY` ile ilişkilendirilmelidir. Bu revizyonda CORE_READY hattı uygulanmamıştır; dolayısıyla mevcut ACK yalnızca test handshake onayıdır, fiziksel çekirdek hazır/kararlı sinyali değildir. Host'un kendi VALID çıkışını geri okuyup ACK diye adlandırmak yasaktır.

## 6. Analog yakınsama ile dijital handshake ayrımı

“Veri alındı” ile “analog ağ çözüme yakınsad” aynı olay değildir. İlkini handshake doğrular. İkincisi için ileride:

- tüm ilgili state düğümlerinin aralıkta olması,
- türev/değişim büyüklüğünün eşik altında kalması,
- residual veya kısıt ihlalinin tolerans altında olması,
- bu koşulların tanımlı bir qualification aralığı boyunca korunması

gerekir. Bu completion detector RAQM-01C'de uygulanmış değildir.

## 7. Deadlock / timeout

Global clock bulunmaması timeout ihtiyacını ortadan kaldırmaz. Host veya bağımsız analog watchdog, ACK'nin beklenen süre içinde gelmemesini hata olarak kaydetmelidir. Timeout süreleri önce ölçülmüş worst-case path ve state-cell karakterizasyonuna göre belirlenir; tahmini ps sayılarıyla sabitlenmez.

## 8. C-element başlangıç durumu

C-element geri beslemeli bir kontrol ağıdır; güç verildiği anda ACK çıkışının başlangıç değeri veri sayfası garantili bir reset değeri gibi kabul edilmemelidir. İlk testten önce REQ=0 ve HOST_VALID_TEST=0 birlikte uygulanmalı, ACK'nin düşük seviyeye oturduğu osiloskop/logic analyzer ile doğrulanmalıdır. Bu revizyonda ayrı bir donanımsal reset pini yoktur. Güç açılışında ACK belirlenemiyorsa test başlatılmamalı ve kontrol devresi revize edilmelidir.
