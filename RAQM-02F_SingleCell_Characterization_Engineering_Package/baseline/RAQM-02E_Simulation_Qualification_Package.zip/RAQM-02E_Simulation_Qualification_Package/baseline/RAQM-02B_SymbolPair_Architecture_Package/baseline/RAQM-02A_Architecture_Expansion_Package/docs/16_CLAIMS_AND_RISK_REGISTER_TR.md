# 16 — İddia ve Risk Kaydı

| İfade | Bu paketteki durumu | Doğrulama/sonraki işlem |
|---|---|---|
| RAQM dataplane global clock kullanmıyor | Tasarım kararı | Schematic/netlist ve bench ile doğrula |
| RAQM host'tan bağımsız işlemci | **Hayır** | Ön-hızlandırıcı; host hâlâ yönetim yapar |
| 00/01/10/11 dört sembolü destekleniyor | RAQM-01C iki diferansiyel pair ile | Dört sembol testleri; kuantum qudit iddiası yok |
| Geçmiş branch saklanıyor | RAQM-02A hedefi | Tek CML latch retention testi |
| Branch'ler birbirine çapraz dönebiliyor | Topoloji tanımlı | 02B/03 fiziksel recurrent test gerekir |
| CML state-cell mevcut | Aday topoloji | SPICE + gerçek PCB ölçümü gerekli |
| BCM847BS 250MHz | Datasheet fT typical at 10mA/5V | Bu kartın clock/data rate'i değil |
| Her problemin rezonansla anında çözümü | **İddia edilmez** | Model + workload + settle detector + bench benchmark |
| Bellek maliyeti sıfır | **İddia edilmez** | State-cell volatile ve static bias power çeker |
| Sub-millisecond çözüm | **İddia edilmez** | Uygulama ölçümleri sonrası karar |
| Genel compiler hazır | **Yok** | Mimari ve fiziksel semantik dondurulduktan sonra |

## Kritik riskler

1. **Latch headroom / bias:** üç transistor katının ortak-mod aralıkları örtüşmeyebilir. DC operating point ve transient SPICE şarttır.
2. **WE metastabilitesi:** D ve WE yakın geçişte latch dengede kalabilir; setup/hold ve resolution time dağılımı ölçülmelidir.
3. **State retention / static power:** HOLD durumunda current devam eder; hücre sayısı büyüdükçe güç toplanır.
4. **Read disturb:** output probe/buffer state'i bozabilir.
5. **Mismatch:** eşleştirilmiş çift de offset'i sıfırlamaz; Monte Carlo ve thermal characterization gerekir.
6. **Join deadlock:** branch iptal veya stale token join slot'unu sonsuza dek bekletebilir; timeout/flush şarttır.
7. **Asimetrik recurrent feedback:** enerji fonksiyonu ve tekil denge garanti değildir.
8. **PCB parazitleri:** layout, transistor matching ve yüksek empedanslı output üzerinde belirleyicidir.
9. **Terminoloji riski:** klasik dört-sembol kodu kuantum qudit değildir.
10. **Revizyon karışması:** 01C PECL/ECL terminasyon değerleri 02A BJT latch'e otomatik kopyalanmamalıdır.
