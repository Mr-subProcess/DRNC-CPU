# RAQM-01C Changelog

## 17 Kasım 2026 — Hardware Design Revision C

- Kapsam ön-hızlandırıcı olarak sabitlendi; genel amaçlı işlemci iddiası kaldırıldı.
- Paket içinden tüm programlama kodu, simülatör ve kod oluşturucu çıkarıldı; bu revizyon yalnız donanım/mimari dokümanıdır.
- Dört diferansiyel 2:1 MUX ve iki adet iki-bit sembol grubu netleştirildi.
- Dallanma, birleşme, cross-feedback ve geçmişe dönüş kuralları normatif hale getirildi.
- Her recurrent kenar için state-cell ve `lag≥1` şartı eklendi.
- CML current-steering ile PECL/ECL demonstratör arasındaki fark açıklandı.
- C-element kontrol mantığının LVC CMOS kapıları kullandığı ve data-plane'den ayrı olduğu kaydedildi.
- VTT=VCC−2V; 3,3 V sistem için 1,30 V olarak tanımlandı.
- 12 diferansiyel çift için 24 adet 49,9 Ω terminasyon eklendi.
- Harici sink-capable VTT beslemesi ve J4 konektörü eklendi.
- J1 pin20 +3V3 bağlantısı kaldırılarak host/kart güç geri-besleme riski azaltıldı.
- PCB ön yerleşimi, katman planı ve sinyal bütünlüğü kuralları güncellendi.
- Üretim öncesi test planı, risk/iddia kaydı ve kabul matrisi eklendi.

## Bilerek yapılmayanlar

- Kod, programlama dili, derleyici veya kod üretici yazılmadı.
- Yerel CML state-cell fiziksel olarak tasarlanmış sayılmadı.
- PCB iz yönlendirmesi, DRC/ERC, 3D veya Gerber üretimi tamamlanmış sayılmadı.
- Performans / yakınsama / enerji ölçümü iddia edilmedi.


## Paket iç denetim düzeltmesi
- KiCad net adı `HOST_VALID_TEST` olarak net arayüz CSV'siyle eşitlendi.
- NET_INTERFACE CSV'sine U9/U10 C-element pin/net eşlemesi eklendi.
- C-element güç-açılış idle koşulu ve bu revizyonda donanımsal RESET bulunmadığı açıklandı.
- Sistem blok ve recurrent mesh görsellerindeki metin/yerleşim çakışmaları düzeltildi.

- RAQM-02 için tek-bit diferansiyel state-cell işlev şartnamesi ve iki hücreli atomik qudit commit modeli eklendi.
- State-cell konsept blok diyagramı SVG/PNG olarak eklendi; transistor-level devre olmadığı özellikle işaretlendi.
- U9/U10 C-element net/pin arayüzü ve güç-açılış idle doğrulaması dokümante edildi.
