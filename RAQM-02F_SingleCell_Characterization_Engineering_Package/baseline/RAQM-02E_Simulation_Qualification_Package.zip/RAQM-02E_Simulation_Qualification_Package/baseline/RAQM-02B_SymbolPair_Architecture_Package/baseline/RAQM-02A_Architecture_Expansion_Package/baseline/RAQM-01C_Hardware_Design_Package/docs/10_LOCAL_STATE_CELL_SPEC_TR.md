# 10 — RAQM-02 İçin Yerel Diferansiyel CML State-Cell Şartnamesi

Bu belge sonraki donanım revizyonunun tasarım şartnamesidir; state-cell RAQM-01C kartına eklenmiş değildir.

## 1. Amaç

State-cell, bir diferansiyel veri değerini asenkron bir yazma olayıyla yakalar ve bir sonraki yazmaya kadar korur. Bu eleman, recurrent mesh içinde geçmiş dal değerinin fiziksel karşılığıdır. Host'un epoch-buffer/replay görevini daha sonra yerel donanıma aktarır.

## 2. Hücre giriş/çıkışları

- `D_P/D_N`: diferansiyel data girişi.
- `WE`: request/accept kontrolünden türetilen write-enable.
- `Q_P/Q_N`: saklanan diferansiyel state çıkışı.
- `RESET`: tanımlı ilk duruma dönüş.
- `READY`: yakalamanın tamamlandığını belirten yerel durum sinyali.
- `FAULT`: giriş geçersizliği, çakışan yazma veya bias arızası.

## 3. Fonksiyonel şartlar

1. RESET etkin olduğunda Q çıkışı tanımlı ve tekrarlanabilir olmalıdır.
2. WE aktifken D geçerli aralıkta ise state yakalanır.
3. WE pasifken Q, D girişinin değişiminden etkilenmemelidir.
4. Yazma penceresi içinde D/P-N ortak-mod ve diferansiyel salınım şartlarını karşılamalıdır.
5. READY, yalnızca state'in geçerli yakalama penceresini tamamladığı zaman yükselir.
6. Giriş aynı anda iki kaynak tarafından sürülemez.
7. Q çıkışının iki alıcıya dağıtılması gerekiyorsa fan-out/buffer yükü ayrıca doğrulanır.

## 4. Aday fiziksel topoloji

Araştırılacak hücre, tail-current kaynağı ve diferansiyel çiftleri içeren **statik current-mode latch/keeper** yaklaşımıdır. Çapraz bağlı diferansiyel geri besleme, tutulan durumu üretir; yazma diferansiyel çiftleri latch'in mevcut durumunu kontrollü olarak aşar. Bu yalnızca kavramsal adaydır. Transistor türü, akım değeri, yük direnci, headroom ve cihaz boyutları henüz dondurulmamıştır.

## 5. Zorunlu elektriksel karakterizasyon

- Set/reset truth table ve açılış durumunun tekrarlanabilirliği.
- Write setup/hold penceresi ve minimum WE darbe genişliği.
- Hold süresince droop/noise margin.
- Read disturb ve fan-out etkisi.
- D/P-N input common-mode range ve differential swing.
- Metastability window ve metastability resolution distribution.
- PVT (process, voltage, temperature) köşeleri.
- Monte Carlo mismatch.
- Tail-current değişimi ve güç tüketimi.
- Transient, DC operating point ve noise SPICE analizi.

## 6. Mesh entegrasyon kuralı

Tarihsel geri besleme kenarı doğrudan MUX çıkışından eski MUX girişine kabloyla bağlanmaz. `Q_P/Q_N` state-cell çıkışı üzerinden sonraki epoch'ta geri beslenir. Her recurrent edge için state-cell ID ve lag metadata'sı tanımlanır.

## 7. Qudit genişletmesi

Bir dört-sembollü qudit için iki bağımsız diferansiyel state-cell gerekir. Bu iki hücrenin capture/READY olayları aynı sembol transaction'ı altında gruplanmalı; yalnızca birinin hazır olması bütün sembolü geçerli yapmaz. `PAIR_READY = READY_b1 ∧ READY_b0` completion mantığı gerekir.
