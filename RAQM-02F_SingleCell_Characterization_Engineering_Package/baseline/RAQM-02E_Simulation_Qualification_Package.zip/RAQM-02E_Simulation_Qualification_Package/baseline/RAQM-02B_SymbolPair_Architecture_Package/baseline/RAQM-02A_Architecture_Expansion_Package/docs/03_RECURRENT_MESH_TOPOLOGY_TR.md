# 03 — Recurrent Mesh: Dallanma, Çapraz Bağlantı ve Geçmişe Dönüş

## 1. İki düzeyli grafik

Topoloji `G=(V,E0,Er)` olarak tanımlanır.

- `V`: fiziksel node/state-cell kümesi.
- `E0`: aynı generation içindeki doğrudan bağlantılar.
- `Er`: STATE_CELL üzerinden geçen tarihsel/recurrent bağlantılar.

`G0=(V,E0)` her generation için DAG olmak zorundadır. Her `e∈Er` için `lag(e)≥1` şarttır. Recurrent cycle izinlidir; ancak cycle, mutlaka state-cell sınırından geçer.

## 2. Somut çapraz dallanma örneği

1. `N0(g)` bir FORK hücresi ile `N1(g)` ve `N2(g)` kollarını üretir.
2. `N1(g)` çıktısı `J0.A`, `N2(g)` çıktısı `J0.B` portuna gider.
3. `J0` bir SYNC_JOIN'dir: aynı parent token ve aynı generation için iki kol da hazır olmadan operand çiftini downstream'e açmaz.
4. `F0` iki operandı kabul eden bir fonksiyon/işlem bloğudur. İşlem fonksiyonunun fiziksel devresi sonraki revizyonda tanımlanır.
5. `F0` sonucu `N3(g)` üzerinden ilerler.
6. `N3(g)` sonucu `S0` durum hücresine yazılır; `S0.Q` sonraki generation'da `N0` girişine geri döner.
7. `N2(g)` kolu ayrıca `S1` hücresine yazılır; `S1.Q` sonraki generation'da `N1`'in ayrı feedback portuna gelir.
8. `N1(g)` kolu `S2` hücresine yazılır; `S2.Q` sonraki generation'da `N2`'nin ayrı feedback portuna gelir.

Bu yapı, N1 ve N2 dallarının birbirine çapraz geri beslenmesini ve önceki generation'daki dal bilgisinin saklanmasını tanımlar. Hiçbir feedback bağlantısı doğrudan kombinasyonel kablo değildir.

## 3. Generation kavramı

`g` global saat sayacı değildir. Bir token/işlem neslini tanımlayan mantıksal etikettir. RAQM-02A tek hücre testinde donanım generation sayacı bulunmaz; generation sadece test planındaki kavramsal etiket olarak kullanılır. Çoklu token eşzamanlılığı hedeflendiğinde her edge/state slot için token kimliği veya faz etiketi ayrıca tanımlanır.

## 4. Tek-hücreden mesh'e büyüme

- `02A`: tek CML state-cell; D/WE/Q ve retention ölçümü.
- `02B`: iki state-cell + çapraz feedback; iki yönlü dal geçmişi.
- `03A`: 2×2 mesh, yerel handshake ve SYNC_JOIN.
- `03B`: ARBITER_JOIN ve FAULT_GUARD.
- `04A`: ağırlıklı current-sum hücresi.

Her aşama önceki aşamanın ölçüm kabul kriterlerini geçmeden büyütülmez.
