# 18 — İki Bitlik Sembol Çifti ve Atomik Güncelleme

## 1. Dört sembolün fiziksel karşılığı

Bir diferansiyel state-cell tek bir bit durumunu taşır. RAQM'nin ilk dört-sembollü gösterimi iki adet bağımsız diferansiyel state-cell'in çiftidir:

| Sembol | Hücre B0 | Hücre B1 |
|---|---:|---:|
| `00` | 0 | 0 |
| `01` | 0 | 1 |
| `10` | 1 | 0 |
| `11` | 1 | 1 |

Her bit için `1`, tanımlı polaritede `Q_P > Q_N`; `0`, `Q_P < Q_N` olarak yorumlanır. Gerçek threshold/noise margin alıcı devresine göre belirlenir.

**Bu iki bitli elektriksel kod klasik dört-sembollü koddur; kuantum qudit veya kuantum süperpozisyon iddiası değildir.**

## 2. Pair identity

İki state-cell aynı transaction'da yazılacaksa ortak `pair_id`, `parent_id` ve generation etiketi taşır. Hücrelerin ayrı ayrı capture ACK üretmesi çiftin tüm downstream tüketiciler için geçerli olduğu anlamına gelmez.

## 3. Pair commit kuralı

- B0 ve B1 yazma istekleri aynı pair kimliğine sahip olmalıdır.
- Her hücre kendi `ACK_CAPTURE` olayını üretir.
- `PAIR_VALID` ancak ikisi de beklenen polaritede yakalanmışsa yükseltilir.
- Bir hücre timeout, invalid WE veya FAULT üretirse `PAIR_VALID=0` kalır; transaction iptal edilir ve reset/rewite politikası uygulanır.
- Downstream node, `PAIR_VALID=1` olmadan sembolü tüketemez.

İlk 02A tek-hücre kartı `PAIR_VALID` üretmez. Bu özellik iki-hücreli RAQM-02B testinde ayrı kontrol kapısıdır.

## 4. Atomiklik seviyesi

İki latch'ın Q çıkışlarında kısa süreli karışık sembol görülmesi fiziksel olarak mümkündür; iki capture aynı anda değişmek zorunda değildir. Dolayısıyla `PAIR_VALID` downstream görünürlüğünü atomik yapar, ama iki Q pininin analog voltajını aynı anda güncelleme garantisi vermez. Gerçek pin-level atomiklik istenirse shadow pair + commit/visibility gating topolojisi gerekir; bu daha fazla latch ve güç demektir.

## 5. İki hücreli büyütme seçenekleri

**Seçenek A — Valid-gated pair:** iki latch doğrudan güncellenir, downstream yalnız PAIR_VALID ile okur. En düşük hücre sayısı; Q pinlerinde geçici karışık durum görülebilir.

**Seçenek B — Shadow pair:** yeni sembol ikinci bir latch çiftine yazılır; iki capture onaylandıktan sonra görünürlük seçimi bir olayla değiştirilir. Daha fazla transistor, bias ve kontrol gerektirir; ancak downstream'e eski sembolü commit anına kadar koruyabilir.

RAQM-02B için başlangıç adayı A'dır; ancak uygulamanın dışarıya atomik sembol sunması gerekiyorsa B seçilmelidir. Karar gerçek fanout ve state-cell alanı ölçüldükten sonra dondurulur.
