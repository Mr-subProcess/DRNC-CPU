# 01 — Üst Seviye RAQM Mimarisi

## 1. Katman modeli

1. **Host / dış dünya:** dosya, I/O, kullanıcı arayüzü, veri yükleme, hata kaydı ve güvenli başlatma. Host saatli olabilir; host clock'u RAQM mesh clock'u değildir.
2. **Asenkron kenar arayüzleri:** her bağlantıda veri, REQ, ACK ve gerekirse FAULT/RESET işaretleri.
3. **CML diferansiyel veri dokusu:** ROUTE, FORK, BUFFER, JOIN ve gelecekte WEIGHTED_SUM hücreleri.
4. **Yerel durum katmanı:** cross-coupled CML latch/state-cell; recurrent geçmişi yerel olarak tutar.
5. **Completion/fault katmanı:** capture-valid, settle detector, watchdog ve saturation/fault gözlemi.
6. **Güç/bias katmanı:** her hücre grubunun tail current ve common-mode gereksinimini sağlar; state-cell açıkken statik güç tüketilir.

## 2. Clockless işleyiş

RAQM veri dokusunda periyodik clock dağıtımı yoktur. Bir düğüm veri hazır olduğunda REQ yükselir; alıcı veriyi yakalayıp kabul edince ACK verir. Bir sonraki düğüm kendi yerel handshake'i üzerinden ilerler. Her düğüm aynı anda çalışmak zorunda değildir. Global bir zaman adımı veya herkesi aynı anda ilerleten epoch clock'u tanımlanmamıştır.

Fiziksel analog devre geçişleri sürekli zamanda oluşur. `generation g`, sadece bir token'ın hangi mantıksal işlem nesline ait olduğunu belirtir. Aynı generation'daki bağlantıların topolojik çevrimsizliği, fiziksel saat senkronizasyonu değildir.

## 3. Veri çekirdeği ve kontrol düzlemi ayrımı

- **Dataplane:** diferansiyel akım/gerilim taşıyan transistor hücreleri.
- **Control plane:** REQ/ACK, mutual-exclusion arbiter, reset, fault ve bias-enable.
- **Completion plane:** alım/capture tamamlandı mı ve analog ağ gerçekten settle oldu mu sorularını ayrı izler.

Kontrol düzleminde CMOS bulunması, veri düzleminde CML akım yönlendirmesi kullanılmasına engel değildir. “Kartın hiçbir yerinde CMOS yok” gibi mutlak bir ifade bu mimari için kullanılmayacaktır.

## 4. Veri yolu ve bellek duvarı

Yerel durum hücresi, ilgili değer için host RAM'e gidip gelme ihtiyacını azaltabilir; ancak bu, bütün harici bellek gereksinimini ortadan kaldırmaz. Host hâlâ problem verisini hazırlar ve sonuçları alır. State-cell'ler statik bias akımı çeker; veri taşımak yerine yerel saklama yapılması güç ve alan maliyetini sıfırlamaz.

## 5. Çalışma modları

- `ROUTE`: diferansiyel veriyi seçilen yola geçirir.
- `RECURRENT_STATE`: geçmiş değeri state-cell'de tutar ve daha sonraki generation'da geri besler.
- `RELAXATION`: ağırlıklı analog ağın dinamik dengeye yaklaşmasını araştırır.

Bir modun doğrulanması diğerlerini doğrulamaz. RAQM-02A yalnız RECURRENT_STATE'in tek hücre yapı taşını hedefler.
