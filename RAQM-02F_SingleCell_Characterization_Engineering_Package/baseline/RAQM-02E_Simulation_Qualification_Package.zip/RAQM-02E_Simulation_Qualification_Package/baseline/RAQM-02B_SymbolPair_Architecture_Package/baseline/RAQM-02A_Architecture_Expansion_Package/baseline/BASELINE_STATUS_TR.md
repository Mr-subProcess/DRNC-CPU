# Baseline durumu

`RAQM-01C_Hardware_Design_Package/` önceki donanım revizyonunun tam doküman setidir. İçinde MC100EP56/MC100EPT22/MC100EPT23 tabanlı dört kanallı PECL/ECL MUX demonstratörü ve yönlendirilmemiş KiCad ön-yerleşimi vardır. Üretime hazır değildir. RAQM-02A BJT-CML state-cell için 01C terminasyonlarını ve bias değerlerini aynen kullanmayın.
