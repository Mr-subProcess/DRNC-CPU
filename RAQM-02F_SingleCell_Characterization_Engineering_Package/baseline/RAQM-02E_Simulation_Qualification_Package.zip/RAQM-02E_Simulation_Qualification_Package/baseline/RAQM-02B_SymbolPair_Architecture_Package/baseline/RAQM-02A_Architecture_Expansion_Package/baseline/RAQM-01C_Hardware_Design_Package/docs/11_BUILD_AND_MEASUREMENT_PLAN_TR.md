# 11 — Prototip Montajı ve Laboratuvar Test Sırası

## A. PCB üretim öncesi

- [ ] Şematik/netlist ile KiCad footprint pad eşleşmesi kontrol edildi.
- [ ] MC100EP56 tüm VCC/VEE pinleri ve COM_SEL bağlantıları doğrulandı.
- [ ] U1–U4 EPT22 pin yönleri veri sayfasıyla doğrulandı.
- [ ] U7–U8 EPT23 pin yönleri veri sayfasıyla doğrulandı.
- [ ] 24 adet 49,9 Ω terminasyonun doğru alıcı tarafında ve VTT'ye bağlı olduğu doğrulandı.
- [ ] VTT kaynağının 1,30 V ve sink kapasitesi ≥0,4 A olduğu doğrulandı.
- [ ] J1 pin20 NC; J2 yalnızca kart +3V3 girişi; host rail ile güç paralellemesi yok.
- [ ] 4-layer stack-up ve üretici kontrollü 50 Ω line impedance onaylandı.
- [ ] ERC/DRC ve 3D clearance tamamlandı.
- [ ] Gerber/ODB++ ve drill çıktıları bağımsız gözden geçirildi.

## B. İlk güç açılışı

1. Tüm IC'ler takılı değilken +3V3/GND/VTT kısa devre kontrolü.
2. VTT bağlı değilken +3V3 uygulanmaması; terminasyonların VTT ihtiyacını göz önünde tut.
3. VTT kaynağının 1,30 V ayarı ve sink modu doğrulanır.
4. +3V3 akım limiti düşük seviyeden başlatılır; ray yükseltilirken toplam akım ve rail droop izlenir.
5. U1–U8 besleme pinlerinde DC seviyeler ve sıcaklık kontrol edilir.
6. Host GPIO bağlantısı yapılmadan diferansiyel P/N çıkışları uygun probla ölçülür.

## C. Kanal doğrulaması

Her N0…N3 için:

- A=0/B=1, SEL=0 ve SEL=1 kombinasyonları.
- A=1/B=0, SEL=0 ve SEL=1 kombinasyonları.
- Sabit veriyle tekrarlı seçim.
- Differential swing, common-mode, rise/fall ve overshoot.
- Çift içi skew ve kanal-kanal skew.
- J3 test noktası ve EPT23 host çıkışının karşılaştırılması.

## D. Dört-sembol testi

Her sembol için b1,b0 bit sırası ve OUT pinleri açıkça kaydedilir: 00,01,10,11. A ve B qudit gruplarının tüm kombinasyonları denenir. Bu test yalnızca klasik dört-sembol taşıma testidir.

## E. Handshake testi

- Idle 00 → Request 10 → Acknowledge 11 → Return-to-zero 01 → Idle 00.
- REQ'nin erken yükseltilmesi.
- VALID'in gecikmesi.
- REQ'nin ACK gelmeden düşmesi.
- Veri payload'ının erken değiştirilmesi.
- Reset sırasında REQ.
- Çok sayıda tekrarlı çevrim, sıcaklık/gerilim değişimi.

Geçersiz sıralamalar ACK üretmemeli ve fault/timeout kaydı oluşturmalıdır.

## F. Sinyal bütünlüğü

- 50 Ω per-leg hat ve VTT yüküyle göz diyagramı/kenar ölçümü.
- Hat yansıması, ringing, common-mode ve pair skew.
- VTT ripple ve transient.
- GND bounce ve güç rayı ripple.
- Termal kararlılık ve hava akışı.

## G. RAQM-02 state-cell testi

State-cell tasarımına geçildiğinde: hold retention, write setup/hold, metastability, read disturb, reset determinism, 2-cell pair coherence ve delayed-feedback stability testleri eklenecek.
