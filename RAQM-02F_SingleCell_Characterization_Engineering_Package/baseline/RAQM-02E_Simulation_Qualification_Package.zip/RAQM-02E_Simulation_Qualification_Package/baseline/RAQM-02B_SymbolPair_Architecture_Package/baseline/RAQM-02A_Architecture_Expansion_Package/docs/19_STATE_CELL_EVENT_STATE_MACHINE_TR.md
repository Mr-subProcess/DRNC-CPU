# 19 — State-Cell Olay Durum Makinesi

Bu durum makinesi periyodik clock ile ilerlemez. Geçişler giriş diferansiyel seviyesi, REQ/ACK ve yerel capture ölçüm olaylarıyla tetiklenir.

| Durum | WE | Giriş koşulu | Eylem | İzin verilen sonraki durum |
|---|---|---|---|---|
| RESET_REQUIRED | HOLD/disabled | Güç açılışı veya fault recovery | Çıkışı valid sayma; bilinen WRITE bekle | WRITE_ARMED |
| HOLD | HOLD polarity | Geçerli state var | Cross-coupled hold akımı state'i korur | WRITE_ARMED, FAULT |
| WRITE_ARMED | HOLD→WRITE öncesi | REQ geldi; D± kararlı değil | ACK verme; setup şartını bekle | TRACK veya FAULT |
| TRACK | WRITE polarity | D± geçerli ve REQ aktif | Tail akımı DATA yoluna yönlenir | CAPTURE_CHECK |
| CAPTURE_CHECK | WRITE polarity | Q diferansiyel eşik/kararlılık koşulu aranır | Capture comparator qualification | HOLD veya FAULT |
| FAULT | Inhibit | Timeout, invalid WE, rail/bias fault | Yeni transferleri engelle; recovery iste | RESET_REQUIRED |

## Olay semantiği

- `REQ↑`: payload sunulmuştur; gönderici data'yı ACK'ye kadar değiştirmez.
- `WE=WRITE`: steering akımı DATA koluna yönlendirir.
- `CAPTURE_OK`: Q± beklenen polariteyi ve eşik marjını ölçüm penceresi boyunca sağlar.
- `ACK↑`: yalnız capture kabulünden sonra.
- `REQ↓`: gönderici işlemi bırakır.
- `ACK↓`: dört-fazlı transfer yeniden IDLE olur.
- `WE=HOLD`: tail current çapraz bağlı hold pair'e yönlendirilir.

## Ölçülmeden sayı verilmeyecek parametreler

Minimum REQ/WE pulse width, D setup/hold, TRACK→HOLD transfer süresi, capture threshold, hysteresis, qualification window ve maksimum güvenli giriş slew rate. Bunlar transistor-level transient SPICE ve ölçüm ile çıkarılır.

## Güvenli hata davranışı

Invalid veya metastabil görünen durumda ACK zorla yükseltilmez. `FAULT`/timeout yolu tetiklenir; state geçerli kabul edilmez. Güç açılışında Q çıktısı bilinen state kabul edilmez; reset-by-write tamamlanmalıdır.
