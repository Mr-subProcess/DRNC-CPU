# 17 — Asenkron Kontrol Düzlemi ve Müller C-Element

## 1. Veri düzlemi ile kontrol düzlemi ayrımı

RAQM'nin CML dataplane'i diferansiyel payload ve analog akım durumunu taşır. Kontrol düzlemi ise REQ/ACK, reset, fault, branch-valid, grant ve join-completion olaylarını taşır. Kontrol işlevi dataplane'in sayısal payload'ına karıştırılmaz.

İlk RAQM-02A kuponunda tam bir fiziksel C-element bulunmaz; WRITE/HOLD, kontrollü harici test kaynağıyla sürülür. RAQM-02B'de C-element ayrı transistor-level hücre olarak tasarlanıp karakterize edilir. Böylece C-element'in henüz tasarlanmamış olması state-cell'in ölçümünü gizlemez.

## 2. İki girişli C-element davranışı

| A | B | Y(next) | Açıklama |
|---:|---:|---|---|
| 0 | 0 | 0 | İki giriş de düşükse çıktı düşük olur |
| 0 | 1 | Y(previous) | Girişler ayrışmış; önceki durum korunur |
| 1 | 0 | Y(previous) | Girişler ayrışmış; önceki durum korunur |
| 1 | 1 | 1 | İki giriş de yüksekse çıktı yüksek olur |

Davranış denklemi:

`Y_next = (A AND B) OR (Y_previous AND (A OR B))`

Bu denklem yalnız mantıksal davranış sözleşmesidir; transistor netlisti değildir.

## 3. Üç ve daha fazla giriş

Üç veya daha fazla bağımsız koşul, karakterize edilmiş iki girişli C-element kademeleriyle birleştirilebilir. Ağaç gecikmesi ve fanout eklenir. Aynı C-element'in birden fazla çıkışın fiziksel gecikmesini otomatik olarak eşitleyeceği varsayılmaz.

## 4. FORK acknowledge

FORK girişinin ACK'si, iki child edge'in ACK veya açıkça tanımlanmış CANCEL sonucuna ulaşmasından önce üretilmez. Child ACK'ler iki girişli C-element/rendezvous kontrolüyle birleştirilebilir. Child'lardan biri fault alırsa upstream ACK yerine FAULT/CANCEL politikası yürür.

## 5. SYNC_JOIN acknowledge

Her operand önce kendi giriş slotuna yakalanır. JOIN çıkış REQ'si tüm zorunlu slotlar dolduğunda oluşturulur. C-element yalnız ready olaylarını birleştirir; payload bitlerini veya analog akımları toplamaz.

## 6. ARBITER_JOIN

C-element mutual-exclusion arbiter yerine geçmez. İki istek aynı anda geldiğinde arbiter grant üretir. Metastabilite çözülme süresi teorik olarak üstten kesin sınırlı değildir; timeout yalnız hata gözlemi/iptal politikasıdır, metastabiliteyi yok etmez.

## 7. CML uyumluluğu

İstenen nihai tasarımda kontrol hücreleri de transistor düzeyinde RAQM'nin diferansiyel/akım mantığıyla uyumlu tasarlanacaktır. İlk kuponun harici laboratuvar kontrolü bir ürün dataplane kapısı olarak kabul edilmez. Bu doküman CMOS kapı ağı seçmez ve C-element transistor topolojisini dondurmaz.
