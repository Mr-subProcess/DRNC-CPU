# 04 — Katı Dallanma, Birleşme ve Geri Besleme Kuralları

Bu bölüm normatiftir. Daha sonra yazılacak özel derleyici bu kuralları donanım konfigürasyonuna çevirecek; bu pakette kod yoktur.

## A. Grafik ve gecikme kuralları

1. Aynı-generation kenarlar grafiği `G0` içinde yönlü çevrim oluşturamaz.
2. Her recurrent edge bir `STATE_CELL` üzerinden geçer ve `lag≥1` taşır.
3. Aynı generation'da node'dan kendisine, ebeveynine veya daha eski bir node'a doğrudan geri dönüş yasaktır.
4. Her recurrent edge'in kaynak node'u, hedef portu, state-cell ID'si ve lag değeri tekil olmalıdır.
5. State-cell Q çıkışı generation ilerletme semantiği olmadan E0 ağına doğrudan eklenemez.

## B. Dallanma kuralları

6. Her kaynak çıkışı en fazla iki downstream portu doğrudan besleyebilir; daha fazlası hiyerarşik FORK/BUFFER ağaçlarıyla yapılır.
7. Bir çıkış iki kola ayrılırken iki ayrı elektriksel sürücü çıkışı gerekir. Pasif bölücüde `I_in = I_A + I_B + I_loss`; her iki kola aynı tam genlikli kopya garanti edilemez.
8. Her branch ayrı branch ID/port kimliğine sahip olmalıdır; A/B dal kimliği downstream'de kaybolamaz.
9. Bir branch token'ı yalnız bir kez tüketilir; çoğaltma gerekiyorsa FORK açıkça iki child token oluşturur.
10. Bir branch iptal edilirse iptal/flush olayı onun bekleyen join girişine ulaşmalıdır; eksik branch sessizce yok sayılamaz.

## C. Fan-in ve birleşme

11. Her fonksiyonel node'un doğrudan fan-in'i en fazla 2'dir. Daha büyük fan-in, ağaç biçimli join/sum kademelerine ayrılır.
12. `MUX_SELECT`, `SYNC_JOIN`, `ARBITER_JOIN` ve `WEIGHTED_SUM` ayrı hücre tipleridir; birbirinin yerine kullanılamaz.
13. SYNC_JOIN yalnızca aynı parent token ve aynı generation'a ait tüm zorunlu operandlar gelince ilerler.
14. ARBITER_JOIN alternatif isteklerden yalnız birine grant verir. İki çıkış aynı anda grant olamaz. Yakın eşzamanlı isteklerde metastabilite çözüm süresi sınırsız olabilir; güvenlik ve liveness ayrı raporlanır.
15. WEIGHTED_SUM yalnız tanımlı akım toplama hücresi, ağırlık aralığı ve headroom hesabı ile kurulabilir. İki akımı aynı nete bağlamak toplama hücresi değildir.
16. Bir node aynı anda SELECT ve SUM semantiğini uygulayamaz; gerekiyorsa iki ayrı seri node kullanılır.

## D. Elektriksel kurallar

17. Her diferansiyel P/N çifti için tek sürücü vardır.
18. P ve N hatları ters çevrilirse polarity metadata ve test pinout birlikte güncellenir.
19. Her yeni branch için çıkış yükü, bias, akım bütçesi ve ölçüm noktası tanımlanır.
20. ECL/PECL terminasyonları, BJT-CML state-cell'in yüklenmesiyle aynı kabul edilmez. Her cell kendi topolojisine göre boyutlandırılır.

## E. State-cell yazma ve reset

21. Her state-cell'in tek bir yazma kaynağı vardır.
22. İki yazma isteği gelirse arbiter olmadan seçim yapılmaz; ikinci istek FAULT/WAIT durumuna alınır.
23. `WE` aktifken D± kararlı olmalıdır; setup/hold ve minimum capture window SPICE/ölçümle belirlenir.
24. Q± kararlılığı ve capture completion ayrı ölçülür; ACK veri yakalama onayıdır, optimizasyonun yakınsadığı anlamına gelmez.
25. Power-on reset garanti edilmez. Her state-cell bilinen değere kontrollü bir WRITE/RESET işlemiyle alınır.

## F. Hard reject koşulları

- Aynı generation kombinasyonel cycle.
- State-cell olmadan recurrent edge.
- Aynı diferansiyel çiftte iki sürücü.
- İzin verilen fan-in/fan-out limitinin aşılması.
- Kaynağı belirsiz ya da aynı nesle ait olmadığı doğrulanamayan join operandı.
- State-cell'e arbiter olmadan çoklu yazma.
- Ölçülmemiş analog toplama veya belirsiz bias bağlantısı.
