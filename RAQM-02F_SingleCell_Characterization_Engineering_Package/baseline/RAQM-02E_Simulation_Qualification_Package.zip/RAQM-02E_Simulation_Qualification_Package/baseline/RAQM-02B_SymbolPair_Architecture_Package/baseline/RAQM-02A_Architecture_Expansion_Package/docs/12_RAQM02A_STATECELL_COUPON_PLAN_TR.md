# 12 — RAQM-02A Tek State-Cell Test Kuponu

## 1. İlk hedef

Tek bir statik diferansiyel CML state-cell'in WRITE/HOLD davranışını fiziksel olarak doğrulamak. Henüz 2×2 mesh, analog problem çözücü veya genel optimizasyon çekirdeği yapılmaz.

## 2. Fonksiyonel bloklar

- U1: DATA differential pair package (U1A/U1B).
- U2: cross-coupled HOLD pair package (U2A/U2B).
- U3: differential WRITE/HOLD steering pair package (U3A/U3B).
- Q1: tail current sink transistor.
- RL_P/RL_N: collector loads.
- Adjustable `VCM_DATA`, `VCM_WE`, `VBIAS_TAIL`.
- High-impedance Q_P/Q_N measurement pads.

## 3. Test kartı arayüzü

| Connector | Pin | Net | Direction |
|---|---:|---|---|
| J1 | 1 | D_P | Instrument → cell |
| J1 | 2 | D_N | Instrument → cell |
| J1 | 3 | GND | Common |
| J2 | 1 | WE_P | Instrument → cell |
| J2 | 2 | WE_N | Instrument → cell |
| J2 | 3 | GND | Common |
| J3 | 1 | Q_P | Cell → differential probe |
| J3 | 2 | Q_N | Cell → differential probe |
| J3 | 3 | GND | Common |
| J4 | 1 | +3V3 | Supply input |
| J4 | 2 | GND | Supply return |
| J4 | 3 | VBIAS_TAIL | Adjustable bias |
| J4 | 4 | VCM_DATA | Adjustable common-mode |
| J4 | 5 | VCM_WE | Adjustable common-mode |

D_P/D_N ve WE_P/WE_N'e bağlanan kaynakların differential amplitude ve common-mode seviyesi ayarlanabilir olmalıdır. Üretici seviye çevirici arayüzü bu revizyonda henüz seçilmemiştir.

## 4. Test noktaları

- `TP_VDD`, `TP_GND`, `TP_VBIAS_TAIL`.
- `TP_D_P`, `TP_D_N`, `TP_WE_P`, `TP_WE_N`.
- `TP_Q_P`, `TP_Q_N`.
- `TP_E_DATA`, `TP_E_HOLD`, `TP_E_SELECT` (yüksek empedanslı probe; parazitik yük kayıt altına alınır).
- `TP_I_TAIL`: tail akımı seri ölçüm direnci veya ammeter fixture üzerinden.

## 5. Ön BOM ve belirsizlikler

BOM `hardware/BOM_RAQM02A_STATECELL.csv` içindedir. Matched NPN adayları seçilmiştir; RL, RE, bias aralıkları ve source level'ları SPICE sweep öncesi dondurulmaz. Footprint/pin mapping Nexperia datasheet'e göre KiCad'de ayrıca kontrol edilir.

## 6. PCB geometrisi

Kat planı 4 katmanlı konsepttir:

- L1: U1–U3, RL ve kısa diferansiyel bağlantılar.
- L2: kesintisiz GND.
- L3: +3V3, bias dağıtımı ve düşük frekanslı kontrol dönüşleri.
- L4: J1–J4 erişim ve yardımcı test sinyalleri.

Bu, fabrika stack-up'ı veya empedans çözümü değildir. Sinyal yolunu kısa tutmak önceliktir. Yüksek hızlı hedef ancak S-parametre/ölçüm sonrasında tanımlanır.

## 7. İlk test sırası

1. BOM/pinout ve footprint doğrulama.
2. Transistor-level DC operating point: tüm cihazlar aktif bölgede mi?
3. DC sweep: data differential polarity → Q polarity.
4. WRITE/HOLD geçişi: D değişirken HOLD modunda Q sabit kalıyor mu?
5. Capture window ve minimum WE süresi.
6. Retention ve sıcaklık drift.
7. Read-disturb ve ölçüm probu loading.
8. Setup/hold ve metastability window sweep.
9. I_TAIL/R_L/V_CM taraması.
10. PVT ve Monte Carlo mismatch.

## 8. Üretim statüsü

`RAQM-02A_StateCell_Coupon_Floorplan.svg` yalnız kat planıdır. Üretim için önce transistor-level şema, SPICE, gerçek KiCad schematic/PCB, footprint kontrol, DRC, 3D, fabrication drawing, Gerber ve drill dosyaları gerekir.
