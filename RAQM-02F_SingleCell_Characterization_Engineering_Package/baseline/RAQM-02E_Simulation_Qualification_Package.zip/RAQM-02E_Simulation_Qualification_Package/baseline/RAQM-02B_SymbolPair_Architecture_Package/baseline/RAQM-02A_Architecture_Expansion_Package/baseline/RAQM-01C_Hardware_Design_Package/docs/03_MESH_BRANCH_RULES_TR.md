# 03 — Mesh, Dallanma, Birleşme ve Geri Besleme: Normatif Kurallar

Bu kurallar mimarinin güvenlik ve kararlılık sözleşmesidir. Daha sonra yazılacak derleyici/kod oluşturucu bu kuralları donanım yapılandırmasına çevirecek; ancak bu pakette yazılım kodu yoktur.

## 1. Graf tanımı

Her hesaplama turu `n` bir epoch olarak etiketlenir. Düğüm kümesi `V`, kenarlar iki sınıftır:

- `E0`: aynı epoch içindeki sıfır-epoch-gecikmeli bağlantılar.
- `Er`: state-cell üzerinden en az bir epoch gecikmeli geri besleme bağlantıları.

`G0=(V,E0)` kesinlikle DAG olmalıdır. Tarihsel/geri besleme kenarı `e∈Er` için `lag(e)≥1` koşulu zorunludur.

## 2. Katı topoloji limitleri

1. Her veri düğümü için `fan-in ≤ 2`.
2. Her sürücü çıkışı için `fan-out ≤ 2`; bunun üstü ancak ayrı aktif buffer/current-copy hücresiyle mümkündür.
3. Her diferansiyel hat çifti tek sürücüye sahip olmalıdır. İki çıkış aynı P/N hattını süremez.
4. Birleştirme, iki diferansiyel hattı doğrudan birbirine bağlamak değildir. Birleşme MUX seçimi veya tanımlı akım-toplama hücresi üzerinden yapılır.
5. MUX seçimi ile akım-toplama aynı operasyon olarak kabul edilmez.
6. Her state-cell tek bir yazma kaynağı ve tek bir tanımlı okuma yolu taşır; çoklu yazma kaynakları arbiter/selector olmadan yasaktır.
7. Aynı epoch içinde düğümden kendisine, geçmiş düğüme veya bir önceki dallanma noktasına sıfır-delay geri dönüş yasaktır.
8. Bir dalın kimliği, kaynak düğümü, hedef düğümü, epoch numarası ve gecikme sınıfı kaybolmadan korunur.

## 3. Recurrent örnek topoloji

`N0[n] → N1[n]` ve `N0[n] → N2[n]` ile iki dal açılır. `N1[n]` ve `N2[n]` ayrı girişler olarak `N3[n]` üzerinde birleşir. Sonra `N3[n]` sonucu `S0` durum hücresine yazılır ve `S0` çıktısı `N0[n+1]` girdisine geri döner. Ayrıca `N2[n]` sonucu `S1` hücresine yazılır ve `S1` çıktısı `N1[n+1]` için çapraz besleme olur.

Böylece dallar yalnızca ileri doğru uzamaz; önceki dallanma ve birleşme noktalarına geri döner. Fakat fiziksel döngü `S0/S1` state-cell sınırından geçer.

## 4. Dallanma akım bütçesi

Pasif bir akım bölücüde:

`I_source = I_A + I_B + I_loss`

ve `I_A + I_B ≤ I_source` olmalıdır. İki dala da aynı genlikte kopya gerekirse aktif buffer/current-mirror kopyalama hücresi gerekir ve her kopyanın bias/güç bütçesi ayrı hesaplanır. Bir dalın ikiye ayrılması akımı bedelsiz iki katına çıkarmaz.

## 5. Çapraz bağlantı kuralı

`N2 → N1` gibi çapraz besleme yalnızca:

- ayrı bir diferansiyel bağlantı çifti,
- tanımlı state-cell gecikmesi,
- tek sürücü/tek alıcı kontrolü,
- reset ve handshake sırası,
- ölçülebilir test noktası

bulunduğunda kabul edilir. Çapraz tel aynı anda N1'in normal A/B girişlerinden birinin üstüne bağlanamaz.

## 6. Birleşme kuralı

İki dalın verisi seçim gerektiriyorsa 2:1 MUX kullanılır. İki akımın aynı anda etkisi isteniyorsa özel diferansiyel current-summing hücresi tanımlanır. Summing hücresinin transconductance, bias, giriş empedansı, çıkış headroom ve lineer çalışma aralığı karakterize edilmeden “süperpozisyon” veya “ağırlıklı toplama” yapılmış sayılmaz.

## 7. Reset ve hata davranışı

- Açılışta tüm state-cell'ler tanımlı başlangıç durumuna alınmalıdır.
- Reset sırasında REQ kabul edilmez.
- Aynı node'a iki eşzamanlı yazma isteği hata durumudur; öncelik politikası açıkça tanımlanmadan deterministik sonuç iddia edilmez.
- ACK yükselmeden önce payload değişirse işlem iptal edilir veya FAULT üretilir.
- Diferansiyel pair geçersiz ortak-mod/salınım bölgesindeyse node sonucu geçerli sayılmaz.

## 8. İhlal sınıfları

- **Hard reject:** aynı epoch çevrimi, çift sürücü, fan-in/fan-out limitinin ihlali, state-cell'siz tarihsel dönüş.
- **Electrical reject:** eşleşmemiş diferansiyel hat, yanlış VTT, yük limiti aşımı, yanlış seviye.
- **Review required:** aktif akım kopyalama, analog sum, yönlü geri besleme, büyük fan-out, asimetrik coupling.
