# RAQM-01C — Donanım Mimarisi ve PCB Revizyon Paketi

**Tam ad:** Recurrent Asynchronous Qudit Mesh — Hardware Design Revision C  
**Tarih:** 17 Kasım 2026  
**Sahip:** Oğuz Kağan Sayın  
**Aşama:** Donanım mimarisi + elektriksel ön tasarım + KiCad ön yerleşim  
**Üretim durumu:** Üretime hazır değildir; iz yönlendirme, ERC/DRC, SPICE ve laboratuvar doğrulaması tamamlanmamıştır.

## Bu revizyonun amacı

RAQM artık genel amaçlı bir işlemci olarak değil, daha sonra özel işlemci mimarisine dönüşmesi hedeflenen **clockless, host-yardımlı bir ön-hızlandırıcı çekirdeği** olarak ele alınır. Bu pakette yazılım, uygulama kodu, referans yürütücü veya kod oluşturucu bulunmaz. Programlama dili ve bu dile özel kod oluşturucu, fiziksel mimari doğrulandıktan sonra ayrı bir çalışma paketi olacaktır.

RAQM-01C üç şeyi bir araya getirir:

1. **Bugünkü ölçülebilir prototip:** 2×MC100EP56, 4×MC100EPT22 ve 2×MC100EPT23 ile dört diferansiyel 2:1 seçim düğümü; iki adet iki-bit/four-symbol çıktı grubu.
2. **Doğru elektriksel altyapı:** LVPECL/ECL hat sonlandırmaları, ayrı 1,30 V VTT hattı, güç ayrımı, test noktaları ve dört katmanlı PCB yerleşim kısıtları.
3. **Bir sonraki gerçek mimari:** Yerel diferansiyel CML durum hücreleri üzerinden gecikmeli geri-besleme, dalların çapraz bağlanması, iki-yollu dallanma/birleşme ve yakınsama denetimi.

## Paket içeriği

- `docs/` — 13 mimari/elektriksel belge: sistem, CML düğümü, qudit kodlaması, dallanma kuralları, asenkron kontrol, DRNC/Zerya modeli, kararlılık, PCB ve RAQM-02 atomik state-cell şartnamesi.
- `hardware/` — güncellenmiş BOM, pin/net tablosu, 24 terminasyon direnci eşlemesi, KiCad ön-yerleşim dosyası, sistem/mesh/state-cell blok şemaları ve PCB kat planı SVG/PNG.
- `validation/` — üretim öncesi kontrol listesi, bench test sırası, kabul matrisi ve risk kaydı.
- `references/` — üretici veri sayfaları ve tasarım referansları.
- `decisions/` — tasarım kararları ve sürüm kayıtları.

## Ana mimari sınırları

- Hızlandırıcı veri çekirdeğinde global clock veya osilatör yoktur. Harici host kendi saatini kullanabilir.
- Bu revizyonda program sayacı, genel RAM, işletim sistemi veya komut yürütme çekirdeği yoktur.
- `00`, `01`, `10`, `11` şu an **iki diferansiyel bitin oluşturduğu klasik dört sembollü elektriksel kodlamadır**. Kuantum süperpozisyonu, dolanıklık veya kuantum donanım iddiası değildir.
- Bugünkü entegreler PECL/ECL current-steering ailesindedir. Bunlar özel üç-gate transistör veya özelleştirilmiş saf CML latch değildir.
- Bugünkü kartta geçmişe dönüş host tarafından yeniden-enjeksiyonla yapılır. Yerel, fiziksel geri-besleme saklama hücreleri sonraki donanım revizyonunun hedefidir.
- “Fiziksel rezonansla her problemi anında çözme”, “sıfır gecikme” ve “sub-millisecond garanti” iddiaları bu paket tarafından yapılmaz.

## Üretim uyarısı

`hardware/RAQM-01C_PreLayout.kicad_pcb` gerçek footprint, pad ve net adlarını içeren bir **ön yerleşim** dosyasıdır; izleri yönlendirilmemiştir. DRC/3D/ERC ve üretici stack-up kontrolü yapılmamıştır. Bu nedenle Gerber, drill veya pick-and-place çıktısı değildir. Özellikle VTT hattı, terminasyonlar, EP56 bütün besleme pinleri ve host güç izolasyonu bağımsız olarak kontrol edilmeden karta güç verilmemelidir.

## Önerilen ilerleme

RAQM-01C kartının düşük hızlı/temel ölçüm doğrulaması → sinyal bütünlüğü ve VTT doğrulaması → bir CML diferansiyel durum hücresinin transistor-level tasarımı ve SPICE doğrulaması → küçük 2×2 yerel mesh → daha büyük mesh. Yazılım ve derleyici bundan sonra tasarlanacaktır.
