# 13 — PCB Yerleşim, Katman ve Ölçüm Kuralları

## 1. Konsept kart

Önerilen kupon alanı yaklaşık 50×40 mm'dir; son ölçü konektör, probe ve assembly clearance sonrası belirlenir. Kart tek state-cell içerir. Aynı PCB üzerine henüz iki veya daha fazla latch eklenmez.

## 2. Fiziksel bölgeler

1. Sol kenar: D_P/D_N ve WE_P/WE_N giriş konektörleri.
2. Merkez: U1 DATA, U2 HOLD, U3 WE steering transistor array'leri.
3. Alt merkez: Q1 tail current sink ve emitter sense.
4. Üst merkez: RL_P/RL_N ve Q_P/Q_N kısa test yolları.
5. Sağ kenar: high-impedance differential output probe footprint/pad.
6. Kenar/alt: VDD, GND, VBIAS_TAIL, VCM_DATA, VCM_WE girişleri.

## 3. Diferansiyel routing

- P/N aynı katmanda, komşu, benzer uzunlukta ve aynı via sayısında.
- P/N altındaki GND düzlemi bölünmez.
- Collector output netleri gereksiz test pad/uzun stub ile yüklenmez.
- Feedback çapraz bağlantıları kısa tutulur; latch çiftinin collector/base çapraz bağlantı simetrisi korunur.
- Bias/ITAIL hatları Q output hatlarından ayrılır; decoupling local olur.

## 4. Probe ve terminasyon

Çıkış ilk olarak 1 MΩ sınıfı yüksek empedanslı diferansiyel probla gözlenir. 50 Ω osiloskop girişi veya SMA kablo doğrudan Q_P/Q_N'e bağlanmaz; bu yük için özel sürücü/terminasyon tasarlanmalıdır. Giriş tarafında kullanılan source terminasyonu, source impedance ve common-mode topolojisine göre hesaplanır.

## 5. Gerber öncesi zorunlu kontroller

- Nexperia BCM847BS SOT363 pin numbering ve pin-1 doğrulaması.
- U1/U2/U3 matched-pair orientation.
- Collector/base cross-coupling netlist check.
- Tüm tail source polarite ve current path doğrulaması.
- Power, bias, ground short check.
- ERC/DRC, 3D clearance, solder-mask, courtyard.
- L2 GND kesintisizliği.
- Probe landing pad clearance ve düşük kapasitans.
- Üretici stack-up/gerber review.

Bu kontroller yapılmadan kart üretim dosyası oluşturulmuş sayılmaz.
