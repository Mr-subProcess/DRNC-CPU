# 15 — Sonraki Revizyonlar ve Kod Oluşturucuya Geçiş Kapısı

## Aşama 1 — RAQM-02A tek state-cell

Tek bir BJT-CML latch test edilir. Write/hold ve retention doğrulanır. Bu aşamada programlama dili veya kod üretilmez.

## Aşama 2 — RAQM-02B iki hücreli recurrent çift

İki state-cell çapraz beslenir. Her recurrent kenar state-cell gecikmesi taşır. Bir state-cell'den diğerine geçmiş branch aktarımı ve edge-local REQ/ACK doğrulanır.

## Aşama 3 — RAQM-03 2×2 mesh

FORK, SYNC_JOIN, ARBITER_JOIN, BUFFER, STATE_CELL ve FAULT_GUARD blokları fiziksel olarak tamamlanır. Aynı-generation DAG, backpressure ve token lineage doğrulanır.

## Aşama 4 — RAQM-04 weighted-sum/relaxation

Akım toplama hücresi, ağırlık aralığı, transfer eğrisi, enerji/güç, saturation ve yakınsama detektörü eklenir. Simetrik ve yönlü feedback modları ayrı karakterize edilir.

## Aşama 5 — RAQM-05 mimari dondurma

Bütün fiziksel node tipleri, port levels, bias windows, fanout limits, handshake semantics, state retention, fault model ve performance envelopes belgelenir. Ancak bu kapı geçildikten sonra özel dil ve uzamsal kod oluşturucu yazılır.

## Kod üreticiye geçiş kriterleri

- Her node type için gerçek hücre ya da açıkça unsupported durumu.
- Ölçülmüş voltage/current/headroom/bias range.
- Tek sürücü ve fanout/branch kısıtları.
- Recurrent edge lag/state allocation.
- Join/arbiter/sum semantics.
- Asynchronous handshake contract.
- Reset/fault/timeout davranışı.
- SETTLED metric and workload criterion.
- Physical placement/routing capacity.

Bunlardan biri eksikse compiler eksik fiziksel kabiliyeti hayal ederek oluşturmamalıdır.
