# 08 — Kararlılık, Yakınsama ve Fiziksel Çözüm Sınırları

## 1. Üç ayrı davranış

1. **Latch stability:** tek state-cell'in Q+ / Q− durumlarından birini tutması.
2. **Network stability:** birden çok recurrent cell'in geri besleme altında salınıma kaçmadan sınırlı kalması.
3. **Optimization convergence:** belirli amaç fonksiyonunun uygun denge noktasına ulaşması.

Birincinin doğrulanması ikinciyi, ikincinin doğrulanması üçüncüyü kanıtlamaz.

## 2. Muhafazakâr kontraksiyon kontrolü

İdealize edilmiş gecikmeli ayrık modelde:

`x_i[g+1] = φ_i(Σ_j Σ_{ℓ=0..L} W_ij^(ℓ) x_j[g−ℓ] + b_i)`

`φ` için Lipschitz sabiti `L_φ` olsun. Bir yeterli tasarım hedefi:

`q = L_φ · max_i Σ_j Σ_{ℓ=0..L} |W_ij^(ℓ)| < 1`.

Bu norm şartı ideal modelde kontraktif davranış için muhafazakâr bir sınır verir. Gerçek gecikme, doygunluk, transistor parazitleri, bias drift ve metastabiliteyi tek başına garanti etmez.

## 3. Enerji/relaksasyon modu

Bir analog ağın enerji azalışı iddiası için örnek:

`E(x)=Σ_i U_i(x_i) − 1/2 xᵀ W x − bᵀx`

Eğer `W=Wᵀ`, mobilite matrisi `M` pozitif tanımlı ve fiziksel dinamik `dx/dt=−M∇E` biçimindeyse:

`dE/dt = −(∇E)ᵀ M (∇E) ≤ 0`.

Yönlü/asimetrik ve gecikmeli feedback mesh'i otomatik olarak bu gradient-flow şartlarını sağlamaz. Bu nedenle:

- `MEMORY/RECURRENT` modu yönlü ve gecikmeli olabilir.
- `RELAXATION/OPTIMIZATION` modu için karşılıklılık veya ayrı Lyapunov kanıtı gerekir.
- İki mod birleştirilirse bütünleşik kararlılık analizi zorunludur.

## 4. Fiziksel rezonans hakkında

Clockless yapı, osilatörsüz/asenkron kontrol hedefidir; “rezonans” otomatik olarak çözüm bulma mekanizması değildir. Rezonans salınım üretir. Optimizasyon için hedef; tanımlı amaç fonksiyonu, sönüm, denge kararlılığı ve sonuç ölçümüdür. Bu yüzden ilk RAQM prototiplerinde terim olarak **analog relaxation / settle** kullanılacaktır.

## 5. SETTLED kriteri

Bir analog işlem ancak aşağıdaki koşullar birlikte sağlanırsa `READY_SETTLED` alabilir:

- İlgili tüm state-cell'ler capture-ready.
- `|dx_i/dt| < ε_i` veya eşdeğer ölçülebilir değişim sınırı.
- Amaç/residual: `|r(x)| ≤ ε_r`.
- Tüm kısıt ihlalleri izin verilen sınır altında.
- Bu koşullar qualification penceresi boyunca korunur.
- Hiçbir saturation, rail violation, oscillation, bias fault veya timeout yok.

Eşikler gerçek problem ölçeğine ve ölçüm gürültüsüne göre seçilir; şimdiden keyfi sabit verilmez.

## 6. Performans raporu

Sadece “hızlı” demek yeterli değildir. Her problem sınıfında: input-to-capture latency, settle time distribution, success probability, residual error, constraint violation, energy/solve, static bias power, temperature drift, restart rate ve host transfer overhead raporlanmalıdır.
