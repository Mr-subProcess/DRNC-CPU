# İlk Kart Açılış Kontrol Listesi

**Bu listeyi tamamlamadan kartı enerjilendirmeyin.**

- [ ] PCB ve şema revizyonu eşleşiyor.
- [ ] Tüm EP56 VCC/VEE pinleri doğrulandı.
- [ ] U1–U4, U7–U8 pin-1 yönleri kontrol edildi.
- [ ] J1 pin20 NC; host ve kart 3,3 V hatları paralel değil.
- [ ] 24 terminasyon direnci ve VTT netleri kontrol edildi.
- [ ] VTT kaynağının akım sink kapasitesi belgeli.
- [ ] VTT=1,30 V nominal, +3V3=3,30 V nominal.
- [ ] GND ortak ve düşük endüktanslı bağlantı mevcut.
- [ ] Tüm girişler default duruma çekilmiş; açıkta kalan hızlı pin yok.
- [ ] Akım limiti düşükten başlatıldı.
- [ ] İlk açılışta tüm raylar ve cihaz sıcaklıkları ölçülüyor.
- [ ] İlk test yalnız düşük veri değişim hızında yapılacak.
- [ ] Diferansiyel hatlar uygun probla ölçülecek.
