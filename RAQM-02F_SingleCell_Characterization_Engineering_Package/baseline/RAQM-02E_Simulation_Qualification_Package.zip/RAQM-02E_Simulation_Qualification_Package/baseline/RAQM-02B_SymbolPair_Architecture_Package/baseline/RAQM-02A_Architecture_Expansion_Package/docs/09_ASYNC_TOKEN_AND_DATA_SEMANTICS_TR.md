# 09 — Token, Branch Kimliği, Qudit ve Veri Semantiği

## 1. Token alanları

Gelecekteki donanım yapılandırıcısının bilmesi gereken soyut alanlar:

- `node_id`: token'ın bulunduğu node.
- `edge_id`: hangi fiziksel bağlantıda olduğu.
- `branch_id`: A/B veya başka child branch kimliği.
- `parent_id`: token'ın hangi fork'tan çıktığı.
- `generation`: mantıksal işlem nesli.
- `payload_format`: 1-bit, 2-bit sembol, diferansiyel analog değer veya operand çifti.
- `polarity`: P/N yorum yönü.
- `valid/cancel`: transferin aktif veya iptal edilmiş durumu.

Bu alanların hepsi ilk kuponda fiziksel binary register olarak uygulanmaz. Tek outstanding token'lı ilk kartta port ve kablo kimliği branch ayrımını taşır. Çoklu eşzamanlı token için ek slot/tag mimarisi gerekir.

## 2. İki-bit / dört-sembol kodlama

| Sembol | b1 | b0 |
|---|---:|---:|
| 00 | 0 | 0 |
| 01 | 0 | 1 |
| 10 | 1 | 0 |
| 11 | 1 | 1 |

Bir sembol iki bağımsız diferansiyel pair ile temsil edilir. `00/01/10/11`, bu kartta klasik elektriksel koddur; kuantum süperpozisyon veya dolanıklık değildir.

## 3. Analog state ve dijital sembol farklı katmanlar

Dijital sembol `00…11` ile normalize diferansiyel analog state `x∈[-1,1]` aynı representation değildir. Bir analog node için voltage/current range, threshold, noise margin, linearity ve quantization kararı ayrı verilmelidir. İki-bit kodu dört analog seviyeli tek iletkenmiş gibi yorumlamak yasaktır.

## 4. Reset, flush ve stale token

Bir join'a gelen operandlar aynı parent/generation eşleşmesine sahip olmalıdır. Reset/flush sırasında bekleyen branch token'ları iptal edilir ve join slotları boşaltılır. Eski token'ın yeni işlemle karışmaması için çoklu outstanding işlem hedefinde tag/slot yeniden kullanım politikası zorunludur.
