# RAQM-02A — Mimari Genişletme ve Yerel CML Durum Hücresi Paketi

**Tam ad:** Recurrent Asynchronous Qudit Mesh — Architecture Expansion A  
**Tarih:** 17 Kasım 2026  
**Sahip:** Oğuz Kağan Sayın  
**Aşama:** Mimari genişletme + durum hücresi ön tasarımı + prototip test kartı kat planı  
**Üretim durumu:** Üretime hazır değildir. PCB kat planı konsepttir; transistor-level SPICE, gerçek şematik, ERC/DRC, iz yönlendirme ve laboratuvar karakterizasyonu tamamlanmamıştır.

## Bu sürümdeki temel karar

RAQM ilk aşamada bir **ön-hızlandırıcı** olarak geliştirilir. Genel amaçlı CPU, işletim sistemi, program sayacı veya host belleği yerine geçme iddiası yoktur. Bu sürümün işi, sonraki işlemci mimarisinin fiziksel temellerini doğru kurmaktır.

**Bu pakette hiçbir programlama/uygulama kodu, simülatör, derleyici veya kod oluşturucu yoktur.** Özel programlama dili ve ona ait kod oluşturucu, fiziksel düğüm, durum hücresi, handshake ve ölçüm semantiği dondurulduktan sonra ayrı bir aşamada geliştirilecektir.

## RAQM-02A'da ne geliştirildi?

1. **Dallanma topolojisi:** dallar yalnız ileri gitmez; dallar arası çapraz besleme ve geçmiş dallara dönüş açık düğüm/kenar kimlikleriyle tanımlandı.
2. **Katı bağlantı kuralları:** aynı nesil içindeki çevrimsiz grafik, gecikmeli recurrent kenarlar, fan-in/fan-out, tek sürücü, tek-yazıcı ve birleşme semantiği normatifleştirildi.
3. **Yerel fiziksel durum:** host replay yerine statik diferansiyel CML latch/state-cell hedefi tanımlandı.
4. **Asenkron kontrol:** her bağlantıya ayrı REQ/ACK; veri yakalama onayı, analog yakınsama onayından ayrıldı.
5. **DRNC + dallanan Zerya:** yönlendirme, dallanma, birleştirme, akım bölme, akım toplama ve tarihsel durum matematiksel olarak birbirinden ayrıldı.
6. **İlk state-cell prototipi:** üç eşleştirilmiş NPN diferansiyel çift paketi (`U1/U2/U3`) ve kuyruk akım transistörü (`Q1`) kullanan CML latch adayı tanımlandı.
7. **Kontrol düzlemi:** dört-fazlı edge handshake, C-element davranış sözleşmesi, FORK ACK ve SYNC_JOIN ayrımı eklendi. İlk kuponda fiziksel C-element bulunmadığı açıkça belirtildi.
8. **Dört-sembol kodlama:** bir state-cell'in tek diferansiyel bit tuttuğu; `00/01/10/11` için iki hücre ve `PAIR_VALID` görünürlük kapısı gerektiği belirlendi.
9. **Olay durum makinesi:** RESET_REQUIRED, WRITE_ARMED, TRACK, CAPTURE_CHECK, HOLD ve FAULT durumları tanımlandı.
10. **Kaynak bütçesi:** statik tail-current gücü, aktif fork maliyeti, headroom ve mesh ölçekleme kapıları dokümante edildi.
11. **Pin-level wiring:** BCM847BS ve BC847B üretici pin eşlemeleriyle U1/U2/U3/Q1 net atama tablosu eklendi; şematik/netlist onay kapıları belirlendi.
12. **Doğrulama:** SPICE, transistor eşleşmesi, metastabilite, hold retention, read-disturb, güç, termal ve PCB testleri için kabul matrisi eklendi.

## Ürün sınırı

- `RAQM-01C`: dört PECL/ECL MUX kanalı ve iki adet klasik dört-sembollü çıkış taşıyan host-yardımlı yönlendirme demonstratörü.
- `RAQM-02A`: tek hücreli gerçek transistor seviyesinde CML durum saklama prototipi için tasarım şartnamesi ve test kartı kat planı.
- `RAQM-02B`: birden çok state-cell içeren küçük, çapraz bağlı yerel mesh.
- `RAQM-03`: ayrık dallar, rendezvous join, arbiter ve kontrollü recurrent ağı.
- `RAQM-04`: ağırlıklı akım toplama ve sınırlı analog relaksasyon/optimizasyon.
- `RAQM-05`: ölçümleri tamamlanmış genişletilmiş ön-hızlandırıcı ve ancak sonrasında mimariye özel programlama dili/kod oluşturucu.

## Dizin yapısı

- `docs/` — mimari ve fiziksel tasarım şartnameleri.
- `hardware/` — test kartı BOM taslağı, pin arayüzü, test noktaları, topoloji ve SVG/PNG devre/PCB çizimleri.
- `validation/` — test matrisi, bring-up kontrolü ve kabul koşulları.
- `decisions/` — mimari karar kaydı.
- `references/` — parça veri sayfaları ve asenkron/CML teknik kaynakları.
- `baseline/RAQM-01C_Hardware_Design_Package/` — önceki donanım paketi; tarihsel tasarım ve PCB ön-yerleşimi.

## Güvenlik ve üretim uyarısı

`hardware/RAQM-02A_StateCell_Coupon_Floorplan.svg` ve buna ait çizimler **yerleşim/işlev kat planıdır**, Gerber veya üretim PCB'si değildir. Transistor bias değerleri ve dirençler SPICE/tezgâh ölçümüyle seçilmeden kart imal edilmemelidir. `baseline/` içindeki RAQM-01C KiCad dosyası da yalnız ön-yerleşimdir; üretime hazır değildir.

> Clockless, zamansız demek değildir. Global periyodik clock yoktur; fakat transistor gecikmeleri, analog geçişler, metastabilite çözülme süreleri ve handshake olayları fiziksel zaman içinde gerçekleşir.
