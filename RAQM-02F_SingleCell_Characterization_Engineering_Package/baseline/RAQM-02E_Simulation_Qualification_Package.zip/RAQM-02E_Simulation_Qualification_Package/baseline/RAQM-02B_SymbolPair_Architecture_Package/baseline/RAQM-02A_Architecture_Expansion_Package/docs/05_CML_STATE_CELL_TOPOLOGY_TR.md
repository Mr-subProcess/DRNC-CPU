# 05 — Yerel Diferansiyel CML State-Cell

## 1. Amaç

Bu hücre, diferansiyel veriyi `WRITE` olayı sırasında yakalar; `HOLD` modunda kendi çapraz bağlı geri beslemesi ile besleme açık kaldığı sürece korur. Böylece recurrent mesh geçmişi host RAM/replay yerine yerel fiziksel hücrede tutabilir.

**Hücre statik ve uçucudur:** güç kesilince bilgi kaybolur. HOLD sırasında tail current devam edeceği için statik güç tüketir. Bu bir SRAM/flash hücresi değildir.

## 2. Aday transistor topolojisi

Önerilen işlevsel yapı, klasik CML track/hold latch'in asenkron kullanımına dayanır:

- `U1A/U1B — DATA pair (package U1)`: D_P/D_N girişini diferansiyel biçimde algılar.
- `U2A/U2B — HOLD pair (package U2)`: Q_N/Q_P çıktılarından çapraz bağlı geri besleme alır ve son durumu yeniler.
- `U3A/U3B — MODE steering pair (package U3)`: diferansiyel WE_P/WE_N kontrolü ile sabit kuyruk akımını DATA veya HOLD koluna yönlendirir.
- `Q1 — tail current sink`: ortak bias akımını belirler.
- `RL_P/RL_N`: collector yükleri; Q_P/Q_N diferansiyel çıkışlarını oluşturur.

`WRITE` durumunda akım DATA pair'e; `HOLD` durumunda HOLD pair'e yönlendirilir. Bu, global saatle çalışan flip-flop değildir. WE kontrolü REQ/ACK protokolünden gelen olay/level bilgisidir. Kontrol geçişlerinin birbirini dışlaması ve metastabilite davranışı ölçülmelidir.

## 3. Eşleştirilmiş transistor adayı

İlk kupon için Nexperia `BCM847BS` (SOT363 içinde eşleştirilmiş iki NPN transistor) adaydır. Üretici 15 Temmuz 2026 veri sayfasında eşleştirilmiş NPN çiftini, V_BE eşleşmesi için en çok 2 mV değerini ve 10 mA / V_CE=5 V koşulunda 250 MHz tipik f_T değerini verir. Bu rakam bu kartın çalışma frekansı değildir; farklı bias ve PCB parazitlerinde ölçüm gerekir. `BC847B` tek NPN transistor tail-sink adayıdır.

## 4. Aday hücre bileşen tablosu

| Referans | İşlev | Aday |
|---|---|---|
| U1 | DATA differential pair | BCM847BS, matched NPN pair |
| U2 | HOLD cross-coupled pair | BCM847BS, matched NPN pair |
| U3 | WRITE/HOLD steering pair | BCM847BS, matched NPN pair |
| Q1 | Tail current sink transistor | BC847B, NPN |
| RL_P/RL_N | Collector loads | Değeri SPICE ile seçilecek; 680 Ω yalnız ilk sweep başlangıç adayı |
| R_E | Tail set resistor | VBIAS/temperature sweep sonrası belirlenecek |
| C_DEC | Local supply bypass | 100 nF + 1 µF footprint |

BOM'daki `680 Ω` ve `R_E` değerleri üretim değeri değildir. CML latch'in headroom, current split, common-mode, differential swing ve sıcaklık davranışı transistor-level transient/DC analiziyle seçilecektir.

## 5. Diferansiyel kontrol ve data bias

D_P/D_N ve WE_P/WE_N girişleri için ayrı common-mode ayarı gerekir. RAQM-01C LVPECL çıkışı bu hücreye otomatik olarak uyumlu varsayılmaz. İlk state-cell test kuponunda giriş common-mode ve differential amplitude laboratuvar kaynağından ayarlanabilir bırakılır. Sonraki revizyonda uygun level-shifter/receiver eklenecektir.

## 6. RESET semantiği

İlk test kuponunda ayrı bir POR devresi varsayılmaz. Bilinen başlangıç durumu, `WRITE` modunda belirlenmiş D_P/D_N değeri en az karakterize edilmiş capture süresince uygulanarak yüklenir. Reset isteği, normal WRITE işlemine göre önceliklidir; eşzamanlı host write kabul edilmez. Çok hücreli reset ağacı sonraki revizyonda tasarlanır.

## 7. Capture, retention ve read-disturb

- `CAPTURE`: WE geçişinden sonra Q_P/Q_N'in hedef diferansiyel eşiği geçmesi.
- `HOLD`: WE HOLD konumundayken D girişleri değişse dahi Q durumu korunmalı.
- `RETENTION`: besleme açıkken belirlenmiş süre boyunca state kaybı/bit flip olmamalı.
- `READ_DISTURB`: Q çıkışının izlenmesi veya bir sonraki kademeyi sürmesi saklanan durumu bozmamalı.
- `PAIR_COHERENCE`: iki state-cell birlikte iki-bit sembol tutuyorsa iki hücre aynı transaction altında capture edilmelidir.

## 8. Hazır olma sinyali

İlk kuponda `READY_CAPTURE` doğrudan iç transistor latch'ten üretilmiş ve karakterize edilmiş bir dijital garanti değildir; ölçüm comparator'ı harici test ekipmanında kurulabilir. Sonraki revizyonda differential threshold + qualification + C-element ile yerel capture-ready tasarlanacaktır. `READY_SETTLED` ise yalnız analog compute mesh'e aittir ve başka bir ölçüm katmanı gerektirir.

## 9. Pin-level bağlantı adayı

Kesin paket pin ve net eşlemeleri `hardware/STATECELL_TRANSISTOR_PIN_NET_MAP.csv` ve `docs/21_PIN_LEVEL_WIRING_CANDIDATE_TR.md` içindedir. U1/U2/U3 eşleştirilmiş BCM847BS paketleri; Q1 ise BC847B tek NPN olarak kullanılır. `D_P>D_N` ve `WE_P>WE_N` koşullarında aday output polaritesi `Q_P>Q_N` olacak şekilde çaprazlanmıştır.

## 10. Tasarımın açık kalan parametreleri

- VCC ve cihazların izin verilen common-mode/headroom bölgesi.
- D_P/D_N ve WE_P/WE_N differential swing/common-mode.
- I_TAIL, R_L ve tail sink uyumu.
- Track-to-hold / hold-to-track geçiş süresi.
- Minimum WE pulse/level süresi ve data setup/hold.
- Metastability çözülme dağılımı.
- Hold current ve güç tüketimi.
- PVT/mismatch toleransları.

Bu parametreler SPICE ve ölçüm olmadan “dondurulmuş” sayılmaz.
