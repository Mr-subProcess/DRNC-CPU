# 02 — Diferansiyel Düğüm, Akım Yönlendirme ve Dört Durumlu Sembol

## 1. Bir fiziksel veri kanalı

Bir kanal, tek gerilimli tel değildir; `P/N` diferansiyel çifttir. Mantık biti, iki hattın farkının işaretiyle tanımlanır:

- `b=1`: `V(P) > V(N)`
- `b=0`: `V(P) < V(N)`

Alıcı, ortak-mod gerilimini ve diferansiyel salınımı veri sayfasındaki aralıklarda görmelidir. P ve N hatlarının ikisi de aynı anda HIGH veya LOW yapılmaz; bu, diferansiyel sembol tanımını bozar.

## 2. Düğüm modeli

Her `N_i` düğümünde iki aday diferansiyel giriş bulunur:

- `A_i = (A_iP, A_iN)`
- `B_i = (B_iP, B_iN)`

Seçim sonucu:

- `SEL_i=1` → A_i
- `SEL_i=0` → B_i

Çıkış `Q_i=(Q_iP,Q_iN)` olur. İlk kartta her N düğümü bir MC100EP56 içindeki bir 2:1 diferansiyel MUX kanalına karşılık gelir.

## 3. Akım yönlendirme bakışı

CML/ECL diferansiyel çiftinde bilgi, akımın iki kol arasında dağılımıyla temsil edilir. Basitleştirilmiş ideal akım bütçesi:

`I_P + I_N ≈ I_TAIL`

ve diferansiyel akım:

`I_D = I_P − I_N`

Gerçek değerler transistor topolojisi, bias, yük, ortak-mod ve sıcaklıkla belirlenir. Bu eşitlik fiziksel devrenin SPICE modeli yerine geçmez; akımın iki kol arasında yönlendirildiğini tarif eder.

## 4. Dört durumlu qudit sembolü

İki bağımsız diferansiyel bit birlikte klasik dört-sembol durumunu verir:

| Sembol | b1 | b0 | Tamsayı kodu |
|---|---:|---:|---:|
| `00` | 0 | 0 | 0 |
| `01` | 0 | 1 | 1 |
| `10` | 1 | 0 | 2 |
| `11` | 1 | 1 | 3 |

`Qudit-A=(OUT1,OUT0)`, `Qudit-B=(OUT3,OUT2)` biçiminde gruplanır. Bit sırası her testte sabit tutulur. Bitleri farklı sırada okumak aynı elektriksel durumu farklı sembol olarak yorumlatır.

**Terminoloji uyarısı:** Bu pakette “qudit”, dört değerli klasik elektriksel sembol/kanal grubu anlamındadır. Kuantum durum vektörü, koherens, kuantum ölçüm veya dolanıklık iddiası yoktur.

## 5. Gerçek dört analog seviyeye geçiş ne demek?

İki diferansiyel bit ile `00/01/10/11` üretmek, tek bir fiziksel hat üzerinde dört analog seviyeye sahip olmakla aynı değildir. Gelecekte tek-akım-örgüsü üzerinde gerçek çok seviyeli sembol hedeflenirse:

- Dört seviyenin voltaj/akım sınırları tanımlanmalı.
- Level spacing, gürültü, sıcaklık ve mismatch payı hesaplanmalı.
- Dört-seviye alıcı/karar devresi tasarlanmalı.
- Gürültü ve tolerans altında symbol error rate ölçülmeli.

RAQM-01C bu hedefe sahip değildir; şimdiki dört sembol iki diferansiyel kanaldan oluşur.

## 6. Üç-gate transistör hedefi

Daha önce tarif edilen “üç gate girişinin tamamı HIGH olduğunda iletime geçme” elemanı bu karttaki standart entegrelerde bulunmaz. Bu davranış daha sonra özel transistor hücresi olarak tasarlanacaksa gate eşikleri, body/bulk bağlantısı, bias, kapasitans, leakage, breakdown ve üretim teknolojisi (CMOS/SOI/FinFET vb.) tanımlanmalıdır. Üç kontrol girişini yalnızca üç ayrı isimli tel olarak çizmek, fiziksel üç-gate transistör oluşturmaz.
