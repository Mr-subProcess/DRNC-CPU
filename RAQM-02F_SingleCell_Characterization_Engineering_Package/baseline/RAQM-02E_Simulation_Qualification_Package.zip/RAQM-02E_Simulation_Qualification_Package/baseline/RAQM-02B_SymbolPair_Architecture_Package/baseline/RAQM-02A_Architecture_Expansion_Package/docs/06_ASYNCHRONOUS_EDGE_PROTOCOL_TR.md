# 06 — Kenar Başına Asenkron Handshake

## 1. Temel ilke

REQ/ACK tüm mesh için tek ortak kablo değildir. Her data edge için bağımsız dört-fazlı handshake bulunur. Böylece bir kolun yavaşlaması diğer kolun bağımsız ilerlemesini engellemez; join noktası gereken operandları bekler.

## 2. Dört faz

| Faz | REQ | ACK | Veri kuralı |
|---|---:|---:|---|
| IDLE | 0 | 0 | Port boş; yeni payload kabul edilebilir |
| OFFER | 1 | 0 | Gönderici payload'ı sabit tutar |
| ACCEPT | 1 | 1 | Alıcı payload/state'i yakalamıştır |
| RETURN | 0 | 1 | Gönderici REQ'yi indirir; veri değişmez |
| IDLE | 0 | 0 | Alıcı ACK'yi indirir; yeni transfer açılır |

REQ yükselmeden önce payload stabil olmalıdır. Alıcı ACK'yi yalnız capture/accept işlemi tamamlandığında yükseltir. ACK, alıcı VALID sinyalini host'tan geri okuyarak türetilmez.

## 3. Bundled-data zamanlama şartı

Kontrol yolu veri yolundan önce ilerlememelidir. Her bağlantı için:

`t_REQ_min_delay ≥ t_DATA,max + t_skew + t_jitter + t_margin`

Bu bir tasarım şartıdır; `t_margin` PCB, PVT, sürücü ve ölçüm sonuçlarına göre seçilir. Gerekli delay margin sistemde ölçülmeden bundled-data çevrimi güvenli kabul edilmez.

## 4. FORK protokolü

Bir giriş transaction'ı iki child branch'e çoğaltıldığında iki çıkışın her biri bağımsız REQ/ACK yürütür. Giriş ACK'si, mimari politika aksini söylemiyorsa, iki çıkışın da kabul/iptal durumu kesinleşmeden verilmez. Bu, backpressure'ın kaybolmasını engeller.

## 5. SYNC_JOIN ve ARBITER_JOIN

- **SYNC_JOIN:** zorunlu operandların tümü aynı parent token/generation için gelmelidir. Her girişin ACK'si, operandın join slot'una yakalanmasıyla verilebilir; join çıkışı tüm slotlar dolmadan REQ üretmez.
- **ARBITER_JOIN:** iki alternatif aynı anda gelirse karşılıklı dışlayıcı arbiter yalnız birini seçer. Kaybeden giriş bekletilir veya retry/flush politikasına göre geri çevrilir. Arbiter metastabilite süresine karşı mutlak zaman sınırı garanti etmez.
- **WEIGHTED_SUM:** tüm gerekli akımlar aynı analog toplama hücresinde buluşur; ACK için yalnız veri yakalama değil, toplama çıkışının geçerli aralığa gelmesi gerekir.

## 6. ACK ve analog completion ayrımı

`ACK_CAPTURE`: verinin alıcı state/slot'a yakalandığını bildirir.  
`READY_SETTLED`: analog hesap ağının yakınsadığını bildirir.  
`FAULT`: timeout, invalid differential pair, saturation, simultaneous write veya bias hatası.

Bu üç sinyal aynı nete bağlanamaz. Bir state-cell capture ACK vermiş olabilir ama bütün mesh henüz çözüm bulmamıştır.

## 7. Watchdog ve iptal

Her edge için timeout ölçümü bulunmalıdır. Timeout süresi bir clock sayacı gerektirmez; RC/monostable ya da host test gözlemi ile ölçülebilir; ürün devresinin yöntemi sonraki revizyonda belirlenecektir. Timeout, ACK'yi sahte biçimde yükseltmez; FAULT üretir ve ilgili edge'i inhibit eder.

## 8. RESET

Reset asenkron olabilir fakat veri aktarımıyla aynı anda tanımsız biçimde bırakılmaz. Önce yeni REQ kabulü durdurulur, aktif handshake'ler kontrollü boşaltılır/iptal edilir, state-cell'ler known-state write alır, ardından idle durumu doğrulanır.
