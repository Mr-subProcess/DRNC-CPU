# Kaynaklar ve Tasarım Dayanakları

## CML / transistor latch

1. **RFIC Design with Open-Source Tools — Frequency Dividers, Static CML Dividers**  
   https://www.skillsurf.org/rfic-design/chapters/13-dividers/  
   Kullanım: CML latch'in track/hold yapısı; differential pair, cross-coupled hold pair, tail current ve yük direnci ilişkisi. Bu kaynak MOS CML örneği gösterir; RAQM-02A BJT eşleniği ayrıca SPICE ile doğrulanmalıdır.

2. **MIT 6.776 High-Speed Communication Circuits — Divide-by-2 Using SCL/CML Latches**  
   https://live.ocw.mit.edu/courses/6-776-high-speed-communication-circuits-spring-2005/9259f09cec66b687e4b7e21461f1626e_lec21.pdf  
   Kullanım: CML/SCL latch topolojisi ve cross-coupled feedback latch prensibi.

## Transistor adayları

3. **Nexperia BCM847BS, NPN/NPN matched double transistor, Product data sheet, 15 July 2026**  
   https://assets.nexperia.com/documents/data-sheet/BCM847BS.pdf  
   Kullanım: SOT363 matched dual NPN, V_BE matching, pinout, f_T eğrisi ve termal/elektriksel sınırlar. f_T=250 MHz tipik değeri yalnız belirtilen data-sheet test koşulundadır; RAQM kart frekansı değildir.

4. **Nexperia BC847B product page**  
   https://www.nexperia.com/product/BC847B  
   Kullanım: tail current sink için tek NPN adayının ürün ailesi ve SOT23 paketi.

## Asenkron handshake

5. **DTU — Design of an asynchronous communication network for an audio DSP chip**  
   https://www2.imm.dtu.dk/pubdb/edoc/imm3974.pdf  
   Kullanım: four-phase bundled-data handshake; request/data stable, acknowledge after capture, return-to-zero; C-element ve arbiter/mutex riskleri. Tez 2005 tarihli akademik referanstır; güncel process/library garantisi değildir.

## Eski RAQM-01C PECL/ECL prototipi

6. **onsemi MC100EP56 datasheet**  
   https://www.onsemi.com/pdf/datasheet/mc10ep56-d.pdf
7. **onsemi MC100EPT22 datasheet**  
   https://www.onsemi.com/pdf/datasheet/mc100ept22-d.pdf
8. **onsemi MC100EPT23 datasheet**  
   https://www.onsemi.com/download/data-sheet/pdf/mc100ept23-d.pdf
9. **onsemi AND8020/D — Termination of ECL Devices with EF Output Structure**  
   https://www.onsemi.com/download/application-notes/pdf/and8020-d.pdf  
   Kullanım: yalnız RAQM-01C PECL/ECL prototipindeki terminasyon referansı. 02A BJT latch'e 50 Ω/VTT topolojisi kopyalanmaz.

## Kaynakların yorumu

Üretici datasheet nominal/limit bilgileri tekil parçaya ve belirtilmiş koşullara aittir. Bütün kart için hız, güç, hata oranı, latch retention veya optimizasyon yakınsama süresi doğrudan datasheet'ten çıkarılamaz. Her kritik değer gerçek bias ve PCB koşullarında ölçülmelidir.


## RAQM-02A source-to-design mapping

- **Nexperia BCM847BS data sheet:** matched dual NPN package, SOT363 pinout and matching specifications. Its quoted typical f_T is condition-specific and is not a clock rate or RAQM operating-frequency specification. The physical board still needs pin-number verification against the exact orderable suffix/revision.
- **Nexperia BC847B data sheet/product page:** single general-purpose NPN candidate for the tail sink; its suitability depends on the selected current, dissipation, VCE headroom and temperature.
- **CML latch/track-hold references:** support the functional grouping of data differential pair, cross-coupled regenerative pair, steering pair and tail current. The proposed NPN implementation is only a topology candidate until DC/transient SPICE and bench characterization.
- **Asynchronous bundled-data and Muller C-element references:** support the four-phase handshake and the C-element's consensus/hold behavior. They do not establish that the future discrete BJT C-element is already designed or verified.

10. **Nexperia BCM847BS official data sheet, 15 July 2026** — https://assets.nexperia.com/documents/data-sheet/BCM847BS.pdf
    Kullanım: U1/U2/U3 dual-NPN pin numbering (1=E1, 2=B1, 3=C2, 4=E2, 5=B2, 6=C1), SOT363-3 package and matched pair data.
11. **Nexperia BC847x series official data sheet, Rev.13, 1 July 2022** — https://assets.nexperia.com/documents/data-sheet/BC847X_SER.pdf
    Kullanım: Q1 BC847B SOT23 pin numbering (1=B, 2=E, 3=C) and limits.
