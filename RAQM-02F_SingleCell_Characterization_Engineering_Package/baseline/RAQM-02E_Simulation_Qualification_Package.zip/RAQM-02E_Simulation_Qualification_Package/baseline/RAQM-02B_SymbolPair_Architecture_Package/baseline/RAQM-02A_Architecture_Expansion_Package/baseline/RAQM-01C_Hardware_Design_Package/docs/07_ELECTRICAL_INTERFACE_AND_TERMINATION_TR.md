# 07 — Elektriksel Arayüz, Besleme ve Terminasyon

## 1. Gerçek parça rolleri

| Ref | Parça | Rol |
|---|---|---|
| U1–U4 | MC100EPT22DTG | 3,3 V LVTTL/LVCMOS → diferansiyel LVPECL; dört entegre, sekiz diff çift |
| U5–U6 | MC100EP56DTG | Dual differential 2:1 ECL/PECL MUX; iki entegre, dört node kanalı |
| U7–U8 | MC100EPT23DG | Diferansiyel LVPECL/LVDS/CML → LVTTL/LVCMOS; dört sonuç biti |
| U9–U10 | SN74LVC08A + SN74LVC32A | Tek kontrol C-element denemesi; veri yolunun içinde değil |

MC100EP56, TSSOP-20 paketli dual diferansiyel 2:1 MUX'tur; tüm VCC ve VEE pinleri bağlanmalıdır. PECL modunda VCC=3,3 V, VEE=0 V kullanılır. MC100EPT22 çift LVTTL girişini çift LVPECL çıkışına çevirir. MC100EPT23 diferansiyel LVPECL/LVDS/CML girişini LVTTL çıkışına çevirir. Kaynak veri sayfaları `references/` içinde listelenmiştir.

## 2. Kritik VTT gereksinimi

MC100EPT22 ve MC100EP56 veri sayfaları tipik çıkış yükünü her iletken için 50 Ω ve `VTT = VCC − 2,0 V` olarak tarif eder. `VCC=3,3 V` için:

`VTT = 1,30 V`

Kartta 8 adet EPT22 diferansiyel çıkış çifti ve 4 adet EP56 diferansiyel çıkış çifti bulunur. Her çift iki ayrı iletkendir:

- EPT22 → EP56: 8 çift × 2 = 16 × 49,9 Ω
- EP56 → EPT23: 4 çift × 2 = 8 × 49,9 Ω
- Toplam: **24 adet 49,9 Ω ±1% terminasyon**

Her direnç ilgili sinyal iletkeninden VTT'ye bağlanır ve alıcı tarafına yakın yerleştirilir. 100 Ω tek bir dirençle iki bacak arasına sonlandırmak, bu datasheet konfigürasyonunun eşdeğeri değildir.

## 3. VTT akım bütçesi

MC100EPT22 ve MC100EP56 tipik PECL çıkış seviyeleri yaklaşık `VOH=2,28 V`, `VOL=1,48 V` ve `VTT=1,30 V` alınırsa, bir diferansiyel çiftin iki yük kolundan geçen yaklaşık akım:

`I_pair ≈ (2,28−1,30)/50 + (1,48−1,30)/50 ≈ 23,2 mA`

12 çift için yaklaşık `0,278 A` hesaplanır. Bu, veri sayfasındaki tipik gerilimlerle yapılan ilk bütçe tahminidir; tolerans, sıcaklık, parça varyantı ve ölçümle güncellenmelidir. VTT kaynağı **en az 0,4 A sink kapasitesi** ile tasarlanmalı; hedef tasarım payı ayrıca gözden geçirilmelidir.

**Önemli:** Standart tek-yönlü laboratuvar güç kaynağı akım sink edemeyebilir. VTT hattı, akım sink edebildiği doğrulanmış source/sink regülatör veya harici aktif VTT kaynağından verilmelidir. Basit direnç bölücüyü VTT kaynağı olarak kullanmayın. RAQM-01C'de VTT harici J4 üzerinden beslenir; kart üstünde VTT regülatörü tasarlanmış sayılmaz.

## 4. Besleme

- `+3V3`: tüm ECL/PECL ve LVC entegreleri için ana ray.
- `VTT≈1,30 V`: yalnızca hat sonlandırmaları için ayrı ray.
- `GND`: ortak referans; host, kart ve ölçüm cihazlarının toprak bağlantısı kontrollü yapılmalı.
- J1 pin 20 yeni revizyonda NC olur; host 3,3 V hattı ile kartın 3,3 V beslemesi paralellenmez.
- Host GPIO 3,3 V seviyesinde olmalıdır; 5 V GPIO doğrudan bağlanmaz.

+3V3 kaynağının 1 A kapasitede seçilmesi bir **kaynak kapasitesi tavsiyesidir**, kartın 1 A çekeceği anlamına gelmez. Gerçek akım başlangıç testinde ölçülür. İlk açılış akım limiti düşükten başlatılıp aşamalı artırılır.

## 5. Pin ve seviye sınırları

- MC100EPT22 girişleri 3,3 V LVTTL/LVCMOS seviyesidir; 5 V tolerans varsayılmaz.
- EP56 veri ve select girişleri diferansiyel ECL/PECL seviyeleridir; host GPIO doğrudan bağlanmaz.
- EP56 Q/Q̅ çıkışları ve EPT22 Q/Q̅ çıkışları doğru VTT sonlandırması olmadan hızlı test edilmemelidir.
- EPT23 girişleri diferansiyel LVPECL/LVDS/CML destekler; dahili bias dirençleri hat sonlandırma direncinin yerine geçmez.

## 6. Datasheet hızlarının doğru yorumlanması

- MC100EP56: tipik diferansiyel yayılma gecikmesi yaklaşık 340–360 ps; tipik maksimum frekans >3 GHz.
- MC100EPT22: tipik diferansiyel yayılma gecikmesi yaklaşık 420 ps; tipik maksimum frekans >1,1 GHz.
- MC100EPT23: tipik yayılma gecikmesi 1,5 ns; maksimum çalışma frekansı >275 MHz.

Bunlar tekil entegre veri sayfası koşullarıdır. Bu sistemin garantili veri hızı değildir. Bu zincirde EPT23 alıcı/çevirici aşaması muhtemel dar boğazdır; PCB yükü, terminasyon, host ve handshake toplam süreyi artırır.

## 7. Termal koşul

İlgili onsemi veri sayfaları AC/DC karakteristiklerin belirtilen board ve çapraz hava akışı test koşullarında sağlandığını not eder. İlk ölçümde sıcaklık, hava akışı, cihaz kasası ve ortam sıcaklığı kaydedilmelidir; yüksek hızlı testlerde üretici termal koşulları ayrıca doğrulanmalıdır.
