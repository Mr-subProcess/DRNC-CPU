# KiCad Dosyası Durumu — RAQM-01C_PreLayout.kicad_pcb

Bu dosya önceki RAQM-01A yerleşiminden türetilmiş ve aşağıdaki değişiklikleri içerir:

- +3V3/J1 pin20 bağlantısı kaldırılmıştır (NC).
- J4 harici VTT giriş konektörü eklenmiştir.
- 8 EPT22 çıkış çifti için 16 adet 49,9 Ω VTT terminasyonu eklenmiştir.
- 4 EP56 çıkış çifti için 8 adet 49,9 Ω VTT terminasyonu eklenmiştir.
- VTT için 100 nF + 1 µF yerel bypass kondansatörleri eklenmiştir.
- Board edge 140×110 mm konsept alanına genişletilmiştir.

**Önemli statü:** Dosyada footprint ve net atamaları vardır; copper track yoktur. Bu oturumda KiCad CLI/PCBNew çalıştırılamadığı için dosya ERC/DRC/3D doğrulamasından geçirilmemiştir. Bu dosyayı doğrudan PCB üreticisine gönderme. Üretim öncesi KiCad'de aç, footprint padlerini onsemi mechanical land pattern ile karşılaştır, netlisti şematikten yeniden üret ve DRC/3D kontrolü yap.
