# 21 — State-Cell Pin-Level Aday Bağlantı Haritası

## 1. Kapsam

Bu belge, tek-hücre CML track/hold adayının **pin/net isimlendirme taslağıdır**. Gerçek KiCad şematiği, ERC/DRC ve SPICE netlisti değildir. Net eşlemeleri transistor gruplarının işlevsel topolojisine göre tanımlanmıştır; PCB üretiminden önce bağımsız şematik incelemesi gerekir.

## 2. BCM847BS pin eşlemesi

Nexperia BCM847BS, iki bağımsız fakat eşleştirilmiş NPN içerir. Üretici pin tablosuna göre pin 1=E1, 2=B1, 3=C2, 4=E2, 5=B2, 6=C1'dir. Paket görünüşü üstten bakışta üst sıra 6-5-4, alt sıra 1-2-3 şeklindedir. PCB footprint pin-1 yönü datasheet ve gerçek footprint ile tekrar kontrol edilmelidir.

| Paket içi transistor | Emitter | Base | Collector |
|---|---|---|---|
| TR1 / A | pin 1 (E1) | pin 2 (B1) | pin 6 (C1) |
| TR2 / B | pin 4 (E2) | pin 5 (B2) | pin 3 (C2) |

## 3. Fonksiyonel net atamaları

### U1 — DATA pair

- U1A: E1→`E_DATA`, B1→`D_P`, C1→`Q_N`.
- U1B: E2→`E_DATA`, B2→`D_N`, C2→`Q_P`.

Bu output atamasıyla `D_P > D_N` iken U1A daha fazla akım çeker, `Q_N` collector düğümü daha aşağı iner ve `Q_P > Q_N` polaritesi oluşur. Bu polarite, kabul testinde doğrulanacak nominal mantık eşlemesidir.

### U2 — HOLD pair

- U2A: E1→`E_HOLD`, B1→`Q_N`, C1→`Q_P`.
- U2B: E2→`E_HOLD`, B2→`Q_P`, C2→`Q_N`.

U2A/U2B collector/base çapraz bağlantısı pozitif geri beslemeli HOLD durumunu oluşturur. İki collector çıkışı U1'in karşılıklı collector düğümleriyle ortaklanır.

### U3 — WRITE/HOLD steering pair

- U3A: E1→`E_TAIL`, B1→`WE_P`, C1→`E_DATA`.
- U3B: E2→`E_TAIL`, B2→`WE_N`, C2→`E_HOLD`.

`WE_P > WE_N` DATA koluna; `WE_N > WE_P` HOLD koluna akım yönlendirir. WE girişleri geçiş sırasında belirsiz/eşit kaldığında ACK üretilmez; fault/qualification davranışı ayrı karakterize edilir.

### Q1 — Tail-current sink

- Nexperia BC847B SOT23 pin 1=`B`, pin 2=`E`, pin 3=`C`.
- Q1 base→`VBIAS_TAIL`; collector→`E_TAIL`; emitter→`Q1_E`; `Q1_E`→`R_E`→GND.

`R_E`, `VBIAS_TAIL`, `I_TAIL` ve transistor headroom değerleri sabitlenmemiştir.

## 4. Collector yükleri ve çıkış

- `RL_P`: `VDD_CML` ile `Q_P` arasında.
- `RL_N`: `VDD_CML` ile `Q_N` arasında.
- Çıkış çifti: `Q_P/Q_N`; yalnız high-impedance differential probe ile ilk ölçüm.
- `U1B.C2` ile `U2A.C1` ortak `Q_P` collector netidir.
- `U1A.C1` ile `U2B.C2` ortak `Q_N` collector netidir.

## 5. Üretim öncesi netlist inceleme kapısı

1. Her BCM847BS footprint pin numarası datasheet ile doğrulanır.
2. U1A/U1B ve U2A/U2B ortak emitter ve cross-coupled collector/base netleri tek tek kontrol edilir.
3. U3A/U3B collector netlerinin E_DATA/E_HOLD kollarına doğru gittiği doğrulanır.
4. Q1 pin 1/2/3 yönü ve R_E akım yolu kontrol edilir.
5. RL_P/RL_N eşleşmesi, common-mode ve tail-sink headroom'u DC SPICE ile test edilir.
6. Transient WRITE↔HOLD, polarite ve metastabilite analizi tamamlanır.
7. ERC/DRC ve fiziksel footprint kontrolü geçmeden Gerber alınmaz.

## 6. Önemli sınır

Bu harita, ilk transistor-level bağlantı adayıdır; üretim imzası değildir. NPN akım yönleri ve çıkış polaritesi çizimdeki net isimleriyle tutarlı olacak biçimde yazılmıştır, ancak gerçek işletim noktası, giriş common-mode'u, differential swing, collector load ve hız aralığı SPICE ve laboratuvar testiyle doğrulanmalıdır.
