# 07 — DRNC ve Dallanan Zerya: Donanım Eşlemeli Matematik

## 1. Soyut durum ve fiziksel karşılık

Her node için soyut durum `x_i` tanımlanır. Fiziksel adayları:

- Diferansiyel gerilim: `v_i = V_{iP} − V_{iN}`.
- Diferansiyel akım: `i_i = I_{iP} − I_{iN}`.

Normalleştirilmiş analiz değişkeni `x_i∈[-1,1]` olarak kullanılabilir; bu, gerçek ölçüm ölçeğine kalibre edilmeden doğrudan volt veya amper değildir.

## 2. DRNC node/edge tanımı

Mesh `G=(V,E)` ile gösterilir. Edge kaydı:

`e = (source, target, source_port, target_port, branch_id, kind, lag, gain, polarity)`

- `kind ∈ {route, fork, sync, arbitrate, sum, feedback}`.
- `lag=0`: aynı generation feed-forward bağlantı.
- `lag≥1`: state-cell üzerinden geçmişe bağlı bağlantı.
- `gain`: ileride gerçek current-mirror/transconductance/resistor ağıyla kalibre edilecek katsayı.
- `polarity`: diferansiyel yön işareti; P/N terslemesi açıkça kaydedilir.

## 3. Dallanan Zerya operatörü

Bir node'dan iki kola ayrılma soyut olarak:

`Z_i(x_i,g) = {(b_A, e_A, x_{A}), (b_B, e_B, x_{B})}`

Ancak fiziksel akım korunumu göz ardı edilemez:

`I_in = I_A + I_B + I_loss`

Tam genlikli iki kopya isteniyorsa aktif buffer/current-copy hücresi gerekir. İki dalın her birine aynı akımın bedelsiz ulaştığı kabul edilmez.

## 4. Birleşme cebiri — dört farklı işlem

### A. Seçim (MUX)

`x_out = x_A` if `SEL=A`, otherwise `x_B`.

Yalnız bir giriş seçilir; iki veri toplanmaz.

### B. Rendezvous / SYNC_JOIN

`valid_out = valid_A ∧ valid_B ∧ same_parent ∧ same_generation`.

İki operand birlikte kabul edilir; tek bir skaler değere indirgenmek zorunda değildir.

### C. Arbitration

`grant_A ⊕ grant_B = 1` (bir grant verildiği çevrimde) ve `grant_A ∧ grant_B = 0`.

Bir yarışta bir istek seçilir; ikisi birden analog olarak toplanmaz.

### D. Ağırlıklı akım toplama

`I_sum = g_A I_A + g_B I_B`.

Bu denklem yalnız fiziksel current-summing/transconductance hücresiyle anlam kazanır. Giriş empedansı, headroom, lineer aralık, ağırlık işareti ve güç hesabı gerekir.

## 5. Gecikmeli DRNC state

Bir state-cell için soyut güncelleme:

`s_i(g+1) = H_i(x_i(g), WE_i)`

ve geri okuma:

`x_{j,fb}(g+1) = R_i(s_i(g+1))`

`H_i/R_i` fiziksel latch ve buffer işlevleridir. Gecikme sayısı global clock periyodu değildir; en az bir kabul edilmiş state transaction'ı kadar tarihsel ayrım anlamındadır.

## 6. Genel recurrent düğüm denklemi

Araştırma modeli olarak:

`C_i dx_i/dt = −G_i x_i + Σ_j W_ij^(0) φ_j(x_j) + Σ_{ℓ=1..L} Σ_j W_ij^(ℓ) φ_j(s_j[g−ℓ]) + b_i`

Burada fiziksel transient `t` ile mantıksal generation `g` farklı kavramlardır. `C_i`, `G_i`, `W`, `φ` ve `b_i` gerçek devreyle kalibre edilmedikçe bu denklem davranışsal modeldir; transistor-level doğrulama değildir.

## 7. CML akım ilişkisi

İdeal diferansiyel akım yönlendirme çiftinde:

`I_P + I_N ≈ I_TAIL`

`I_D = I_P − I_N`

Rezistif yük altında ilk yaklaşım olarak `ΔV_diff ≈ I_TAIL · R_L` şeklinde bir ölçek ilişkisi kullanılabilir. Gerçek salınım ve common-mode, BJT bias/headroom, transistor transfer eğrisi, yük, parazit ve sıcaklığa göre SPICE ile belirlenir.

## 8. DRNC için tasarım ayrımı

DRNC node ilişkisini ve saklanan durumu tanımlar; dallanan Zerya branch/merge/history topolojisini tarif eder. Bunlar kendiliğinden fiziksel akım kopyalama, memory, sum veya convergence üretmez. Her sembol ve operatörün karşısında gerçek bir hücre tipi ve ölçüm kriteri bulunmak zorundadır.
