# RAQM-02A Mimari Karar Kaydı

| ID | Karar | Gerekçe | Durum |
|---|---|---|---|
| ADR-001 | İlk ürün ön-hızlandırıcıdır | CPU kapsamı erken | Donduruldu |
| ADR-002 | Dataplane global clock içermez | Yerel asenkron olaylarla ilerleme | Donduruldu |
| ADR-003 | Generation global clock değildir | Token lineage semantiği | Donduruldu |
| ADR-004 | Her edge kendi REQ/ACK hattına sahiptir | Bağımsız yerel backpressure | Tasarım kararı |
| ADR-005 | Aynı-generation graph DAG'dir | Zero-delay cycle engeli | Donduruldu |
| ADR-006 | Her recurrent edge state-cell'den geçer ve lag≥1 | Gerçek geçmiş saklama sınırı | Donduruldu |
| ADR-007 | FORK active duplicate semantics taşır | Pasif akım split bedelsiz kopya değildir | Donduruldu |
| ADR-008 | MUX/JOIN/ARBITER/SUM ayrı hücre tipidir | Semantik karışıklığı önlenir | Donduruldu |
| ADR-009 | SYNC_JOIN aynı parent/generation ister | Yanlış operand birleşmesini önler | Donduruldu |
| ADR-010 | State-cell statik, volatile CML latch'tir | Recurrent state fiziksel dayanağı | Aday devre |
| ADR-011 | WE, handshake kontrollü differential select'tir | Clockless write/hold | Aday devre |
| ADR-012 | Capture ACK ve SETTLED ayrıdır | Data accepted ≠ computation converged | Donduruldu |
| ADR-013 | RAQM-02A tek-hücre kuponudur | Önce temel latch doğrulansın | Donduruldu |
| ADR-014 | BCM847BS matched NPN candidate | Matched differential pairs | Ön BOM; SPICE şart |
| ADR-015 | Bias değerleri SPICE/bench öncesi sabitlenmez | Headroom ve PVT doğrulaması | Donduruldu |
| ADR-016 | Kod oluşturucu son aşamadır | Hardware semantics first | Donduruldu |

| ADR-017 | Eşleştirilmiş transistor paketleri U1/U2/U3, tail sink Q1 olarak adlandırılır | BOM/netlist referans tutarlılığı | Donduruldu |
| ADR-018 | C-element ilk kuponda harici kontrol; fiziksel CML hücresi 02B'de | State-cell ölçümünü izole etmek | Donduruldu |
| ADR-019 | Bir state-cell bir diferansiyel bit tutar | Dört sembol için iki cell gerekir | Donduruldu |
| ADR-020 | İki hücreli sembol yalnız PAIR_VALID sonrası tüketilir | Ara karma sembol görünürlüğünü engellemek | Donduruldu |
| ADR-021 | Q pinlerinde eşzamanlı analog geçiş garantisi yoktur | Shadow pair gerekebilir | Donduruldu |
| ADR-022 | C-element ACK_CAPTURE üretimine yardım eder; SETTLED farklı katmandır | Capture ve çözüm tamamlanmasını ayırmak | Donduruldu |
| ADR-023 | Clockless dataplane fiziksel zamansız değildir | Gecikme/metastabilite ölçümü gerekir | Donduruldu |
| ADR-024 | 02A ölçüm kartı üretime hazır değildir | Önce SPICE, schematic, ERC/DRC ve Gerber review | Donduruldu |
