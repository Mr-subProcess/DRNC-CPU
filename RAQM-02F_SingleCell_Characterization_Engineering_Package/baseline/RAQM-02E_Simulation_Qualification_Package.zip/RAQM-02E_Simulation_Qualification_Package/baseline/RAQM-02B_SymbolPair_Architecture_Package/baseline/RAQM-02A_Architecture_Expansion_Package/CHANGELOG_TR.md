# RAQM-02A Changelog

## 17 Kasım 2026 — Architecture Expansion A

- Kapsam ön-hızlandırıcı olarak korundu; genel amaçlı işlemci tanımı kullanılmadı.
- Yazılım, simülatör, derleyici ve kod oluşturucu paketten tamamen çıkarıldı.
- Global epoch/clock varsayımı kaldırıldı; generation kavramı token/işlem nesli için mantıksal etiket olarak yeniden tanımlandı.
- Her fiziksel bağlantı için bağımsız dört-fazlı handshake tanımlandı.
- FORK, ROUTE, SYNC_JOIN, ARBITER_JOIN, WEIGHTED_SUM ve STATE_CELL birbirinden ayrıldı.
- Dalların birbirine çapraz dönmesi ve tarihsel düğümlere geri besleme yolları için iki recurrent örnek eklendi.
- Aynı-generation DAG + state-cell üstünden lag≥1 recurrent kenar şartı katı kural yapıldı.
- Tek yerel CML latch/state-cell için altı transistorlü diferansiyel track/hold topolojisi tarif edildi.
- Nexperia BCM847BS eşleştirilmiş NPN çifti ve BC847B kuyruk akım kaynağı aday BOM'a eklendi; bias değerleri bilerek dondurulmadı.
- Durum saklamanın volatile/powered olduğu ve sürekli bias gücü gerektirdiği açıkça belirtildi.
- CML capture ACK ile analog SETTLED completion ayrıldı.
- RAQM-02A tek-hücre test kartı işlev şeması ve kat planı hazırlandı.
- Sonraki özel derleyici için yalnız soyut donanım sözleşmesi tanımlandı; kod yazılmadı.

## Bu revizyonda bilerek yapılmayanlar

- Transistor-level SPICE netlisti veya doğrulanmış bias/direnç değerleri oluşturulmadı.
- RAQM-02A test kartı için üretilebilir KiCad şematik/PCB, Gerber veya pick-and-place hazırlanmadı.
- İki hücreli/çok hücreli fiziksel mesh üretime hazır sayılmadı.
- Analog optimizasyon, fiziksel rezonans, yakınsama süresi veya enerji/çözüm performansı iddia edilmedi.
- Programlama dili, kod üretici veya uygulama kodu yazılmadı.
- BCM847BS iç pinleri ve BC847B SOT23 pinleri üretici pin tablosuna göre net mapping CSV ve wiring şartnamesine eklendi; bias/şematik doğrulama şartı korunuyor.
