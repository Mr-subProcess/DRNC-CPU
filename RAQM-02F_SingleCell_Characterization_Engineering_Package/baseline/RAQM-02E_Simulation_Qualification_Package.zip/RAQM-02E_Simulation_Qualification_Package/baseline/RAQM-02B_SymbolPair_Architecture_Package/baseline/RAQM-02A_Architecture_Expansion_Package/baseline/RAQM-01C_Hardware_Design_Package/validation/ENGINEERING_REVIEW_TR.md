# Mühendislik İncelemesi — RAQM-01C

## Kritik düzeltmeler

1. Önceki BOM'da EPT22 ve EP56 çıkış hatlarının 50 Ω / VTT yüklemesi eksikti. Rev-C'de 12 diferansiyel çift için 24 adet 49,9 Ω terminasyon tanımlandı.
2. 3,3 V sistemde VTT yaklaşık 1,30 V'tur. VTT, yaklaşık 0,28 A tipik yük akımı hesabına sahiptir; en az 0,4 A sink yeteneği tasarım hedefi konmuştur.
3. J1 pin20 daha önce +3V3 idi. J2 de +3V3 girişi olduğundan host ve kart kaynaklarının paralellenme/backfeed riski vardı. Yeni pinout'ta J1 pin20 NC'dir.
4. MC100EPT23 için 1,5 ns tipik gecikme ve >275 MHz maksimum çalışma frekansı bilgisi, zincirin 3 GHz çalıştığı iddiasını geçersiz kılar. EP56'nın >3 GHz tipik değeri tüm kartın hızı değildir.
5. MC100EP56 TSSOP-20 pinout'unda VCC pin 14 ve 20; VEE pin 11'dir. Üç besleme pini harici olarak bağlanmalıdır.
6. LVC kapılarından yapılan C-element, kontrol katmanındadır. Tüm kartın CMOS içermediği iddia edilemez.

## Risk seviyesi

| Risk | Seviye | Kapatma kriteri |
|---|---|---|
| VTT kaynağı sink edemiyor | Kritik | J4 VTT kaynağı yük altında 1,30 V ± toleransla ölçülür |
| PECL terminasyonu hatalı | Kritik | 24 direnç/net, konum ve VTT doğrulanır |
| Diferansiyel hat empedansı | Yüksek | Üretici stack-up, field solver ve TDR |
| Handshake ACK yanlış anlamlandırma | Yüksek | HOST_VALID_TEST ile CORE_READY ayrılır |
| Zero-delay recurrent loop | Kritik | Her tarihsel kenar state-cell/lag içerir |
| Asimetrik feedback kararsızlığı | Yüksek | SPICE transient + small-gain/Lyapunov analizi |
| C-element metastabilitesi/race | Yüksek | Çoklu çevrim ve PVT bench testi |
| PCB DRC/route eksik | Kritik | DRC/3D/ERC ve üretici çıktısı |

## Sonuç

RAQM-01C, önceki prototip taslağından daha eksiksiz bir elektriksel ön tasarımdır; ancak hâlâ üretime hazır değildir. En yüksek öncelik VTT/terminasyon ağı, +3V3 izolasyonu, gerçek diferansiyel hat yönlendirmesi ve asenkron handshake'in ölçümüdür.
