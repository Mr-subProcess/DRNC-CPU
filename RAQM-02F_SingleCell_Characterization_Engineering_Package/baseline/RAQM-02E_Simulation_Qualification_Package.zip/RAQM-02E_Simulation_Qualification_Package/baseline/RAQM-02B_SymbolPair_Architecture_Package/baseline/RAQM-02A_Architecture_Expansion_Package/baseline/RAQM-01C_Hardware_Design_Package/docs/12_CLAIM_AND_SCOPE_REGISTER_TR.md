# 12 — İddia, Kanıt ve Kapsam Kaydı

| İfade | Durum | Kanıt / sonraki adım |
|---|---|---|
| RAQM-01C'de global clock yok | Mimari tasarım kararı | Host bağımsız clock kullanabilir; core clock dağıtım ağı yok |
| Dört diferansiyel 2:1 MUX kanalı var | Parça sayısından ve pin ağından çıkar | PCB/bench doğrulaması gerekir |
| `00/01/10/11` sembolleri taşınır | Mimari kodlama | Dört-sembol test vektörleriyle doğrulanır |
| Gerçek yerel geri-besleme belleği var | **Yok** | RAQM-02 state-cell gerekir |
| Dallar geçmiş node'lara döner | Mantıksal hedef topoloji | RAQM-02/03 fiziksel state-cell gerektirir |
| Saf CML dataplane | **Tam değil** | İlk kart PECL/ECL MUX/çevirici demonstratörü |
| Kartın tüm alanlarında CMOS AND/OR yok | **Yanlış** | LVC C-element kontrol düzleminde CMOS kapılar var |
| Analog problem çözümü / fiziksel rezonans | Araştırma hipotezi | Relaxation devresi + SPICE + ölçüm + kıyas gerekir |
| Genel amaçlı işlemci | **Değil** | İlk ürün ön-hızlandırıcı |
| ps gecikmeli tüm sistem | **Kanıtlanmadı** | Tekil IC datasheet değerleri sistem gecikmesi değildir |
| sub-ms çözüm garantisi | **Yok** | Uygulama ve yakınsama dağılımı ölçülmeli |
| Otomatik programlama/kod üretici | **Bu pakette yok** | Donanım doğrulamasından sonra ayrı proje |

Bu kayıt, gelecekteki sunum/teknik yazılarda tasarım hedefi, simülasyon sonucu, parça veri sayfası ve fiziksel ölçümü birbirine karıştırmamak için zorunludur.
