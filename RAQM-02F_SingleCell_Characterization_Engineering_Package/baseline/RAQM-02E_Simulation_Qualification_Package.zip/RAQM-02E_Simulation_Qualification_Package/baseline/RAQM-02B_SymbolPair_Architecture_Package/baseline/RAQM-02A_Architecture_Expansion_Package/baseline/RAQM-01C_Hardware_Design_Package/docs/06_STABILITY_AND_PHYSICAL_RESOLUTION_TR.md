# 06 — Kararlılık, Yakınsama ve “Fiziksel Çözüm” Koşulları

## 1. Temel dinamik model

Bir sonraki revizyonda analog relaksasyon araştırılırsa düğüm durumları için başlangıç modeli:

`C dx/dt = −D x + W Φ(x) + u`

- `C`: pozitif kapasitans/etkin zaman sabiti matrisi.
- `D`: sönüm/iletkenlik matrisi; diagonal ve pozitif olması başlangıç modelidir.
- `W`: düğümler arası ağırlıklı coupling matrisi.
- `Φ`: transistor transfer/limit fonksiyonu.
- `u`: harici bias/girdi.

Bu model tasarım denklemi taslağıdır; transistor-level netlist ve SPICE köşe analizi değildir.

## 2. Yakınsama için muhafazakâr koşul

`Φ` Lipschitz sabiti `L` ile sınırlı olsun. İlk tasarım hedefi:

`q = ||D⁻¹ W||∞ · L < 1`

olarak seçilir. Bu, statik fixed-point eşlemesi için kontraksiyon ve tekil denge çözümü yönünde muhafazakâr bir tasarım kriteridir. Gecikmeli geri beslemede aynı norm koşulu tek başına bütün fiziksel gecikme, doyum, transistor paraziti ve metastabilite risklerini ortadan kaldırmaz; gecikmeli sistem için ayrıca small-gain/Lyapunov-Krasovskii veya transistor-level transient analizi gerekir.

## 3. Enerji fonksiyonu modu

Ağırlıklı ağ pasif gradient-flow olarak tasarlanacaksa `W=Wᵀ` gibi karşılıklılık koşulları ve uygun node transfer fonksiyonu aranır. Örnek enerji fonksiyonu:

`E(x) = Σ_i U_i(x_i) − 1/2 xᵀ W x − uᵀx`

Eğer fiziksel dinamik `dx/dt = −M∇E`, `M` pozitif tanımlı ise:

`dE/dt = −(∇E)ᵀ M (∇E) ≤ 0`

Bu ilişki yalnızca belirtilen gradient-flow varsayımları karşılandığında geçerlidir. Yönlü, asimetrik ve gecikmeli bir mesh otomatik olarak bu enerji fonksiyonunu izlemez.

## 4. İki modun karıştırılmaması

- Simetrik/karşılıklı coupling, enerji azalışı ve dengeye oturma araştırmasına uygundur.
- Yönlü/gecikmeli feedback, geçmiş durum ve recurrent bilgi taşımaya uygundur; osilasyon veya çoklu denge oluşturabilir.

İkisini aynı anda kullanmak istenirse birleşik Lyapunov/kararlılık analizi gerekir. “Dallanma var, o hâlde çözüm bulur” çıkarımı geçersizdir.

## 5. Completion detector gereksinimi

Bir optimizasyon çıktısının hazır sayılması için sadece `REQ` veya sabit bekleme yeterli değildir. En azından:

- ilgili tüm analog state düğümleri ölçüm aralığında,
- `|dx_i/dt| < ε_i` koşulu,
- amaç fonksiyonu residual'ı veya kısıt hatası `≤ ε_r`,
- bu sınırların qualification penceresi boyunca korunması,
- watchdog ve saturation/fault durumlarının temiz olması

gerekir. Bu eşikler gerçek devre, sıcaklık, yük ve problem ölçeği ölçülerek belirlenir.

## 6. Performans raporlaması

Sistem performansı şu metriklerle yayımlanmalıdır: input-to-valid latency, convergence time distribution, energy per solve, success probability, residual error, constraint violation, temperature drift, restart rate ve host transfer overhead. Tek entegre datasheet gecikmesi RAQM sistem gecikmesi değildir.
