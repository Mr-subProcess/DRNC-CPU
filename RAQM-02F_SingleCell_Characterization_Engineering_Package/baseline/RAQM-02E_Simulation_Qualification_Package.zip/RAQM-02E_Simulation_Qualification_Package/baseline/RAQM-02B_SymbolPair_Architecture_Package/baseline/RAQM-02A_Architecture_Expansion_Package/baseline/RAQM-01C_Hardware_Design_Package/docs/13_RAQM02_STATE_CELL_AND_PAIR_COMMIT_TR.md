# 13 — RAQM-02 Yerel Diferansiyel State-Cell ve Atomik Qudit Commit

## 1. Bu belgenin statüsü

Bu belge RAQM-02 için işlevsel donanım şartnamesidir. Transistör seviyeli şematik, transistor boyutları, tail-current değeri, yük direnci, bias ağı ve fiziksel layout henüz dondurulmamıştır. Şekil `RAQM-02_StateCell_Concept` bir blok diyagramıdır; üretim şematiği değildir.

## 2. Neden iki hücre gerekir?

İlk RAQM kartındaki `00/01/10/11`, iki diferansiyel bitin taşıdığı klasik dört semboldür. Bir sonraki revizyonda aynı sembol fiziksel olarak iki bağımsız diferansiyel bit hücresinde saklanır:

- `SC_b1`: sembolün yüksek biti.
- `SC_b0`: sembolün düşük biti.
- `PAIR_JOIN`: iki hücrenin capture/READY olayını tek sembol işlemi olarak birleştirir.

Yalnızca bir state-cell hazırsa `PAIR_READY=0` kalır. İki hücre de kendi capture ve hold koşulunu tamamladığında sembol birlikte commit edilir. Bir bitin eski epoch değeriyle diğer bitin yeni epoch değeri bir sembol olarak dışarı verilmez.

## 3. Tek bit state-cell arayüzü

| Sinyal | Yön | Anlam |
|---|---|---|
| `D_P/D_N` | Giriş | Diferansiyel veri; geçerli common-mode ve swing aralığı zorunlu |
| `WE` | Giriş | Yerel write/accept olayı; periyodik clock değildir |
| `RESET` | Giriş | Hücreyi tanımlı başlangıç durumuna getirir |
| `Q_P/Q_N` | Çıkış | Tutulan diferansiyel durum |
| `READY` | Çıkış | Yakalama ve hold durumunun tamamlandığını bildirir |
| `FAULT` | Çıkış | Geçersiz giriş, yazma çakışması, bias veya capture hatası |

`WE` darbesi tek başına yeterli kabul edilmez: giriş penceresi, iç durum değişimi ve READY koşulu ölçülmelidir. `READY` doğrudan `WE` sinyalinin gecikmiş kopyası olamaz.

## 4. Fonksiyonel durum makinesi

1. **RESET:** `Q` tanımlı reset sembolüne zorlanır; `READY=0`.
2. **IDLE/HOLD:** `WE=0`; Q, D girişindeki değişimlerden etkilenmeden tutulur.
3. **CAPTURE:** `WE` kabul edilirken D geçerlilik penceresi içinde olmalıdır. İkinci bir yazma isteği ilk capture tamamlanmadan gelirse `FAULT` veya açıkça tanımlı back-pressure oluşur.
4. **SETTLE:** Diferansiyel Q çıkışı izin verilen seviye ve gürültü marjına ulaşır.
5. **READY:** Q geçerli hold durumuna geçtiğinde READY yükselir. Sonraki yazma yalnızca handshake protokolü izin verirse başlar.

Bu süreçte global clock kullanılmaz. Olaylar WE/READY/ACK el sıkışmasıyla ilerler; analog yayılma ve kararlılık süreleri yine vardır.

## 5. Aday hücre topolojisi

Araştırılacak aday, çapraz bağlı diferansiyel keeper/latch çifti, giriş akım-yönlendirme çifti, tail-current kaynağı ve yük elemanlarından oluşan statik CML state-cell'dir. WE kontrolü giriş yolunu açıp kapatır; hold yolu saklanan durumu sürdürür. RESET ayrı kontrollü bir zorlamadır.

Bu topoloji henüz transistor-level tasarım sayılmaz. Cihaz tipi (NMOS/BJT), tail-current, yük tipi, çıkış salınımı, headroom ve bias topolojisi SPICE ile seçilecektir. Çapraz bağlı pozitif geri besleme metastabiliteyi yok etmez; metastabilite penceresi ve çözülme dağılımı ayrıca ölçülür.

## 6. Qudit atomik commit

`SC_b1.READY` ve `SC_b0.READY` ayrı ayrı izlenir. `PAIR_JOIN`, her ikisinin de hazır olduğunu doğrulayana kadar `PAIR_READY` üretmez. Ortak işlem kimliği/epoch etiketi tutulur. Reset, write, ready veya fault olaylarından biri eşleşmiyorsa pair geçersizdir.

Dört kodun eşlemesi: `00`, `01`, `10`, `11`. Bu klasik dört-sembol gösterimidir; kuantum durum vektörü veya kuantum dolanıklık anlamı taşımaz.

## 7. Recurrent mesh'e bağlantı

Bir tarihsel kenar, örneğin `N3[n] → S0 → N0[n+1]`, state-cell çıkışından geçer. `Q_P/Q_N` bir sonraki epoch/transaction için kullanılmadan önce READY/PAIR_READY tamamlanır. `N2[n] → S1 → N1[n+1]` çapraz bağlantısı aynı kurala tabidir. State-cell olmadan doğrudan kombinasyonel dönüş yasaktır.

Bir state-cell'in Q çıkışını iki farklı düğüme dağıtmak fan-out=2 limitine girer; elektriksel yük ve akım bütçesi ayrıca doğrulanır. Aynı Q hattına iki sürücü bağlanamaz.

## 8. Zorunlu doğrulama

- Reset ve power-up durumunun her açılışta tekrarlanabilirliği.
- WE kabul penceresi, minimum pulse ve setup/hold.
- Hold retention, droop, noise margin ve read-disturb.
- D/Q common-mode, differential swing ve edge rate.
- READY'nin gerçek capture/settle durumuna bağlılığı.
- Metastability window ve resolution-time istatistiği.
- PVT köşeleri, Monte Carlo mismatch ve bias varyasyonu.
- Tek hücre, iki bit pair ve gecikmeli feedback loop için transient/DC/noise SPICE.
- En az 2×2 mesh üzerinde deadlock, write collision ve pair incoherence testleri.

## 9. RAQM-02 kabul kapısı

RAQM-02'ye geçiş için tek bit hücre, reset/hold/capture/READY koşullarını SPICE ve bench testlerinde karşılamalı; iki hücreli pair commit eski-yeni bit karışmasına izin vermemeli; bir gecikmeli feedback loop kararlı ve tekrarlanabilir olmalıdır. Bu kapı geçilmeden büyük mesh, analog optimization veya özel programlama modeli tasarım dondurmasına alınmaz.
