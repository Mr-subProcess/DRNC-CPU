# Paket Manifestosu

| Kategori | İçerik | Durum |
|---|---|---|
| Mimari dokümantasyon | 22 teknik şartname | Dahil |
| Karar kaydı | ADR-001…ADR-024 | Dahil |
| Recurrent mesh | Ana recurrent dönüş + 2 çapraz geçmiş geri-besleme | Kavramsal topoloji |
| CML state-cell | 3 matched-pair package + tail-sink BJT (7 transistor adayı) | Elektriksel ön tasarım |
| PCB | 1 hücreli test kuponu kat planı | Üretime hazır değil |
| BOM | Aday transistorlar + ayarlanacak pasifler | Ön BOM |
| Pinout | Test kuponu arayüzü + transistor pin/net map | Ön arayüz |
| Doğrulama | Test matrisi, bring-up, riskler ve C-element truth table | Dahil |
| Önceki revizyon | RAQM-01C donanım paketi | Referans/baseline |
| Kod / compiler | Hiçbir kaynak veya yürütülebilir dosya yok | Bilerek hariç |

| Ek mimari | C-element kontrol katmanı, iki-bit PAIR_VALID, event state machine, akım bütçesi | Dahil |

## Dosya kapsam kontrolü

Bu ZIP, sonraki özel programlama dilini veya kod oluşturucuyu içermez. `baseline/RAQM-01C_Hardware_Design_Package/` de donanım dokümanları ve ön PCB dosyalarıdır. RAQM-01B'deki eski Python yürütücü/test kaynakları bu pakete taşınmamıştır.
