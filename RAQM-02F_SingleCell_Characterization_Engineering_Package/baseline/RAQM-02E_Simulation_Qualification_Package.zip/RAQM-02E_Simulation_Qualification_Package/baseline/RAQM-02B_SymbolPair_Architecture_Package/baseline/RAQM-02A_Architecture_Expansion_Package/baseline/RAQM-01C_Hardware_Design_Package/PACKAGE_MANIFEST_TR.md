# Paket Manifestosu

Bu ZIP yalnızca donanım mimarisi ve PCB ön tasarım dokümanlarını içerir. İçinde `.py`, `.c`, `.cpp`, `.h`, `.exe`, firmware, compiler veya code-generator kaynakları bulunmaz.

Dosya grupları:
- README ve changelog
- 13 mimari/elektriksel tasarım belgesi
- BOM, terminasyon eşleme tablosu, net arayüz CSV
- KiCad `.kicad_pcb` ön-yerleşim dosyası
- Sistem blok, recurrent mesh, RAQM-02 state-cell ve PCB floorplan çizimleri (SVG ve PNG)
- Bench planı, kabul matrisi, risk/iddia kaydı
- Üretici veri sayfası referansları

## Dosya envanteri (RAQM-01C paketi)
- `CHANGELOG_TR.md`
- `README_TR.md`
- `decisions/DESIGN_DECISION_REGISTER_TR.md`
- `docs/01_SYSTEM_ARCHITECTURE_TR.md`
- `docs/02_CML_NODE_AND_QUDIT_TR.md`
- `docs/03_MESH_BRANCH_RULES_TR.md`
- `docs/04_ASYNCHRONOUS_HANDSHAKE_TR.md`
- `docs/05_DRNC_ZERYA_PHYSICAL_MODEL_TR.md`
- `docs/06_STABILITY_AND_PHYSICAL_RESOLUTION_TR.md`
- `docs/07_ELECTRICAL_INTERFACE_AND_TERMINATION_TR.md`
- `docs/08_PCB_LAYOUT_AND_SIGNAL_INTEGRITY_TR.md`
- `docs/09_PIN_NET_INTERFACE_TR.md`
- `docs/10_LOCAL_STATE_CELL_SPEC_TR.md`
- `docs/11_BUILD_AND_MEASUREMENT_PLAN_TR.md`
- `docs/12_CLAIM_AND_SCOPE_REGISTER_TR.md`
- `docs/13_RAQM02_STATE_CELL_AND_PAIR_COMMIT_TR.md`
- `hardware/BOM_RAQM01C.csv`
- `hardware/NET_INTERFACE_RAQM01C.csv`
- `hardware/PCB_FILE_STATUS_TR.md`
- `hardware/PLACEMENT_AND_ROUTING_TR.md`
- `hardware/RAQM-01C_PCB_Floorplan.png`
- `hardware/RAQM-01C_PCB_Floorplan.svg`
- `hardware/RAQM-01C_PreLayout.kicad_pcb`
- `hardware/RAQM-01C_Recurrent_Mesh.png`
- `hardware/RAQM-01C_Recurrent_Mesh.svg`
- `hardware/RAQM-01C_System_Block.png`
- `hardware/RAQM-01C_System_Block.svg`
- `hardware/RAQM-02_StateCell_Concept.png`
- `hardware/RAQM-02_StateCell_Concept.svg`
- `hardware/TERMINATION_MAP.csv`
- `references/SOURCES.md`
- `validation/ACCEPTANCE_MATRIX.csv`
- `validation/BRINGUP_CHECKLIST_TR.md`
- `validation/ENGINEERING_REVIEW_TR.md`
