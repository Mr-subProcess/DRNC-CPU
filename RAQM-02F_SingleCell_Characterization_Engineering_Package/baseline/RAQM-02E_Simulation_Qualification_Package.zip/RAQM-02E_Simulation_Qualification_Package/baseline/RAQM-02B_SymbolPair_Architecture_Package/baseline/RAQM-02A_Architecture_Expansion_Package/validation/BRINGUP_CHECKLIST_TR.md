# RAQM-02A İlk Kupon Bring-up Kontrol Listesi

## Üretim öncesi
- [ ] BCM847BS ve BC847B sipariş kodları / güncel datasheet doğrulandı.
- [ ] U1/U2/U3 SOT363 pin-1 yönü ve transistor eşleşmesi footprint'e göre doğrulandı.
- [ ] U1 data, U2 cross-coupled hold, U3 mode-select transistor bağlantıları netlist ile kontrol edildi.
- [ ] Q1 tail sink bağlantısı ve emitter resistor değeri SPICE sonuçlarıyla seçildi.
- [ ] RL_P/RL_N eşleşmesi ve collector headroom hesaplandı.
- [ ] VCM_DATA ve VCM_WE aralıkları SPICE ile belirlendi.
- [ ] WE differential polarity ve source impedance tanımlandı.
- [ ] Q outputs için yüksek empedanslı differential probe seçildi.
- [ ] PCB GND plane, kısa cross-coupling ve decoupling gözden geçirildi.
- [ ] ERC/DRC/3D clearance ve footprint pad eşlemesi tamamlandı.

## İlk güç
- [ ] Hücreye bağlı olmayan kısa devre ve net kontrolleri yapıldı.
- [ ] +3V3 akım limiti en düşük güvenli seviyeden başlatıldı.
- [ ] VBIAS_TAIL kapalıyken beklenmeyen tail current yok.
- [ ] VBIAS kademeli artırılırken TP_I_TAIL ölçülüyor.
- [ ] Kolektör/common-mode voltajları SPICE operating point ile karşılaştırılıyor.
- [ ] Aşırı ısınma veya besleme çökmesi varsa hemen kapatılıyor.

## Dinamik test
- [ ] Önce 1 kHz sınıfı düşük hızda WRITE/HOLD.
- [ ] Her iki state polaritesi yazıldı.
- [ ] HOLD sırasında D toggle edilerek Q retention gözlendi.
- [ ] WE/D setup-hold sweep yapıldı.
- [ ] Problama etkisi ve output load raporlandı.
- [ ] Test daha yüksek frekanslara ancak önceki basamaklar temiz geçince çıkarıldı.

**Bu liste tamamlanmadan RAQM-02A kartını üretime/uzun süreli çalışmaya alma.**
