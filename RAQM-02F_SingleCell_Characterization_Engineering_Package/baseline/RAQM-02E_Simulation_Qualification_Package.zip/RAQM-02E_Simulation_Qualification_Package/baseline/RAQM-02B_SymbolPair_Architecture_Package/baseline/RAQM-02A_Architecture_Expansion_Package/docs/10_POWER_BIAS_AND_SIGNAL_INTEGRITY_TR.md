# 10 — Güç, Bias ve Diferansiyel Sinyal Bütünlüğü

## 1. Güç alanları

- `VDD_CML`: CML collector/load üst rayı.
- `GND`: ortak referans.
- `VBIAS_TAIL`: tail current sink ayarı veya referans girişi.
- `VCM_DATA`: D± data pair common-mode ayarı.
- `VCM_WE`: WE± mode-select common-mode ayarı.
- `VBIAS_MON`: ileride kullanılacak settle monitor/reference.

İlk kuponda bazı bias noktaları harici laboratuvar kaynağıyla ayarlanabilir. Bias generator ürün özelliği olarak varsayılmaz.

## 2. Statik güç

Bir state-cell HOLD modunda iken tail current akışı devam eder. İlk yaklaşım:

`P_cell ≈ VDD · I_TAIL + P_bias + P_buffer`.

Bu, tam güç modeli değildir; ölçüm için bütçe başlangıcıdır. Mesh büyüdükçe state-cell başına static power toplamı ölçeklenir. “In-fabric memory'nin güç maliyeti sıfırdır” iddiası yapılmaz.

## 3. Common-mode ve headroom

CML state-cell'in input, internal node ve output common-mode seviyeleri birbirine eşit olmak zorunda değildir; ama her transistor'un V_BE, V_CE ve aktif bölge/headroom koşulları sağlanmalıdır. Q output seviyeleri data pair ve mode pair'in bias aralığını aşmamalıdır. Bu nedenle D± ve WE± common-mode ayrı ayarlanır.

## 4. PCB kuralları

- QP/QN, D+/D− ve WE+/WE− çiftleri aynı katmanda, kısa ve geometrik olarak dengeli tutulur.
- Diferansiyel çiftlerin altında kesintisiz GND referans düzlemi bulunur.
- Tail-current ve bias hatları hızlı çıkış çiftlerinden ayrılır.
- QP/QN doğrudan uzun header kablosuyla yüklenmez; ilk ölçüm high-impedance differential probe ile yapılır.
- 50 Ω terminasyon, EPT22/EP56 uygulamasından otomatik kopyalanmaz. State-cell collector load ve test ekipmanı koşuluna göre ayrıca belirlenir.
- Bypass kondansatörleri supply pinlerinin yakınında, kısa dönüş yolu ile konur.

## 5. Eski RAQM-01C terminasyonundan fark

RAQM-01C, belirli PECL/ECL entegrelerinin üretici yük koşuluna göre VTT terminasyon kullanır. RAQM-02A BJT CML latch kuponu farklı bir topolojiye sahiptir; onun yükleri transistor headroom ve amaçlanan alıcı input impedance ile seçilir. İki kartın direnç/terminasyon kuralları birbirine doğrudan taşınamaz.
