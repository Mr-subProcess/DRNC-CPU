# Yerleşim ve Yönlendirme Rehberi

## Zone map

- J1 solda, kısa low-speed host hatları.
- U1–U4 giriş çeviricileri sol-orta.
- R15–R30, U5/U6 giriş pinlerinin yakınında; her bir EPT22 differansiyel iletkenini VTT'ye sonlandırır.
- U5/U6 MUX merkezi.
- R31–R38, U7/U8 alıcı girişlerinin yakınında; EP56 çıkışlarını VTT'ye sonlandırır.
- U7/U8 sağda; OUT0…OUT3 host seviyesine dönüşür.
- U9/U10 control C-element'i veri yolundan ayrı tut.
- J2 +3V3 ve J4 VTT girişleri ayrı, etiketli olmalıdır.

## Routing order

1. +3V3/GND return plane ve VTT distribution.
2. EPT22→EP56 sekiz diferansiyel giriş çifti.
3. EP56→EPT23 dört diferansiyel çıkış çifti.
4. Selector ve diğer low-speed kontrol hatları.
5. Host interface ve test bağlantıları.

## Sonlandırma yerleşimi

Her PECL çıkışının iki iletkeni alıcı tarafında ayrı 49,9 Ω dirençle VTT'ye bağlanır. Pair-to-pair skew, trace length, via sayısı ve receiver pin breakout aynı topolojiyle yönetilir. VTT trace'i terminasyon bankına düşük empedanslı dağıtılmalı; yük akımının analog ground return'ü üzerinden dijital host ground'una dolaşması önlenmelidir.
