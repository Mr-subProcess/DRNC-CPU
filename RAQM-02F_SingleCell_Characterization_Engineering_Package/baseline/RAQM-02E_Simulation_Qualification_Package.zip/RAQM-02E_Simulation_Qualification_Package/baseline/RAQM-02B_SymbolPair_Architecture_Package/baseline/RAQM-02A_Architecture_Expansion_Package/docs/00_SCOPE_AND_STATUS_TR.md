# 00 — Kapsam, Sürüm ve Kanıt Seviyesi

## 1. Ürün tanımı

RAQM, recurrent/asenkron diferansiyel düğümlerden oluşan, belirli veri akışlarını fiziksel topolojide yürütmesi araştırılan bir **ön-hızlandırıcı mimarisidir**. İlk hedef; seçilmiş matematiksel alt problemleri yönlendirme, yerel durum saklama ve ileride analog ağırlıklı ağlarla işlemek için ölçülebilir yapı taşları geliştirmektir.

## 2. Üç kanıt sınıfı

- **Tasarım kararı:** dokümanda normatif olarak belirlenmiş mimari kural; fiziksel olarak doğrulanmış olduğu anlamına gelmez.
- **Aday devre:** transistor topolojisi, bileşen sınıfı veya PCB kat planı; SPICE/ölçüm görmeden çalışır kabul edilmez.
- **Doğrulanmış sonuç:** belirtilmiş cihaz, gerilim, sıcaklık, yük, ölçüm düzeneği ve tekrar sayısıyla kaydedilmiş SPICE/bench sonucu.

Bu paketteki yeni CML state-cell, aday devredir. 22 otomatik yazılım testi veya önceki simülasyon sonuçları donanım kanıtı değildir; yeni paket hiçbir uygulama kodu içermez.

## 3. Bugünkü ve sonraki fiziksel kapsam

| Revizyon | Gerçek kapsam | Henüz olmayan |
|---|---|---|
| RAQM-01C | 4 PECL/ECL MUX kanalı, 2×2-bit klasik sembol, host kontrollü | Yerel state-cell, analog sum, fiziksel recurrent mesh |
| RAQM-02A | Tek statik CML state-cell test kuponu | Çok hücreli mesh ve optimizasyon |
| RAQM-02B | 2×2 yerel state-cell ağı | Geniş mesh, genel analog çözüm |
| RAQM-03 | Dal/arbiter/join/recurrent kontrol dokusu | Genel problem çözücü |
| RAQM-04 | Sınırlı ağırlıklı current-sum ve relaksasyon | Evrensel optimizasyon garantisi |

## 4. Terminoloji

- **Clockless:** veri çekirdeğinde periyodik global clock yoktur; fiziksel zaman ve gecikmeler vardır.
- **Generation:** token/işlem neslini ifade eden mantıksal etiket; global sayaç veya program counter değildir.
- **Qudit:** bu prototipte iki diferansiyel bitin ürettiği klasik dört-sembollü elektriksel kod. Kuantum qudit değildir.
- **State-cell:** besleme varken diferansiyel durumu koruyan statik, uçucu (volatile) hücre. Güç kesilince veri kaybolur.
- **Recurrent edge:** state-cell üzerinden lag≥1 gecikmeli geçmiş durum bağlantısı.
- **Completion:** bir işin alındığının/kararlı olduğunun ayrı doğrulama olayı; ACK ile analog SETTLED aynı sinyal değildir.
