# Üretici ve Teknik Kaynaklar

Tüm elektriksel değerler tasarımın yapıldığı tarihte erişilen üretici dokümanlarından alınmıştır. Satın alma ve PCB üretiminden önce veri sayfalarının son revizyonu tekrar kontrol edilmelidir.

1. **onsemi — MC10EP56 / MC100EP56**, Dual Differential 2:1 Multiplexer, Data Sheet MC10EP56/D, Revision 20, 19 Şubat 2026.  
   https://www.onsemi.com/download/data-sheet/pdf/mc10ep56-d.pdf  
   Kullanılan bilgiler: dual differential 2:1 MUX, pinout, 3,3 V PECL modu, VCC/VEE, output load 50 Ω to VCC−2.0 V, typ delay ve fmax.

2. **onsemi — MC100EPT22**, Dual LVTTL/LVCMOS to Differential LVPECL Translator, Data Sheet MC100EPT22/D, Revision 15, Haziran 2024.  
   https://www.onsemi.com/pdf/datasheet/mc100ept22-d.pdf  
   Kullanılan bilgiler: dual channel, pinout, VCC 3,0–3,6 V, typical propagation delay/fmax, VOH/VOL ve 50 Ω to VCC−2.0 V yük koşulu.

3. **onsemi — MC100EPT23**, Dual Differential LVPECL/LVDS/CML to LVTTL/LVCMOS Translator, Data Sheet MC100EPT23/D, Revision 20, Haziran 2024.  
   https://www.onsemi.com/download/data-sheet/pdf/mc100ept23-d.pdf  
   Kullanılan bilgiler: diferansiyel giriş desteği, pinout, 1,5 ns typical propagation delay ve >275 MHz maximum operating frequency.

4. **onsemi AND8020/D — Termination of ECL Logic Devices.**  
   https://www.onsemi.com/  
   MC100EP56 ve MC100EPT22 veri sayfalarının işaret ettiği terminasyon uygulama notu. Üretim öncesi tam uygulama notu ayrıca gözden geçirilmelidir.

## Veri sayfası sınırı

Datasheet'in tipik gecikme ve frekans rakamları tekil entegre test koşullarına aittir. Kart gecikmesi, sistem throughput'u, optimizasyon yakınsama süresi veya enerji/çözüm değeri olarak kullanılamaz.
