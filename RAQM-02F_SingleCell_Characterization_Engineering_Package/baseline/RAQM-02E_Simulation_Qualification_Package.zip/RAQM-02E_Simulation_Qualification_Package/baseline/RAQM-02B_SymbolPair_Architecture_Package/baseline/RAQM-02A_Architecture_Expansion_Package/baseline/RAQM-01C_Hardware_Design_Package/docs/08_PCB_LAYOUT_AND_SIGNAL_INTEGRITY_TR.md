# 08 — PCB Tasarımı ve Sinyal Bütünlüğü

## 1. Rev-C kart mimarisi

Kart 4 katmanlı olarak düşünülmüştür:

1. **L1 / Top:** bileşenler, kısa diferansiyel fanout ve kritik sinyal izleri.
2. **L2 / GND plane:** kesintisiz referans düzlemi; diferansiyel hatların altında bölünmüş boşluk oluşturulmaz.
3. **L3 / Power:** +3V3 ve VTT bölgesel güç dağıtımı.
4. **L4 / Bottom:** kontrol sinyalleri, düşük hızlı bağlantılar ve gerektiğinde tamamlayıcı diferansiyel izler.

Kesin 50 Ω tek-hat empedans geometrisi, PCB üreticisinin gerçek FR-4 malzemesi, stack-up, bakır kalınlığı, prepreg/core ve solder mask verileriyle hesaplanmalıdır. Çizimde gösterilen iz aralığı veya kalınlığı üretim empedansı olarak kabul edilmez.

## 2. Diferansiyel hat kuralları

- Her P/N çifti aynı katmanda ve aynı referans düzlemi üzerinde ilerlemelidir.
- Her iletken için 50 Ω hat varsayımı, datasheet sonlandırmasıyla birlikte değerlendirilir. Otomatik olarak 100 Ω diferansiyel sonlandırmaya çevrilmez.
- P/N izleri eş uzunluklu, aynı via sayısında ve benzer çevresel geometride olmalıdır.
- İlk yerleşim hedefi: bir çift içindeki uzunluk farkını mümkün olduğunca küçük tutmak (ön hedef ≤0,5 mm); üretici stack-up ve zaman bütçesiyle son değer yeniden hesaplanmalıdır.
- Pair altında plane split, test header stub, gereksiz via ve uzun branşman yasaktır.
- Termination dirençleri ilgili alıcı pinlerine çok yakın yerleştirilir; ortak VTT hattı geniş ve düşük empedanslı olmalıdır.

## 3. Yerleşim bölgeleri

- Sol: host konektörü ve 3,3 V/low-speed girişleri.
- Sol-orta: U1–U4 LVTTL→LVPECL çeviricileri.
- Orta: U5–U6 MUX kanalları ve 16 adet giriş çifti sonlandırması.
- Sağ: U7–U8 LVPECL→LVTTL alıcıları ve 8 adet çıkış çifti sonlandırması.
- Kenar: J4 VTT girişi, J2 +3V3 girişi, ölçüm noktaları.
- U9/U10 kontrol mantığı, yüksek hızlı diferansiyel çiftlerden fiziksel olarak ayrılır.

## 4. Güç ve geri besleme önlemleri

- +3V3 pin20'yi host konektörüne geri taşımayın; J1 pin20 NC'dir.
- J2 kartın +3V3 girişidir; host'un ayrı 3,3 V kaynağıyla paralel bağlanmaz.
- J4 yalnızca 1,30 V civarı, sink yeteneği doğrulanmış VTT kaynağı içindir.
- VTT ve +3V3 test noktaları ayrı işaretlenmelidir.
- Her hızlı IC'nin VCC pinlerine yakın 100 nF decoupling; cihaz gruplarında ek bulk kapasitör kullanılır.
- VTT bankına yakın en az 100 nF ve 1 µF bypass kondansatörü yerleştirilir.

## 5. KiCad dosyası

`hardware/RAQM-01C_PreLayout.kicad_pcb` mevcut taslak üstüne terminasyon ve VTT girişlerini ekleyen, footprint ve net atamalarını içeren ön-yerleşim dosyasıdır. İzler yönlendirilmemiştir. Dosya düzenleme/yerleşim başlangıcıdır; DRC, ERC, 3D ve üretici empedans kontrolünden geçirilmeden üretime gönderilemez.

## 6. Üretim öncesi gerekli çıktılar

- Onaylı şematik ve netlist karşılaştırması.
- PCB üreticisi stack-up onayı ve impedance coupon planı.
- DRC=0 kritik hata ve ERC=0 kritik hata.
- Gerber/ODB++, NC drill, BOM, pick-and-place.
- VTT source/sink regülatörü veya harici bench harness bağlantı şeması.
- Gerçek bileşen footprints/pin-1 yönleriyle üretici land pattern çapraz kontrolü.
