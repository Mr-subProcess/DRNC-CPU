# Tasarım Karar Kaydı — RAQM-01C

| ID | Karar | Gerekçe | Etki |
|---|---|---|---|
| ADR-001 | RAQM ilk aşamada ön-hızlandırıcıdır | Genel amaçlı CPU kapsamı erken ve doğrulanmamış | Host-yardımlı test modeli korunur |
| ADR-002 | Veri düzleminde global clock yoktur | Olay tabanlı çalışma hedefi | REQ/ACK ve completion tasarımı zorunlu |
| ADR-003 | Her recurrent kenar state-cell üzerinden geçer | Sıfır-delay loop ve tanımsız kararlılık önlenir | RAQM-02 state-cell gerekir |
| ADR-004 | Qudit sembolü iki diferansiyel bitten oluşur | İlk kartın ölçülebilir dijital kodlaması | 00/01/10/11 doğrulanabilir |
| ADR-005 | İlk kartta standart PECL/ECL entegre kullanılır | Temin edilebilir ve datasheet tabanlı prototip | Özel üç-gate transistor iddiası yok |
| ADR-006 | Tüm hızlı çiftler 50 Ω per-leg ve VTT ile sonlandırılır | Onsemi önerilen yük koşulu | 24 resistor + harici 1.30 V sink VTT |
| ADR-007 | Host J1 pin20 NC'dir | Çift 3,3 V kaynağı/backfeed riski | Kart beslemesi yalnız J2 üzerinden |
| ADR-008 | C-element ile analog completion ayrıdır | Veri alındı ≠ optimizasyon yakınsadı | Ayrı READY/SETTLED mimarisi |
| ADR-009 | Yazılım/kod oluşturucu sonraki aşamadır | Fiziksel semantics önce kesinleşmeli | Pakette hiçbir uygulama kodu yok |
| ADR-010 | PCB yalnızca ön-yerleşim olarak dağıtılır | DRC, yönlendirme ve ölçüm tamamlanmadı | Gerber üretimi yasak |

| ADR-011 | İki-bit sembol iki diferansiyel state-cell ile tutulur | Bitler farklı epoch'lardan karışamaz | PAIR_JOIN her iki READY'yi bekler |
| ADR-012 | State-cell clock ile değil WE/READY olayıyla çalışır | Global clock mimarisi korunur | Capture/hold penceresi analog ölçülür |
