# RAQM-02B Tasarım Karar Kaydı

| ID | Karar | Durum | Gerekçe |
|---|---|---|---|
| D-020 | İlk ürün ön-hızlandırıcıdır, genel CPU değildir | Donduruldu | Kapsamı yönetmek |
| D-021 | Her sembol iki diferansiyel bit hücresidir | Donduruldu | 00/01/10/11 gösterimi |
| D-022 | Sembol geçerliliği PAIR_VALID ile yönetilir | Donduruldu | Ara kodun tüketilmesini önlemek |
| D-023 | Q pinleri eşzamanlı değişmek zorunda değildir | Donduruldu | Fiziksel latch davranışını doğru ifade etmek |
| D-024 | 02B tek outstanding transaction destekler | Donduruldu | Tag/queue tasarımını sonraya bırakmak |
| D-025 | Recurrent edge lag≥1 ve state-cell üzerinden | Donduruldu | Kombinasyonel çevrimi engellemek |
| D-026 | SYNC_JOIN ile HISTORY_COMBINE ayrıdır | Donduruldu | Farklı generation'ları yanlış eşleştirmemek |
| D-027 | Branch kopyası aktif driver gerektirir | Donduruldu | Pasif akım split kaybı |
| D-028 | Analog relaxation, latch state'ten ayrıdır | Donduruldu | Yanlış solver iddiasını önlemek |
| D-029 | BCM847BS eşleştirilmiş transistor adayıdır | Geçici | SPICE/bench gerekir |
| D-030 | +3V3 yalnız rail adayıdır | Geçici | Bias/headroom sonuçları bekleniyor |
| D-031 | Pair-valid C-element bu kartta harici/harici fixture kontrollüdür | Geçici | Önce capture hücresi karakterize edilsin |
| D-032 | Üretim PCB'si ancak ERC/DRC ve testlerden sonra | Donduruldu | Güvenilir prototipleme |
