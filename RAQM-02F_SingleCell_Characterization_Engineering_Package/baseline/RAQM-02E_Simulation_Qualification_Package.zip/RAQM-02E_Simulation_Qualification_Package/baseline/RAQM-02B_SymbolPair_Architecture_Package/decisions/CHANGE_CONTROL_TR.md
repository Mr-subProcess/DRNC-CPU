# Değişiklik Kontrolü

Bu paketteki normatif değişiklikler `CHANGELOG_TR.md` ve `DESIGN_DECISION_REGISTER_TR.md` ile izlenir. PCB netlistine geçilecek her değişiklikte:

1. ilgili pinout/BOM/şematik aynı revizyona alınır,
2. bağlantı tabloları güncellenir,
3. test matrisi etkileniyorsa yeni test eklenir,
4. eski revizyon baseline altında değiştirilmeden korunur,
5. üretim dosyaları yalnız tek bir release hash'inden çıkarılır.
