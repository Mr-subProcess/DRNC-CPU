# PCB Üretim ve Revizyon Dondurma Kapıları

Bir kartın “üretime hazır” sayılabilmesi için aşağıdaki kapıların tamamı kapanmalıdır:

1. **Şematik:** tüm pin/terminal/netler, güç ağacı, bias ve protection açıkça çizilmiş.
2. **Model:** kullanılan her transistör için üretici SPICE modeli veya doğrulanmış model; sıcaklık ve mismatch kapsamı kayıtlı.
3. **DC:** tüm çalışma noktaları, VCE/VBE, current, power ve headroom limitleri içinde.
4. **Transient:** write/hold, setup/hold, WE skew, invalid input, capture ve fault geçişleri.
5. **C-element/pair control:** fiziksel transistor topolojisi, metastabilite/qualification ve fail-safe davranış karakterize edilmiş; harici fixture bağımlılığı kaldırılmış veya ürün hedefi olarak açıkça kabul edilmiş.
6. **PCB:** pin-1, footprint, return path, katman yığını, decoupling, differential routing ve prob yükü kontrol edilmiş.
7. **ERC/DRC:** sıfır kritik hata; tüm istisnalar gerekçeli.
8. **BOM:** tam orderable parça kodu, paket, alternatif ve bulunabilirlik doğrulanmış.
9. **Bench:** test matrisi, tekrarlı sonuçlar, sıcaklık/rail ve hata oranı kayıtlı.
10. **Release:** Gerber, drill, assembly, BOM ve revision hash aynı netlist revizyonundan üretilmiş.

Bu paket bu kapıları kapattığını iddia etmez; bir sonraki mühendislik işlerinin kabul ölçütlerini tanımlar.
