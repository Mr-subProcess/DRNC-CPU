# RAQM-02B Bring-up Kontrol Listesi

## Üretim öncesi
- [ ] Güncel BCM847BS v8 pin ve package outline doğrulandı.
- [ ] Her Ux footprint pin-1 yönü netlist ile çift kontrol edildi.
- [ ] Kesin VDD/bias/RL/RE değerleri SPICE DC + transient ile belirlendi.
- [ ] Tüm BJT DC çalışma noktaları aktif bölge ve güç sınırında.
- [ ] ERC/DRC hatasız; yönlendirme ve parazit/impedans raporu tamam.
- [ ] BOM orderable suffix, package ve bulunabilirlik doğrulandı.

## İlk güç
- [ ] Akım limitli güç kaynağı kullan.
- [ ] Önce tek B0 hücresini biasla; B1 kapalı/inhibit.
- [ ] Her base/collector/emitter gerilimini kaydet.
- [ ] Q çıkışını yüksek empedans diferansiyel probla ölç.
- [ ] B0 write/hold ve ters polariteyi doğrula.
- [ ] Aynı prosedürü B1 için tekrarla.

## Pair test
- [ ] PAIR_VALID ilk durumda düşük.
- [ ] 00, 01, 10, 11 sembollerini dene.
- [ ] ACK_B0 ve ACK_B1 ayrı ayrı zaman damgalı ölç.
- [ ] Tek ACK olduğunda PAIR_VALID yükselmediğini doğrula.
- [ ] Her iki ACK ve fault-free commit sonrasında valid yükselmesini doğrula.
- [ ] Bir sonraki write başlamadan valid'in düştüğünü doğrula.
- [ ] Timeout, invalid input ve reset fault injection testlerini yap.

## Laboratuvar kayıtları
- [ ] VDD, supply current, I_TAIL0/1.
- [ ] Q0/Q1 differential swing and common-mode.
- [ ] Capture/hold latency distributions.
- [ ] Setup/hold and WE skew.
- [ ] Temperature and rail margins.
- [ ] Probe/load sensitivity and read-disturb.
