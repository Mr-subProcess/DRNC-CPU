# RAQM-02B — İki Bitlik Sembol Çifti ve Recurrent Mesh Mimarisi

**Tam ad:** Recurrent Asynchronous Qudit Mesh — Symbol-Pair Architecture B  
**Tarih:** 17 Kasım 2026  
**Sahip:** Oğuz Kağan Sayın  
**Ürün aşaması:** Ön-hızlandırıcı araştırma prototipi  
**Paket türü:** Mimari + elektriksel tasarım şartnamesi + test kartı konsepti  
**Üretim durumu:** Üretime hazır değildir.

## 1. Bu revizyonun hedefi

RAQM-02A tek diferansiyel durum hücresini tanımlıyordu. RAQM-02B bu hücreyi iki bağımsız bit hücresinden oluşan **tek bir klasik dört-sembollü elektriksel kayıt** hâline getirir. Ayrıca gelecekteki recurrent mesh için dallanma, tarihsel geri besleme, join, asenkron olay ve analog hesaplama sınırlarını daha kesin tanımlar.

Bu sistem şu anda genel amaçlı işlemci değildir. İlk ürün hedefi, belirli matematiksel iş yükleri için host yanında çalışan bir **ön-hızlandırıcı çekirdeği** geliştirmektir.

## 2. Kesin ürün sınırı

- Global periyodik clock hedeflenmez.
- Program Counter, instruction fetch/decode ve genel amaçlı işletim sistemi bu ön-hızlandırıcı çekirdeğinin parçası değildir.
- İlk donanım deneyi iki diferansiyel CML state-cell ile bir adet iki-bitlik sembolü saklar; ACK qualification ve PAIR_VALID birleştirmesi 02B aşamasında harici test fikstüründedir.
- Sembol geçerliliği iki hücrenin ayrı capture ölçümü/ACK gözlemi harici test fikstüründe birleştirilmeden yükseltilmez; 02B kartında fiziksel C-element yoktur.
- Recurrent kenarlar yalnız state boundary üzerinden ve en az bir kabul edilmiş işlem gecikmesiyle döner.
- CML dataplane'de klasik CMOS AND/OR kapı ağı kullanılmaz. Kontrol düzleminin nihai transistor topolojisi ayrıca tasarlanacak ve ölçülecektir.
- Bu aşamada programlama dili, derleyici, konfigürasyon üreticisi, firmware veya uygulama kodu YOKTUR. Bunlar fiziksel mimari ve arayüz sözleşmeleri dondurulduktan sonra geliştirilecektir.

## 3. Yeni mimari kararlar

1. **Bit hücresi ve sembol ayrımı:** Bir CML state-cell bir diferansiyel bit saklar. İki hücre birlikte `B1:B0` sembolünü saklar.
2. **PAIR_VALID:** Yazma başlarken geçersizleşir; `ACK_B0 ∧ ACK_B1 ∧ ¬FAULT` koşulu ölçülmeden tekrar geçerli olmaz.
3. **Ara kod tüketimi yasak:** İki Q çıkışı geçici olarak farklı anlarda değişebilir. PAIR_VALID düşükken aşağı akış sembolü okuyamaz.
4. **Tek outstanding transaction:** İlk RAQM-02B test kartında bir sembol çifti için aynı anda yalnız bir yazma işlemi kabul edilir. Çoklu uçuş ve token etiketleri sonraki mesh revizyonudur.
5. **Recurrent edge:** Geri besleme doğrudan kombinasyonel kabloyla kurulmaz. Her tarihsel kenar açık bir state-cell/lag sınırından geçer.
6. **İşlem türleri ayrıdır:** MUX, FORK, SYNC_JOIN, ARBITER_JOIN, HISTORY_READ ve WEIGHTED_SUM birbirinin yerine kullanılamaz.
7. **Analog çözüm ayrı aşamadır:** İki-bit latch'in dört sembolü, analog çok-seviyeli qudit veya kuantum süperpozisyon değildir. Analog relaxation için ayrı hücre, model ve ölçüm gereklidir.

## 4. Paket içeriği

- `docs/` — normatif mimari, state-pair transaction, dallanma, recurrent edge, DRNC–Zerya eşlemesi, fiziksel zaman, analog relaxation sınırı ve ölçekleme.
- `hardware/` — iki-bitlik sembol çifti blok şemaları, state-cell konsepti, PCB kat planı, BOM, konnektör pinout'ları, pin eşlemesi ve dondurulmamış parametre listesi.
- `validation/` — 31 maddelik doğrulama matrisi, bring-up ve üretim kapıları.
- `decisions/` — karar kaydı.
- `references/` — üretici datasheet ve mimari kaynaklar.
- `baseline/RAQM-02A_Architecture_Expansion_Package/` — önceki 02A paketi değişmeden eklenmiştir.

## 5. Donanım düzeyinin dürüst beyanı

Bu ZIP, **tam bir mühendislik tasarım paketi ve PCB konseptidir**; üretim dosyası değildir. Aşağıdakiler bilerek bu aşamada üretilmemiştir:

- transistor-level SPICE netlist veya doğrulanmış model deck,
- kesin bias ve direnç değerleri,
- ERC/DRC'den geçmiş KiCad şematik/PCB,
- iz yönlendirmesi, Gerber, drill, Pick-and-Place,
- karakterize edilmiş C-element / pair-valid transistor devresi,
- fiziksel mesh veya ölçülmüş hız/güç/başarı oranı.

Bunları eksikmiş gibi gizlemek yerine üretim kapısı olarak listeliyoruz. `hardware/` içindeki çizimler mimari/yerleşim konseptidir; imalat verisi değildir.

## 6. Önerilen geliştirme sırası

- **02B:** Tek bir iki-bit sembol çiftini fiziksel olarak sakla; her bitin capture/hold sınırlarını ve PAIR_VALID protokolünü ölç.
- **02C:** İki sembol düğümünü aktif CML branch sürücüleri, bağımsız edge handshake ve bir gecikmeli recurrent edge ile bağla.
- **03:** Dört düğümlü recurrent mesh, FORK, SYNC_JOIN, HISTORY_READ ve transistor düzeyinde C-element/arbiter.
- **04:** Ayrı ağırlıklı akım toplama ve sönümlü analog relaxation katmanı.
- **05:** Donanım semantiği dondurulduktan sonra mimariye özel programlama dili ve kod oluşturucu.

## 7. Başlangıç notu

`RAQM-02B`, `RAQM-02A` dosyalarının yerine geçmez; onu genişletir. Önceki paketin tamamı `baseline/` altında korunmuştur.
