# RAQM-02B Kaynaklar ve Tasarım Dayanakları

## Üretici veri sayfaları

1. **Nexperia BCM847BS — NPN/NPN matched double transistor, v8, 15 July 2026**  
   https://assets.nexperia.com/documents/data-sheet/BCM847BS.pdf  
   Kullanım: SOT363-3 pinout (1=E1, 2=B1, 3=C2, 4=E2, 5=B2, 6=C1), matched dual özelliği, V_BE matching ve mutlak maksimum sınırlar. Üreticinin V_BE eşleşmesi 2 mV max değeri yalnız V_CE=5 V, I_C=2 mA, 25 °C koşulundadır; tasarımın otomatik eşik garantisi değildir.

2. **Nexperia BC847x series — 45 V, 100 mA NPN, Rev. 13, 1 July 2022**  
   https://assets.nexperia.com/documents/data-sheet/BC847X_SER.pdf  
   Kullanım: BC847B tek NPN tail sink adayının SOT23 pinout ve elektriksel sınırları. Mutlak maksimumlar çalışma noktası olarak kullanılmaz.

3. **Nexperia BCM847BS product page**  
   https://www.nexperia.com/product/BCM847BS  
   Kullanım: eşleştirilmiş dual NPN'nin current gain ve base-emitter matching özelliklerinin üretici tanımı.

## CML ve asynchronous design kaynakları

4. **MIT 6.776 — High-Speed Communication Circuits, SCL/CML latches**  
   https://live.ocw.mit.edu/courses/6-776-high-speed-communication-circuits-spring-2005/9259f09cec66b687e4b7e21461f1626e_lec21.pdf  
   Kullanım: differential latch/cross-coupled feedback ilkesi. Bu kaynak MOS CML/SCL örnekleri içerebilir; RAQM BJT topolojisine birebir model sayılmaz.

5. **DTU — Design of an asynchronous communication network for an audio DSP chip**  
   https://www2.imm.dtu.dk/pubdb/edoc/imm3974.pdf  
   Kullanım: four-phase bundled-data handshake, C-element ve arbiter/mutex risklerinin temel kavramları.

6. **RAQM-02A previous baseline package**  
   `baseline/RAQM-02A_Architecture_Expansion_Package/`  
   Kullanım: önceki mimari ve state-cell kupon tasarım kararlarını tarihsel referans olarak saklar.

## Kaynak yorum kuralı

Veri sayfasındaki tipik `f_T` değeri, RAQM kartının çalışma frekansı değildir. Matched-pair değeri yalnız üreticinin belirttiği koşulda aynı paket içindeki çift için geçerlidir. Kartın hızı, güç tüketimi, hold süresi, hata oranı veya optimizer başarısı bu kaynaklardan çıkarılamaz; ölçüm gerekir.
