# 32 — Doğrulama ve Kabul Planı

## 1. Kanıt düzeyleri

- **A — Belge kontrolü:** net/pin/kurallar tutarlılığı.
- **B — Şematik/SPICE:** DC operating point, transient, mismatch/temperature sweeps.
- **C — PCB bring-up:** fiziksel rail, bias, capture/hold ve signal integrity.
- **D — Sistem:** iki-bit sembol işlemi, PAIR_VALID ve tekrarlı işlem.

Bir alt seviye geçilmeden sonraki seviye “başarılı” sayılmaz.

## 2. Kabul koşulu

00, 01, 10, 11 sembollerinin tümü B0/B1'de doğru capture edilip HOLD sırasında korunmalıdır. PAIR_VALID, tek bit capture ile değil yalnız iki ACK ve fault-free commit ile yükselmelidir. Invalid differential seviyede PAIR_VALID yükselmemelidir. Güç/ısıl/offset marjları hedef çevresinde ölçülmelidir.

## 3. Raporlanacak metrikler

- B0/B1 ayrı capture latency dağılımları,
- pair commit latency,
- valid/invalid error rate ve test sayısı,
- differential output swing ve common-mode,
- static supply current / tail current,
- hold retention süresi (besleme açıkken),
- read-disturb ve load sensitivity,
- sıcaklık/rail/bias marjları,
- setup/hold ve metastability bölgesi,
- branch/feedback eklenince skew ve backpressure.

## 4. Hız iddiası

Bu aşamada picosecond, MHz, GOPS veya “milisaniyenin altında çözüm” hedefi doğrulanmış değildir. Bütün gecikmeler test koşuluyla ölçülmeden hız beyanı yapılamaz.
