# 31 — Fault, Reset, İptal ve Tanılama

## 1. Fault sınıfları

- `F_DATA_INVALID`: diferansiyel giriş guard band içinde.
- `F_CAPTURE_TIMEOUT`: harici ölçüm fikstüründen B0 veya B1 capture-qualified ACK gözlemi gelmedi.
- `F_PAIR_MISMATCH`: iki ACK aynı pair transaction'ına ait değil veya pair control uyuşmuyor.
- `F_BIAS`: VBIAS/VCM/rail ölçümü kabul penceresinin dışında.
- `F_WE_SKEW`: WRITE/HOLD diferansiyel kontrolü geçersiz.
- `F_CONTENTION`: aynı hücrede birden fazla write isteği.
- `F_RESET_DURING_CAPTURE`: aktif capture sırasında reset.
- `F_OUTPUT_MARGIN`: Q diferansiyel swing threshold marjını sağlamıyor.

## 2. Güvenli durum

FAULT durumunda `PAIR_VALID=0` tutulur (02B prototipinde harici test fikstürünün pair-valid çıkışı düşük tutulur); yeni downstream tüketim yasaktır. ACK eksikse sentetik ACK oluşturulmaz. Yeni capture öncesi girişler ve biaslar normal duruma getirilir, ardından bilinen başlangıç sembolü reset-by-write ile yüklenir.

## 3. Reset sırası

1. Yeni PAIR_REQ kabulünü inhibit et.
2. Aktif transferi kontrollü tamamla veya FAULT/CANCEL olarak işaretle.
3. PAIR_VALID'i düşür.
4. B0/B1'i bilinen diferansiyel girişe WRITE ile al.
5. İki ACK capture ve output margin doğrulansın.
6. Pair control valid'i yeniden açsın.

Power-on'da state-cell'in rastgele/önceki durumu geçerli kabul edilmez.

## 4. Tanılama

Her bit için VDD akımı, tail akımı, Q differential swing, Q common-mode, V_BE/collector çalışma noktası, WE differential amplitude, input setup/hold ve ACK gecikmesi kaydedilir. İki hücre için ayrı sonuç tutulur.
