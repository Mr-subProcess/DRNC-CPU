# 33 — Risk Kaydı ve Açık Tasarım Kararları

| Risk | Etki | Önlem / kapanış kanıtı |
|---|---|---|
| BCM847BS pin/footprint yanlışlığı | Kartın çalışmaması/hasar | Güncel 15.07.2026 Nexperia pinning ve SOT363-3 footprint kontrolü |
| Bias/headroom yanlış seçimi | Transistor saturation, swing kaybı | SPICE DC sweep + bench DC operating point |
| İki bit arası mismatch | Hatalı sembol/invalid | Her bit ayrı threshold; PAIR_VALID guard |
| Capture yarışması | Metastabilite / yanlış ACK | Differential control skew sweep, fail-safe ACK |
| PAIR_VALID kontrolünün harici kalması | Test rig'e bağımlılık | CML C-element pair controller ayrı kupon olarak tasarlanıp doğrulanacak |
| Pasif branch split | Genlik/akım düşmesi | Aktif branch driver/current copy |
| Direct feedback | Sıfır-gecikme çevrim/salınım | Recurrent edge yalnız state boundary üzerinden |
| Analog latch'i solver saymak | Yanlış hesaplama iddiası | Analog relaxation ayrı model ve test kapısı |
| Termal etkileşim | B0/B1 threshold drift | Cell spacing, thermal sweep, current budget |
| Yük/prob etkisi | State bozulması | High-Z probe, read-disturb testleri |
| PCB kat planını üretim dosyası sanmak | Hatalı imalat | README'de açıkça konsept olarak etiketlendi |

## Açık kararlar

- VDD_CML kesin seviyesi ve toleransı.
- VCM_DATA / VCM_WE çalışma aralığı.
- I_TAIL, RL ve R_E.
- Capture threshold/qualification window.
- Pair control için fiziksel C-element topolojisi.
- B0/B1 için ortak mı ayrı bias mı.
- Gerçek ürün gereksiniminde valid-gated mi shadow-pair atomiklik mi.
