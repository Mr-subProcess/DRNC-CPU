# 24 — FORK, SYNC_JOIN, ARBITER ve Akım Toplama Kuralları

Bu kurallar normatiftir; ileride konfigürasyon üreticisi ancak bu sözleşmeyi hedefleyebilir. Bu pakette konfigürasyon kodu yoktur.

## FORK
1. Kaynak başına doğrudan fan-out en fazla 2'dir.
2. Her child ayrı edge ID ve ayrı REQ/ACK taşır.
3. FORK upstream ACK'si, iki child da ACK veya açıkça tanımlı CANCEL durumuna gelmeden verilmez.
4. Child'lardan biri FAULT alırsa diğeri de transaction politikasına göre commit/abort edilir; sessizce unutulmaz.
5. İki child tam genlik isterse aktif current-copy/buffer kullanılır.

## SYNC_JOIN
1. Doğrudan fan-in en fazla 2'dir.
2. Operandlar aynı parent token ve generation'a ait olmalıdır.
3. Her operand ayrı slotta capture edilir.
4. Join output REQ ancak tüm zorunlu slotlar doluysa yükselir.
5. Payload bitleri C-element ile birleştirilmez; C-element yalnız ready olaylarını birleştirir.

## HISTORY_COMBINE
1. Current-generation operand ile history operand farklı slotlarda tutulur.
2. `history_generation = current_generation - lag` koşulu metadata/edge düzeniyle sağlanmalıdır.
3. Bu node'un fonksiyonel matematiği açıkça belirlenmeden farklı generation'lar tek bir SYNC_JOIN'a sokulamaz.

## ARBITER_JOIN
1. Aynı state-cell veya tek kaynak için birden fazla write yarışıyorsa mutex/arbiter gerekir.
2. İki grant aynı transaction için aynı anda aktif olamaz.
3. Metastabilite çözülme süresinin teorik mutlak üst sınırı garanti edilmez.
4. Timeout, metastabiliteyi yok etmez; yalnız hata politikası uygular.

## WEIGHTED_SUM
1. Akımlar yalnız tasarlanmış summing node üzerinde birleşir.
2. `I_sum = Σ g_i I_i` ifadesi, g_i fiziksel ağırlık elemanlarıyla kalibre edildiğinde geçerlidir.
3. Headroom, lineer aralık, offset, noise, doygunluk ve güç hesaplanmalıdır.
4. WEIGHTED_SUM, MUX veya SYNC_JOIN ile eşdeğer değildir.

## Hard reject
Sıfır-gecikmeli recurrent loop, çift sürücü, belirsiz branch kimliği, eksik join operandı, arbiter olmadan multi-writer ve tanımsız analog summing node reddedilir.
