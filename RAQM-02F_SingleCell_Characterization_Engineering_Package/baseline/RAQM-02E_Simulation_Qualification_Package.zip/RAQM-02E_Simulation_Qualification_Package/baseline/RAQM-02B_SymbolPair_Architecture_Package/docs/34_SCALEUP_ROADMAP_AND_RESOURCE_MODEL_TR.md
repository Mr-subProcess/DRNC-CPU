# 34 — Ölçekleme ve Fiziksel Kaynak Modeli

## 1. Katmanlı ölçekleme

- **02B:** iki state-cell, bir sembol çifti, tek outstanding write; fiziksel hold/capture doğrulaması.
- **02C:** iki sembol node'u, bir aktif fork, bir history edge, edge başına REQ/ACK.
- **03:** N0/N1/N2/N3 dört node; N0 fork, N1/N2 sync-join, N3 history feedback; N2→N1 çapraz tarihsel port.
- **04:** ayrı analog weighted-sum ve relaxation blokları.
- **05:** compiler/codegen, yalnız sabit donanım sözleşmesine karşı.

## 2. Kaynak bütçesi

Bir bit hücresi aday topoloji olarak 3 matched-dual NPN paket + 1 tail NPN kullanır. İki-bit sembol çifti nominalde 6 matched-dual paket + 2 tail NPN gerektirir. Bu yalnız aktif transistor gruplarıdır; load resistor, bias, decoupling, probe, pair-control ve input/output buffer BOM'u dahil değildir.

Dört sembol node'lu tam bir mesh, en az 8 bit hücresi (24 matched-dual paket ve 8 tail NPN adayı) anlamına gelebilir; fork/branch driver, join, arbiter, pair-valid, buffer, bias ve terminasyon elemanları buna dahil değildir. Bu ölçekleme sayısı bir tasarım bütçesi tahminidir; üretim BOM'u değildir.

## 3. Güç ve ısı

`I_total ≈ Σ I_tail,cell + I_control + I_buffer + I_monitor`  
`P_total ≈ VDD × I_total`

HOLD durumunda tail current tüketimi sürer. Yerel state saklama ücretsiz veya sıfır-güç değildir. Düğüm sayısı arttıkça bias ve termal dağıtım da ölçeklenir.

## 4. Genişletme kapısı

Bir sembol çiftinin ölçülmüş capture/hold ve PAIR_VALID sonuçları yoksa 02C mesh PCB'si dondurulmaz. Bir recurrent edge'in ölçülmüş transaction semantics'i yoksa daha karmaşık döngüler eklenmez.
