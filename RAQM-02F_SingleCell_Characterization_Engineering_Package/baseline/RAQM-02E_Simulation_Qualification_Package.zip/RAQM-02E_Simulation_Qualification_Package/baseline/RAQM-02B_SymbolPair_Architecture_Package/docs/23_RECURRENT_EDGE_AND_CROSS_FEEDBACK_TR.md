# 23 — Recurrent Edge, Çapraz Besleme ve Geçmiş Dal Semantiği

## 1. İki grafikli model

Mesh, aynı transaction generation içindeki ileri akış grafiği `G_now` ve state boundary üzerinden dönen geçmiş grafiği `G_hist` olarak ayrılır.

- `G_now`: generation içinde yönlü çevrimsiz olmalıdır.
- `G_hist`: her kenar en az bir state-cell/commit sınırından geçer ve `lag≥1` taşır.
- `G_now ∪ G_hist` toplamı çevrim içerebilir; çevrim ancak açık state boundary ve gecikme koşuluyla yasaldır.

## 2. Geri besleme ilkesi

Bir düğümün Q çıkışı doğrudan aynı düğümün kombinasyonel girişine bağlanamaz. Tarihsel bağlantı şu sırayı izler:

`source node → edge driver/receiver → history state-cell → target history port`

State-cell write/capture kabulü tamamlanmadan yeni generation için geçmiş değer görünür sayılmaz. `lag=1`, en az bir tamamlanmış state transaction'ı anlamına gelir; sabit saniye/pikosan değerine eşit değildir.

## 3. Çapraz dal kuralı

Dallar birbirine bağlanabilir; ancak her çapraz bağlantı bir kenar kimliği taşır ve aşağıdaki türlerden biri olur:

- `CURRENT_ROUTE`: aynı generation ileri yönlü taşıma.
- `HISTORY_READ`: önceki generation state-cell çıktısı.
- `HISTORY_WRITE`: mevcut payload'ın gelecek generation için kaydı.
- `SYNC_JOIN`: aynı parent/generation operandlarını rendezvous eder.
- `ARBITER_JOIN`: alternatif isteklerden birini seçer.
- `WEIGHTED_SUM`: analog akımları tanımlı toplama hücresinde toplar.

Bir `HISTORY_READ` ile mevcut generation payload'ı otomatik olarak SYNC_JOIN sayılmaz. Bu iki farklı zaman bağlamını birleştirmek için `HISTORY_COMBINE` adlı ayrı fonksiyonel düğüm ve açık operand semantiği gerekir.

## 4. Dört düğümlü referans topoloji

- N0 → N1 ve N0 → N2: iki bağımsız ileri dal.
- N1 → N3 ve N2 → N3: aynı parent/generation için SYNC_JOIN.
- N3 → N0: bir state boundary üzerinden gecikmeli recurrent geri besleme.
- N2 → N1: ayrı history portuna, bir state boundary üzerinden çapraz geçmiş besleme.

Son iki kenar aynı-generation çevrim oluşturmaz. N1'in iki girdi bağlamı farklıdır; bunlar doğrudan tek bir SYNC_JOIN'da birleştirilemez.

## 5. Fiziksel akım çoğaltma

Bir logical FORK, iki fiziksel tam-genlikli kopya gerektiriyorsa iki bağımsız aktif branch driver/current-copy yolu kullanır. Pasif Y bağlantısı iki tam genlikli çıktı sağlamaz. Akım dengesi ve buffer bias gücü hesaplanır.

## 6. Recurrent state ile analog recurrence ayrımı

Bu revizyondaki state-cell geçmiş **sembolü** saklar. Analog optimizasyon için gerekli sürekli değişen düğüm gerilimi/akımı, ayrı bir analog state element ve dinamik sönüm ağı gerektirir. Dijital latch'i bir analog integratör olarak kabul etmek yasaktır.
