# 35 — İddia Sınırları ve Kapsam Dışı Özellikler

## Bu sürümde doğru olan ifadeler

- RAQM, global periyodik clock kullanmadan handshake tabanlı asenkron kontrol hedefler.
- CML/BJT current-steering diferansiyel hücreleri araştırma prototipinin dataplane adaylarıdır.
- Recurrent edge'ler history state-cell sınırı üzerinden planlanmıştır.
- İki diferansiyel bit, 00/01/10/11 klasik sembol kümesini kodlar.
- DRNC/Zerya, branch lineage, state history ve akım yönlendirmesini tanımlamak için kullanılan mimari/matematiksel sözleşmedir.

## Bu sürüm için ileri sürülmeyen iddialar

- Genel amaçlı CPU veya RAM yerine geçme.
- Kuantum hesaplama veya gerçek kuantum qudit.
- Clockless olduğu için sıfır gecikme.
- Her matematik problemini rezonansla anında çözme.
- Ölçülmüş picosecond çalışma, MHz/GOPS veya enerji verimliliği üstünlüğü.
- Fiziksel recurrent mesh, analog optimizer veya transistor-level C-element'in tamamlanmış olması.
- Üretime hazır PCB veya doğrulanmış yield.

İddialar ancak ölçüm, tekrar edilebilir test koşulları ve açık hata sınırlarıyla yükseltilebilir.
