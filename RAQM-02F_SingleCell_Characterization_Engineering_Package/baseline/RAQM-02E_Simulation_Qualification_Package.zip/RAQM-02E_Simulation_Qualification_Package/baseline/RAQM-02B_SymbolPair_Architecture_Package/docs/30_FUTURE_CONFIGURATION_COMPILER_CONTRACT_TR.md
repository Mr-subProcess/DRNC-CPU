# 30 — Gelecekteki Programlama Dili/Kod Oluşturucu için Donanım Sözleşmesi

## 1. Bu pakette kod yok

RAQM-02B hiçbir programlama dili, compiler, firmware, HDL, script veya kod oluşturucu içermez. Bu bölüm yalnız ileride yazılacak aracın hedefleyeceği donanım sözleşmesini dondurulacak alanlar olarak listeler.

## 2. Compiler'a ancak şu mimari sabitlerden sonra geçilir

- bit-cell elektriksel polaritesi ve valid threshold,
- pair write/commit/cancel semantiği,
- edge ve branch kimliği,
- fan-in/fan-out limitleri,
- SYNC_JOIN ve HISTORY_COMBINE ayrımı,
- recurrent lag ve state boundary,
- arbiter/fault recovery davranışı,
- analog node ve current-sum transfer aralığı,
- ölçülmüş gecikme/enerji ve kaynak bütçesi.

## 3. Gelecek konfigürasyon nesnesinin alanları

| Alan | Açıklama |
|---|---|
| node_id | Fiziksel veya mantıksal düğüm kimliği |
| node_type | CELL, FORK, MUX, SYNC_JOIN, ARBITER, HISTORY, SUM |
| edge_id | Tekil bağlantı kimliği |
| src/dst_port | Fiziksel portlar |
| lag | State boundary gecikmesi; recurrent için en az 1 |
| branch_id | Dal soy ağacı kimliği |
| generation_scope | İşlem/nesil ilişkilendirmesi; clock/PC değildir |
| polarity | Diferansiyel P/N yönü |
| bias_profile | Onaylanmış bias konfigürasyonu |
| validity_rule | ACK/PAIR_VALID/FAULT koşulu |

## 4. Derleyicinin yapmaması gerekenler

- zero-lag recurrent edge üretmek,
- geçerli sembol olmadan bit tüketmek,
- tipleri farklı join hücrelerini birbirine dönüştürmek,
- ölçülmemiş analog ağırlık veya bias uydurmak,
- global clock/PC varsaymak,
- her problem için fiziksel çözüm garantisi vermek.
