# 27 — Clockless Olay Zamanı ve Bundled-Data Tasarım Koşulları

## 1. Clockless anlamı

Global periyodik clock yoktur. Bununla birlikte REQ/ACK olayları, transistor propagation delay ve analog settling gerçek zaman alır. “Anında” veya sıfır gecikme iddiası yasaktır.

## 2. Four-phase bundled-data

Her edge için:

1. Sender payload'ı kararlı yapar.
2. REQ yükselir; sender payload'ı ACK'ye kadar tutar.
3. Receiver payload/state'i yakalar; ACK yükselir.
4. Sender REQ'yi indirir; receiver ACK'yi indirir.

`PAIR_VALID` iki bitlik pair için ayrıca commit niteliğindedir; REQ/ACK'nin yerine geçmez.

## 3. Delay constraint

Bundled-data kontrolü veri yolundan erken gelmemelidir:

`t_REQ,min ≥ t_DATA,max + t_skew + t_jitter + t_margin`

Her terim sürücü, PCB, yük, PVT ve ölçüm koşullarında karakterize edilmelidir. Sabit bir RC delay veya “picosecond” hız iddiası bu aşamada belirlenmez.

## 4. One-outstanding kuralı

RAQM-02B kuponunda aynı sembol çifti için bir transaction tamamlanmadan yenisi kabul edilmez. Böylece ayrı token ID bus gerekmeksizin tek işlem ilişkilendirmesi korunur. Multi-flight ve backpressure ağının tasarımı sonraki revizyonun kapsamıdır.
