# 26 — Analog Relaxation, Rezonans ve Hesaplama Sınırı

## 1. Terminoloji

RAQM'nin clockless olması fiziksel zamanın olmadığı anlamına gelmez. Transistor gecikmesi, RC zaman sabiti, slew, metastabilite çözülmesi ve handshake tümü fiziksel zaman içinde oluşur.

`Resonance` tek başına çözüm bulma yöntemi değildir; sönümsüz/az sönümlü rezonans salınım oluşturabilir. Bu nedenle matematiksel işlem hedefi için `analog relaxation` terimi kullanılır.

## 2. Üç farklı fiziksel iş

1. **State retention:** CML latch, ayrık diferansiyel sembolü tutar.
2. **Current routing:** diferansiyel steering ve branch driver akım yolunu seçer.
3. **Analog relaxation:** ayrı dinamik ağ, belirlenmiş hedef fonksiyon/dengeye doğru ilerler.

Birinci işin başarılı olması üçüncünün var olduğunu göstermez.

## 3. Enerji fonksiyonu iddiası

Bir optimizasyon devresi için enerji `E(x)` tanımlanmış ve fiziksel dinamik `C dx/dt = -∇E(x)` veya bu denkleme Lyapunov yaklaşımıyla denk bir sönümlü sistem olarak gösterilmiş olmalıdır. Sabit noktaya ulaşma, tek başına global optimum kanıtı değildir. Başlangıç koşulu, yerel minimumlar, doygunluk ve residual ölçülür.

## 4. READY_SETTLED

İleride `READY_SETTLED` yalnız şu koşullar birlikte sağlanınca üretilebilir:

- tüm gerekli input/state valid,
- `|dx_i/dt| < ε_i` qualification penceresi boyunca,
- problem residual `|r(x)| ≤ ε_r`,
- kısıt ihlalleri limit altında,
- saturation, oscillation, bias fault veya rail violation yok.

Bu koşullar için threshold değerleri iş yükü ve tezgâh gürültüsüne göre belirlenir. RAQM-02B latch test kartı `READY_SETTLED` üretmez.
