# 21 — İki Bitlik Sembol Çifti ve Geçerlilik Sözleşmesi

## 1. Fiziksel temsil

Bir CML state-cell tek diferansiyel karar saklar. Bir RAQM sembolü iki hücreden oluşur:

- `B0`: en düşük anlamlı bit (LSB)
- `B1`: en yüksek anlamlı bit (MSB)
- Sembol gösterimi: `B1:B0`

| Sembol | B1 | B0 | Anlam |
|---|---:|---:|---|
| `00` | 0 | 0 | Kod 0 |
| `01` | 0 | 1 | Kod 1 |
| `10` | 1 | 0 | Kod 2 |
| `11` | 1 | 1 | Kod 3 |

Bu dört sembol klasik dijital/diferansiyel bir kodlamadır. Kuantum durumu, kuantum süperpozisyon veya fiziksel Hilbert uzayı qudit'i olduğu iddia edilmez.

## 2. Diferansiyel bit kararı

Her hücre için `V_Q = V(Q_P)-V(Q_N)` tanımlanır. Pozitif ve negatif karar eşikleri arasında bir guard band bulunur:

- `V_Q ≥ +V_TH`: mantıksal 1
- `V_Q ≤ −V_TH`: mantıksal 0
- `−V_TH < V_Q < +V_TH`: INVALID/kararsız; hiçbir tüketici bu bit'i kabul edemez

`V_TH`, gürültü, offset, yük ve sıcaklık ölçümünden sonra seçilecektir. İki hücre arasında threshold eşleştiği varsayılmaz.

## 3. Sembol geçerliliği

`PAIR_VALID=1` yalnız aşağıdaki şartlarda üretilebilir:

1. B0 ve B1 aynı sembol yazma transaction'ına aittir.
2. Her iki hücre için harici ölçüm fikstürü `ACK_CAPTURE` gözlemini üretmiştir; bu revizyonda ACK karşılaştırıcısı PCB üzerinde değildir.
3. Her hücrenin diferansiyel polaritesi geçerli karar marjını sağlamıştır.
4. `FAULT=0` ve reset/inhibit aktif değildir.
5. Harici pair kontrolü iki ACK'yi aynı transaction kapsamında birleştirmiştir.

Bunlardan herhangi biri eksikse `PAIR_VALID=0` kalır.

## 4. Atomiklik düzeyi

RAQM-02B **transaction-level atomiklik** sağlar: PAIR_VALID düşükken sembol downstream tarafından tüketilemez. İki Q çiftinin analog gerilimleri aynı anda geçiş yapmaz; kısa süreli karışık kod fiziksel pinlerde görülebilir. Bu nedenle:

- PAIR_VALID düşükken `B1:B0` okunması yasaktır.
- PAIR_VALID, yeni write başlamadan önce düşürülür.
- PAIR_VALID ancak B0 ve B1 capture sonrası yükselir.
- Gerçek pin-level kesintisiz eski-sembol görünürlüğü istenirse shadow-pair bankası gerekir; bu RAQM-02D/03 tasarım seçeneğidir.

## 5. İlk kart sınırı

İlk test kartında her bit hücresi ayrı ayrı ölçülür. Capture threshold/completion gözlemleri harici karşılaştırıcı ve test fikstürü tarafından üretilir. PAIR_VALID birleşimi de harici fikstürde yapılır; bu net 02B PCB üzerinde üretilmiş bir sinyal değildir. Entegre CML C-element sonraki revizyonda ayrı kupon olarak tasarlanıp doğrulanacaktır. Bu durum nihai RAQM dataplane mimarisinde harici yazılım kontrolü olacağı anlamına gelmez; test kartının ölçüm kolaylığıdır.
