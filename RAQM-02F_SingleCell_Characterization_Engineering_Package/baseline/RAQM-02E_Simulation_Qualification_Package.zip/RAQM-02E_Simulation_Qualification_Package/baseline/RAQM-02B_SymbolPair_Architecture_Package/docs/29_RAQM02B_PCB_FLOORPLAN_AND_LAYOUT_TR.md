# 29 — RAQM-02B Test Kartı: PCB Kat Planı ve Yerleşim Kuralları

## 1. Kartın amacı

Kart, tek bir iki-bit sembol çiftini oluşturan iki bağımsız BJT-CML state-cell'i test etmek içindir. Dört düğümlü recurrent mesh'in kendisi değildir. Mesh'e geçişin ön şartı olan hücre ve pair-valid davranışını ölçer.

## 2. Yerleşim blokları

- `CELL_B0`: U1/U2/U3/Q1, RL0P/RL0N, RE0.
- `CELL_B1`: U4/U5/U6/Q2, RL1P/RL1N, RE1.
- `BIAS`: iki hücre için ayrı test edilebilir VBIAS/VCM girişleri.
- `J8 MONITOR`: I_TAIL0/I_TAIL1 sense, VDD monitor, VCM monitor ve GND test pinleri. Pair controller, ACK qualification ve PAIR_VALID üretimi harici laboratuvar fikstüründedir; PCB üzerinde C-element yoktur.
- `POWER`: current-limited VDD_CML ve yerel decoupling.
- `PROBES`: QB0±/QB1± high-Z differential test points.

## 3. Önerilen katman yığını

Ön tasarım önerisi: 4 katman.

| Katman | Rol |
|---|---|
| L1 | CML diferansiyel sinyal ve kısa transistor bağlantıları |
| L2 | Kesintisiz GND referans düzlemi |
| L3 | VDD_CML ve kontrollü bias dağıtımı; güç adaları gerekirse ayrılır |
| L4 | Düşük hızlı kontrol, izleme ve test yönlendirmesi |

Bu bir öneridir; üretici stackup/impedans hesabı ile kesinleşir. Diferansiyel yol altında plane yarığı açılmaz.

## 4. Yerleşim kuralları

1. Her matched pair transistörleri aynı paket içinde kalır; iki kolun collector/base/emitter izleri simetrik ve kısa tutulur.
2. Ux/Uy/Uz aynı bit hücresi yakınında kümelenir; B0 ve B1 hücreleri ayrı bias test noktalarına sahip olur.
3. RL_P ve RL_N eşleştirilir, aynı geometri ve termal çevrede yerleştirilir.
4. Tail sink ve sense direnci kendi bias dönüş akımından ayrı ölçülebilecek şekilde yerleştirilir.
5. Her rail girişinde yerel 100 nF decoupling; kart girişinde 1 µF bulk footprint bulunur. Değer/etkin kapasite ve yerleşim son PCB analizinde kontrol edilir.
6. Probe pad'leri çıkış yükünü minimum etkiler; 50 Ω SMA/terminasyon yalnız devre yeniden boyutlandırılırsa eklenir.
7. High-speed diferansiyel hatlar için ortak-mode, dönüş yolu ve parasitik kapasitans raporlanır.
8. GND plane bölünmez; bias filtreleri sinyal dönüş yolunu bozmayacak şekilde yerleştirilir.
9. Footprint, pin-1 işareti, solder mask ve assembly yönü her transistor için data sheet ile çift kontrol edilir.
10. Kartın iki hücresi arasında termal kuplaj ve güç dönüşü ölçülür.

## 5. Kart üretim kapısı

Kat planı SVG'si Gerber değildir. J8, pair control bloğu değil; yalnız bias/rail izleme başlığıdır. ACK/PAIR_VALID mantığı harici laboratuvar fikstüründedir. Kesin pin/net listesi, transistor-level şematik, SPICE ve bias sweep, ERC/DRC, iz yönlendirme, impedance/parasite kontrolü, BOM availability ve test fixture doğrulanmadan üretim onayı verilmez.
