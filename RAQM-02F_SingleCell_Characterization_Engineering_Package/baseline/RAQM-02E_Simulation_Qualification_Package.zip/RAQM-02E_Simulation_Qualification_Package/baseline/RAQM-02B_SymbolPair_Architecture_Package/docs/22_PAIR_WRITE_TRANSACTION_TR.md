# 22 — Pair Write Transaction ve Dört Fazlı Handshake

## 1. Sinyaller

- `PAIR_REQ`: iki-bit sembol yazma isteği.
- `D0±`, `D1±`: iki bitin diferansiyel girişleri.
- `ACK_B0`, `ACK_B1`: ilgili hücrenin Q diferansiyel çıkışını ölçen harici test fikstürünün capture-kabul gözlemi; 02B kartında üretilen dijital ACK değildir.
- `PAIR_VALID`: harici pair-control fikstürünün, iki bitin birlikte tüketilebilir olduğunu bildiren test/commit sonucudur; 02B PCB üzerinde üretilmez.
- `FAULT`: timeout, invalid diferansiyel seviye, bias veya capture hatası.
- `RESET/INHIBIT`: yeni transaction kabulünü durdurur.

## 2. Olay dizisi

| Aşama | PAIR_REQ | ACK_B0 | ACK_B1 | PAIR_VALID | Kural |
|---|---:|---:|---:|---:|---|
| IDLE | 0 | 0 | 0 | Önceki geçerli kayıt korunabilir | Yeni işlem beklenir |
| INVALIDATE | 1 | 0 | 0 | 0 | PAIR_VALID önce düşer; D0/D1 sabit tutulur |
| CAPTURE-0/1 | 1 | bağımsız | bağımsız | 0 | Hücreler ayrı zamanlarda yakalayabilir |
| COMMIT | 1 | 1 | 1 | 1 | Yalnız iki ACK ve FAULT=0 ise |
| RETURN | 0 | 1→0 | 1→0 | 1 kalır | Yeni veri, ACK dönüşü tamamlanmadan sürülmez |
| IDLE | 0 | 0 | 0 | 1 (kayıt geçerli) | Sonraki write başlamadan invalidate |

## 3. Gönderici kuralları

- `PAIR_REQ` yükselmeden önce D0± ve D1± gerekli setup koşulunda kararlı olmalıdır.
- İki veri çifti, hem ACK_B0 hem ACK_B1 dönene kadar değiştirilmez.
- ACK gözlemleri geldi diye PAIR_VALID otomatik yükseltilmez; 02B aşamasında harici pair-control fikstürü tüm koşulları denetler.
- Yeni transaction aynı pair üzerinde öncekinin dört fazı tamamlanmadan başlatılamaz.

## 4. Capture ile computation completion farkı

`ACK_B0/ACK_B1` yalnız state-cell yakalamasıdır. Bu olay bir algoritmanın çözüldüğü, analog ağın yakınsadığı veya residual'ın yeterli olduğu anlamına gelmez. Gelecekte analog compute layer için ayrı `READY_SETTLED` ve `RESIDUAL_OK` durumları gereklidir.

## 5. Hata

Harici ölçüm fikstüründen bir ACK gözlemi gelmezse, polarite guard band içinde kalırsa veya bias/rail geçersiz olursa PAIR_VALID yükselmez. Timeout yalnız FAULT üretir; eksik ACK'yi sentetik olarak tamamlamaz. Retry ancak hücre state'i güvenli şekilde reset-by-write ile bilinen duruma getirildikten sonra yapılır.
