# 25 — DRNC ve Dallanan Zerya: Vektör Sembol ve Akım Modeli

## 1. Node ve edge

Mesh `G=(V,E)` ile ifade edilir. Bir node state'i:

`X_i = (b1_i, b0_i, valid_i, lineage_i)`

`b1_i,b0_i` klasik iki-bit semboldür; `valid_i` yalnız pair commit sonrasında 1 olur. `lineage_i`, branch/parent/generation ilişkisinin mimari metadata'sıdır. İlk fiziksel 02B kuponu tek outstanding transaction sınırında çalıştığı için lineage ağacını tam genel biçimde taşımaz.

Her edge:

`e=(src,dst,src_port,dst_port,branch_id,kind,lag,polarity,weight_id)`

`lag=0` yalnız G_now feed-forward kenardır. `lag≥1` ancak history state-cell üzerinden izinlidir.

## 2. Dallanan Zerya operatörü

Soyut fork:

`Z_i(X_i) = { (branch_A, X_A), (branch_B, X_B) }`

Branch ID'ler birbirinden ayrıdır. Bu soyut çoğaltma fiziksel olarak bedelsiz değildir. Tam genlikli akım kopyaları için aktif current-copy/driver; bunların akım, gecikme, noise ve güç bütçesi gerekir.

## 3. Birleştirme operatörleri

- `M(a,b,s)`: MUX seçimi; a veya b'den biri.
- `J_sync(a,b)`: aynı lineage/generation için iki operandın rendezvous'u; bitleri otomatik toplamaz.
- `J_arb(a,b)`: mutual exclusion; yalnız bir istek grant edilir.
- `R_lag(X)`: history state-cell üzerinden önceki sembolü okur.
- `S_w(I)`: tanımlı analog current-sum elemanında ağırlıklı toplama.

Bu operatörler tipleri farklı olduğundan tek bir genel “join” işlemine indirgenemez.

## 4. Akım korunum hesabı

Pasif dalda `I_in = I_A + I_B + I_loss`. Her kola I_in kadar akım göndermek için aktif kopyalama veya ayrı sürücü gerekir. Analog toplamada collector/common-mode/headroom hesabı yapılmadan iki netin birleştirilmesi geçerli değildir.

## 5. Sembolik recurrent güncelleme

Bir sembol geçmişi soyut olarak:

`X_i[k+1] = F_i( X_current[k], R_lag(X_history[k]), controls )`

Buradaki `k`, global clock tick'i değildir; tamamlanmış transaction/generation sırasıdır. F_i henüz işlemci talimatı değildir; donanım node türlerinin fonksiyon sözleşmesidir.

## 6. Analog alan için ayrı eşleme

İleride sürekli analog durum vektörü `x(t)` için aday dinamik:

`C dx/dt = -D x + W φ(x) + u`

Burada C ve D pozitif diyagonal katsayı matrisleri, W fiziksel ağırlık/transconductance ağı, φ transistor katının transfer fonksiyonudur. Bu model state-cell latch'e doğrudan uygulanmaz; analog compute block ayrı ölçülür.

Basit yeterli contraction koşulu:

`max_i [ -d_i/C_i + (1/C_i) Σ_j |W_ij| L_j ] < 0`

Burada L_j, φ_j için geçerli Lipschitz üst sınırıdır. Bu koşul sağlanırsa modellenen ideal sistemin durumları daralır; gerçek devrede parazit, doygunluk, noise ve sıcaklık ayrıca hesaba katılmalıdır.
