# 28 — BJT-CML Hücresi: Elektriksel Bütçe ve Parça Seçimi

## 1. Aday aktif elemanlar

- `BCM847BS`: SOT363-3 içinde eşleştirilmiş iki NPN. Üretici current-gain ve V_BE eşleşmesi özelliklerini açıklar; data sheet'te V_BE mismatch için 2 mV maksimum değer, V_CE=5 V ve I_C=2 mA, T_amb=25 °C test koşulundadır. Bu eşleşme yalnız aynı paketteki çift içindir; paketler arası B0/B1 eşleşmesi garanti edilmez.
- `BC847B`: tek NPN tail-sink adayı. Ürün ailesi 45 V V_CEO ve 100 mA I_C sınıfındadır; bu sınırlar hedef çalışma noktası değildir.

## 2. Pin eşlemesi — BCM847BS

Üretici top-view pin tablosu:

| Pin | İç transistor | Terminal |
|---:|---|---|
| 1 | TR1 | E1 |
| 2 | TR1 | B1 |
| 3 | TR2 | C2 |
| 4 | TR2 | E2 |
| 5 | TR2 | B2 |
| 6 | TR1 | C1 |

SOT363-3 yön işareti ve gerçek footprint pin-1 yönü PCB kütüphanesinde data sheet'e göre kontrol edilir. Eski SOT363 sembol/footprint kütüphaneleri otomatik olarak kabul edilmez.

## 3. Her bit hücresi

- DATA differential pair — Ux
- HOLD cross-coupled pair — Uy
- WRITE/HOLD steering pair — Uz
- Tail-current sink — Qx
- Collector loads — RL_P/RL_N
- Tail set element — R_E / external bias

B0 için U1/U2/U3 ve Q1; B1 için U4/U5/U6 ve Q2 kullanılır. Her hücrede 3 eşleştirilmiş dual paket ve 1 tail transistör adayı vardır.

## 4. Bias ve headroom

VDD_CML için +3V3 yalnız tasarım adayıdır. VCM_DATA, VCM_WE, VBIAS_TAIL, I_TAIL, RL ve R_E değerleri dondurulmamıştır. DC çalışma noktası, tüm BJT'lerin aktif bölgede kalması, collector swing, tail sink headroom, input common-mode ve Q çıkış eşikleri birlikte hesaplanır.

İlk mertebe olarak `P_static ≈ VDD × I_supply` ve `I_supply ≈ Σ I_tail + I_control + I_buffer` kullanılır. Bunlar ölçüm yerine geçmez.

## 5. Yük ve prob

Q_P/Q_N önce yüksek empedanslı diferansiyel prob ile ölçülür. Doğrudan 50 Ω terminasyon, LVPECL/VTT terminasyonu veya MC100EP56 yüklemesi otomatik olarak aktarılmaz. BJT-CML hücresi kendi kaynak empedansı ve yükü ile ölçülür.

## 6. Mismatch ve termal eşleşme

BCM847BS iç eşleşmesi bir differential pair için yararlıdır. B0/B1 farklı paketlerde olduğundan iki bit arasında ofset farkı beklenebilir. Her bitin eşik/offset kalibrasyonu, sıcaklık kayması ve akım farkı ölçülmeden ortak threshold varsayılmaz.
