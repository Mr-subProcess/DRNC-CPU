# Değişiklik Günlüğü — RAQM-02B

## 17 Kasım 2026 — RAQM-02B

### Eklenenler
- İki diferansiyel bit hücresini tek bir `B1:B0` sembolü olarak tanımlayan normatif sembol sözleşmesi.
- `PAIR_VALID` ile transaction-level görünürlük/atomiklik protokolü.
- Tek outstanding transaction ve tek-yazıcı kuralları.
- Dört düğümlü gelecekteki recurrent mesh için yeni edge tablosu: iki ileri fork, bir sync join, iki gecikmeli tarihsel bağlantı.
- Tarihsel geri besleme ile analog sürekli-zamanlı geri besleme ayrımı.
- DRNC ve dallanan Zerya için vektör durum ve fiziksel akım korunum eşlemesi.
- Üretici datasheet pin eşlemesi ve 2-bit test kartı BOM/pinout konsepti.
- 31 testli donanım kabul matrisi ve üretim öncesi kapılar.

### Değiştirilen yaklaşım
- Eski tek-hücre testinden iki-bitlik sembol çiftine geçildi.
- İki Q çıkışının aynı anda fiziksel olarak değiştiği iddiası kaldırıldı. Bunun yerine, geçiş sırasında `PAIR_VALID=0` tutularak tüketici tarafında atomik görünürlük sağlanır.
- `epoch` global sayaç/clock değildir; test düzeyinde transaction generation etiketi olarak kalır. RAQM-02B kartı tek outstanding transaction ile sınırlıdır.
- Rezonans ile anında çözüm iddiası kullanılmaz; latch saklama, akım yönlendirme ve analog relaxation farklı fiziksel alt sistemler olarak ayrılır.

### Bilerek yapılmayanlar
- Firmware, Python/C/C++ kaynak kodu, HDL, compiler, code generator veya konfigürasyon kodu yazılmadı.
- PCB üretim verisi veya doğrulanmamış kesin analog değerler üretilmedi.
