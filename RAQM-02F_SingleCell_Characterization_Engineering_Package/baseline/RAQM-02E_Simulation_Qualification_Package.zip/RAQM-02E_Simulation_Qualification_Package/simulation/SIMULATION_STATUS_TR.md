# SPICE Çalışma Durumu

Durum: NOT RUN.

Nedenler:
- Bu build ortamında ngspice mevcut değil.
- Nexperia BCM847BS için doğrulanmış üretici model dosyası bu pakette bulunmuyor.
- Generic BJT modeliyle elde edilecek sonuçlar eşlenmiş çift davranışını kanıtlamaz.

Bu nedenle sayısal simülasyon sonucu, grafik veya PASS iddiası eklenmemiştir.
