# Analiz Sırası

1. Tek BJT modelini datasheet DC eğrileriyle doğrula.
2. BCM847BS dual modelinin pin sırasını ve eşleşme davranışını doğrula.
3. Tek bit hücre DC operating point.
4. DC giriş polaritesi taraması.
5. WRITE→HOLD transient.
6. HOLD sırasında DATA disturb.
7. WE overlap / dead-zone taraması.
8. Power-on ve power-off transient.
9. Temperature ve supply corners.
10. Direnç toleransları ve mismatch.
11. İki bitli sembol çiftine geçiş.

Her aşamada simülatör uyarıları, convergence başarısızlıkları ve model varsayımları rapora dahil edilir.
