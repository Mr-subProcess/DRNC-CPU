# RAQM-02E — Simulation & Qualification Package

## Amaç
RAQM-02D'nin iki bağımsız BJT-CML latch hücresini üretim öncesi elektriksel doğrulamaya hazırlayan mühendislik revizyonudur. Bu sürüm **üretim dosyası değildir**. Kod, firmware, özel programlama dili veya kod oluşturucu içermez.

## Bu pakette
- Transistor seviyesinde doğrulama planı
- DC çalışma noktası ölçüm tablosu
- WRITE/HOLD ve state-retention test matrisi
- Metastabilite ve güç açılış karakterizasyonu
- PVT/Monte-Carlo kapsamı
- SPICE model kaynak/provenans kaydı
- Bench bring-up ve güvenlik prosedürü
- PCB tasarım girdileri ve release gate güncellemesi

## Kritik doğruluk notu
Bu ortamda ngspice ve KiCad CLI bulunmadığından SPICE çözümü, ERC/DRC veya Gerber üretimi çalıştırılmadı. Nexperia BCM847BS için doğrulanmış üretici SPICE modeli pakete eklenmedi; uydurma model veya simülasyon sonucu üretilmedi. Simülasyon kapısı, doğru üretici modeli ve simülatörle yeniden üretilebilir hâle gelene kadar **HOLD** durumundadır.

## Öncelik sırası
1. Gerçek komponent modelini ve exact OPN'yi doğrula.
2. Tek bit hücre için DC op ve transistor bölge kontrollerini yap.
3. WRITE/HOLD transient, state retention ve startup testlerini yap.
4. Sıcaklık, besleme ve tolerans köşelerini tara.
5. Ancak tüm limitler geçilirse iki hücreli sembol test kartına geç.

## Dosya kullanımı
- `simulation/` — model provenance, analiz planı ve ölçüm şablonları
- `validation/` — kabul kriterleri ve test matrisleri
- `hardware/` — önceki BOM/netlist ve 02E değişiklik kaydı
- `docs/` — ayrıntılı mühendislik notları
- `baseline/` — RAQM-02D baseline aynen korunmuştur
